document.addEventListener('DOMContentLoaded', () => {

    // ===== STATE MANAGEMENT (Using localStorage for persistence) =====
    let state = {
        cart: JSON.parse(localStorage.getItem('cart')) || [],
        wishlist: JSON.parse(localStorage.getItem('wishlist')) || [],
        user: JSON.parse(localStorage.getItem('user')) || null,
        filters: { category: 'All', isVeg: false, hasOffers: false, sortBy: 'default' },
        addresses: [ { id: 1, type: 'Home', text: '123 Pixel Lane, Webville' }, { id: 2, type: 'Work', text: '456 Script Street, Code City' } ],
        orderHistory: JSON.parse(localStorage.getItem('orderHistory')) || [],
        cartTotals: { couponDiscount: 0, tipAmount: 0 }
    };
    
    // ===== DOM Elements =====
    const getEl = (id) => document.getElementById(id);
    const query = (selector) => document.querySelector(selector);
    
    // NEW: Elements for the responsive navbar
    const navToggle = query('.nav-toggle');
    const navMenu = query('.nav-menu');
    const body = document.body;

    // ===== GENERAL FUNCTIONS =====
    const saveState = () => {
        localStorage.setItem('cart', JSON.stringify(state.cart));
        localStorage.setItem('wishlist', JSON.stringify(state.wishlist));
        localStorage.setItem('user', JSON.stringify(state.user));
        localStorage.setItem('orderHistory', JSON.stringify(state.orderHistory));
    };

    const showToast = (message, type = 'info') => {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-times-circle' : 'fa-info-circle'}"></i> ${message}`;
        getEl('toast-container').appendChild(toast);
        setTimeout(() => toast.remove(), 3500);
    };

    const showModal = (content, maxWidth = '700px') => {
        query('#modal-container .modal-content').style.maxWidth = maxWidth;
        getEl('modal-body').innerHTML = content;
        getEl('modal-container').classList.add('show');
    };
    
    const hideModal = () => getEl('modal-container').classList.remove('show');
    
    const showItemModal = (itemId) => {
        const item = menu.find(i => i.id === itemId);
        if (!item) return;

        const isCustomizable = item.customizations && item.customizations.length > 0;
        const renderStars = (rating) => '⭐'.repeat(Math.round(rating)) + '☆'.repeat(5 - Math.round(rating));
        
        const itemReviews = reviews[item.id] || [];
        const reviewsHTML = `<div class="modal-reviews">
            <h4><i class="fa-solid fa-comments"></i> Reviews</h4>
            ${itemReviews.length > 0 ? itemReviews.map(r => `
                <div class="review">
                    <div class="review-header"><strong>${r.author}</strong><span>${renderStars(r.rating)}</span></div>
                    <p class="review-comment">"${r.comment}"</p>
                </div>`).join('') : '<p>No reviews yet.</p>'}
           </div>`;

        const relatedItems = menu.filter(m => m.category === item.category && m.id !== item.id).slice(0, 3);
        const relatedItemsHTML = relatedItems.length > 0 ? `<div class="modal-related">
            <h4>More from ${item.category}</h4>
            <div class="related-items-grid">
            ${relatedItems.map(rel => `
                <div class="related-item" data-id="${rel.id}" data-action="show-related-item">
                    <img src="${rel.image}" alt="${rel.name}" referrerpolicy="no-referrer">
                    <span>${rel.name}</span>
                </div>`).join('')}
            </div>
           </div>` : '';
        
        const tagsHTML = `
            <div class="modal-tags">
                ${item.isVeg ? '<span class="tag veg-tag"><i class="fa-solid fa-leaf"></i> Vegetarian</span>' : ''}
                ${isCustomizable ? '<span class="tag customizable-tag"><i class="fa-solid fa-sliders"></i> Customizable</span>' : ''}
            </div>
        `;
           
        const customizationHTML = isCustomizable ? item.customizations.map(cust => `
            <div class="customization-group">
                <label>${cust.label}</label>
                <div class="customization-options">
                    ${cust.options.map(opt => `
                        <button class="${opt === cust.default ? 'active' : ''}" data-key="${cust.key}" data-value="${opt}">${opt}</button>
                    `).join('')}
                </div>
            </div>
        `).join('') : '';

        showModal(`
            <div id="item-preview-modal-body">
                <div class="modal-main-content">
                    <img src="${item.image}" class="modal-img" referrerpolicy="no-referrer">
                    <div class="modal-text">
                        <h2>${item.name}</h2>
                        <p>${item.restaurant}</p>
                        ${tagsHTML}
                        <p class="item-description">${item.description}</p>
                        <p class="modal-price">$${item.price.toFixed(2)}</p>
                        ${customizationHTML}
                        <button class="btn-primary" style="width:100%;" data-id="${item.id}" data-action="add-to-cart">Add to Cart</button>
                    </div>
                </div>
                <div class="modal-additional-content">
                    ${reviewsHTML}
                    ${relatedItemsHTML}
                </div>
            </div>`, '850px');
    };


    // ===== RENDER FUNCTIONS =====
    
    const observeFoodTiles = () => {
        document.querySelectorAll('.food-tile').forEach(tile => observer.observe(tile));
    };

    const renderMenuItems = () => {
        let filteredMenu = [...menu];
        if (state.filters.category !== 'All') filteredMenu = filteredMenu.filter(item => item.category === state.filters.category);
        if (state.filters.isVeg) filteredMenu = filteredMenu.filter(item => item.isVeg);
        if (state.filters.hasOffers) filteredMenu = filteredMenu.filter(item => item.offer);
        
        switch (state.filters.sortBy) {
            case 'price-asc': filteredMenu.sort((a, b) => a.price - b.price); break;
            case 'price-desc': filteredMenu.sort((a, b) => b.price - a.price); break;
            case 'rating-desc': filteredMenu.sort((a, b) => b.rating - a.rating); break;
        }

        getEl('food-grid').innerHTML = filteredMenu.map((item, index) => `
            <div class="food-tile" data-id="${item.id}">
                <div class="tile-img-container">
                    <img src="${item.image}" alt="${item.name}" class="tile-img" referrerpolicy="no-referrer">
                    <i class="fa-${state.wishlist.includes(item.id) ? 'solid' : 'regular'} fa-heart wishlist-icon ${state.wishlist.includes(item.id) ? 'active' : ''}" data-id="${item.id}" data-action="toggle-wishlist"></i>
                    ${item.offer ? `<div class="offer-tag">${item.offer}</div>` : ''}
                </div>
                <div class="tile-content">
                    <h3 class="tile-title">${item.name}</h3>
                    <div class="tile-category-rating">
                        <span>${item.restaurant}</span>
                        <span class="tile-rating"><i class="fa-solid fa-star"></i> ${item.rating}</span>
                    </div>
                    <div class="tile-footer">
                        <span class="tile-price">$${item.price.toFixed(2)}</span>
                        <button class="add-to-cart-btn" data-id="${item.id}" data-action="add-to-cart">Add</button>
                    </div>
                </div>
            </div>`).join('');
        // observeFoodTiles(); // <-- REMOVED to disable on-scroll animation for tiles
    };
    
    const renderCart = () => {
        getEl('cart-badge').textContent = state.cart.reduce((sum, item) => sum + item.quantity, 0);

        if (state.cart.length === 0) {
            getEl('cart-items-container').innerHTML = '<p class="cart-empty-msg" style="text-align:center; padding: 2rem; text-decoration: none;">Your cart is hungry. Feed it!</p>';
        } else {
            getEl('cart-items-container').innerHTML = state.cart.map(cartItem => {
                const menuItem = menu.find(item => item.id === cartItem.itemId);
                const customizationsHTML = cartItem.customizations ? 
                    Object.entries(cartItem.customizations).map(([key, value]) => 
                        `<p class="cart-item-customization">${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}</p>`
                    ).join('') : '';

                return `
                <div class="cart-item">
                    <img src="${menuItem.image}" alt="${menuItem.name}" class="cart-item-img" referrerpolicy="no-referrer">
                    <div class="cart-item-info">
                        <p class="cart-item-name">${menuItem.name}</p>
                        ${customizationsHTML}
                        <p class="cart-item-price" style="text-decoration:none;">$${menuItem.price.toFixed(2)}</p>
                    </div>
                    <div class="cart-item-actions">
                        <button class="quantity-btn" data-cart-entry-id="${cartItem.cartEntryId}" data-change="-1" data-action="change-quantity">-</button>
                        <span>${cartItem.quantity}</span>
                        <button class="quantity-btn" data-cart-entry-id="${cartItem.cartEntryId}" data-change="1" data-action="change-quantity">+</button>
                        <button class="remove-item-btn" data-cart-entry-id="${cartItem.cartEntryId}" data-action="remove-from-cart"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>`;
            }).join('');
        }
        renderCartFooter();
    };

    const renderCartFooter = () => {
        const subtotal = state.cart.reduce((sum, item) => sum + (menu.find(m => m.id === item.itemId).price * item.quantity), 0);
        let deliveryFee = 4.99;
        let deliveryText = `<span>Delivery Fee</span><span>$${deliveryFee.toFixed(2)}</span>`;

        if (subtotal > 50) {
            deliveryFee = 0;
            deliveryText = `<span class="success">Delivery Fee</span><span class="success">FREE</span>`;
        }
        
        if (state.user) {
            if (state.user.membership === 'gold') {
                deliveryFee = 0;
                deliveryText = `<span class="success">Gold Delivery</span><span class="success">FREE</span>`;
            } else if (state.user.membership === 'silver') {
                deliveryFee = 2.49;
                deliveryText = `<span class="success">Silver Delivery</span><span>$${deliveryFee.toFixed(2)}</span>`;
            }
        }

        const total = subtotal - state.cartTotals.couponDiscount + deliveryFee + state.cartTotals.tipAmount;

        getEl('cart-footer').innerHTML = `
            <div class="cart-checkout-form">
                ${state.user ? `
                <div class="form-group">
                    <label for="delivery-address"><i class="fa-solid fa-location-dot"></i> Delivery Address</label>
                    <select id="delivery-address">${state.addresses.map(addr => `<option value="${addr.id}">${addr.type} - ${addr.text}</option>`).join('')}</select>
                </div>
                 <div class="form-group">
                    <label for="coupon-code"><i class="fa-solid fa-tags"></i> Coupon Code</label>
                    <div class="coupon-group">
                        <input type="text" id="coupon-code" placeholder="e.g., GALAXY20">
                        <button id="apply-coupon-btn" data-action="apply-coupon" class="btn-primary" style="padding:0 1rem;">Apply</button>
                    </div>
                </div>
                <div class="form-group">
                    <label for="tip-amount"><i class="fa-solid fa-hand-holding-dollar"></i> Tip Your Rider</label>
                    <input type="number" id="tip-amount" placeholder="Amount" min="0" value="${state.cartTotals.tipAmount || ''}">
                </div>
                ` : `<p style="text-align:center; text-decoration:none;">Please <a href="#" data-action="show-login">login</a> to proceed.</p>`}
            </div>
            <div class="price-summary">
                <div class="price-line"><span>Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
                <div class="price-line">${deliveryText}</div>
                ${state.cartTotals.couponDiscount > 0 ? `<div class="price-line success"><span>Discount</span><span>-$${state.cartTotals.couponDiscount.toFixed(2)}</span></div>` : ''}
                ${state.cartTotals.tipAmount > 0 ? `<div class="price-line"><span>Tip</span><span>$${state.cartTotals.tipAmount.toFixed(2)}</span></div>` : ''}
                <div class="price-line total"><span>Total</span><span>$${total.toFixed(2)}</span></div>
            </div>
            <button id="checkout-btn" data-action="place-order" class="btn-primary" style="width:100%; margin-top:1rem;" ${state.cart.length === 0 || !state.user ? 'disabled' : ''}>Place Order</button>`;
    };
    
    const renderUserActions = () => {
        const container = getEl('user-actions');
        if (state.user) {
            const membershipClass = state.user.membership ? `${state.user.membership}-member` : '';
            container.innerHTML = `<div id="user-profile-icon" class="${membershipClass}" title="My Account" data-action="show-profile">
                <i class="fa-solid fa-user-circle"></i>
            </div>`;
        } else {
            container.innerHTML = `<button id="login-btn" data-action="show-login" class="btn-primary">Login</button>`;
        }
    };

    const renderInitialComponents = () => {
        const categories = ['All', ...new Set(menu.map(item => item.category))];
        getEl('category-container').innerHTML = categories.map(c => `<button class="category-btn ${c === 'All' ? 'active' : ''}" data-category="${c}">${c}</button>`).join('');
        
        // CORB FIX: Refactor slider to use <img> tags with referrerpolicy
        query('.slider-wrapper').innerHTML = heroSlides.map(s => `
            <div class="slide">
                <img src="${s.img}" alt="${s.title}" class="slide-img" referrerpolicy="no-referrer">
                <div class="slide-content">
                    <h1>${s.title}</h1>
                    <p>${s.text}</p>
                </div>
            </div>
        `).join('');

        getEl('gold-banner-container').innerHTML = `<div class="feature-banner"><div><h3 class="feature-banner-title">Galaxy Memberships</h3><p>Get free delivery and exclusive offers!</p></div><button class="btn-primary" data-action="show-membership-modal">View Tiers</button></div>`;

        renderUserActions();
        renderMenuItems();
        renderCart();
    };

    // ===== CORE LOGIC & EVENT HANDLERS =====

    // RESPONSIVE FIX: Add event listener for the hamburger menu toggle
    // This now includes toggling a 'no-scroll' class on the body to prevent
    // the background page from scrolling when the mobile menu is open.
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('nav-menu--visible');
            navToggle.classList.toggle('is-active');
            body.classList.toggle('no-scroll');
        });
    }

    const handleAction = (e) => {
        const target = e.target.closest('[data-action]');
        if (!target) return;

        const action = target.dataset.action;
        const id = parseInt(target.dataset.id);
        const cartEntryId = target.dataset.cartEntryId;

        switch(action) {
            case 'show-login':
                showModal(`
                    <div class="modal-tabs">
                        <div class="modal-tab active" data-tab="login-tab">Login</div>
                        <div class="modal-tab" data-tab="register-tab">Register</div>
                    </div>
                    <div id="login-tab" class="modal-tab-content active">
                        <h2><i class="fa-solid fa-user-astronaut"></i> Welcome Back</h2>
                        <p>Login to continue your culinary journey.</p>
                        <div class="form-group"><label for="login-email">Email</label><input id="login-email" type="email" value="explorer@gourmet.com" autocomplete="email"></div>
                        <div class="form-group"><label for="login-password">Password</label><input id="login-password" type="password" value="password" autocomplete="current-password"></div>
                        <button data-action="login" class="btn-primary" style="width:100%">Login</button>
                    </div>
                    <div id="register-tab" class="modal-tab-content">
                        <h2><i class="fa-solid fa-user-plus"></i> Join the Galaxy</h2>
                        <p>Create an account to save your preferences.</p>
                        <div class="form-group"><label for="reg-name">Name</label><input id="reg-name" type="text" placeholder="Starlight Seeker" autocomplete="name"></div>
                        <div class="form-group"><label for="reg-email">Email</label><input id="reg-email" type="email" placeholder="you@galaxy.net" autocomplete="email"></div>
                        <div class="form-group"><label for="reg-password">Password</label><input id="reg-password" type="password" placeholder="••••••••" autocomplete="new-password"></div>
                        <button data-action="register" class="btn-primary" style="width:100%">Create Account</button>
                    </div>
                `, '450px');
                break;
            case 'login':
                state.user = { name: "Galaxy Explorer", email: "explorer@gourmet.com", membership: null };
                saveState();
                renderUserActions();
                renderCart();
                hideModal();
                showToast('Login successful! Welcome back.', 'success');
                break;
            case 'register':
                 const name = getEl('reg-name').value;
                 const email = getEl('reg-email').value;
                 const password = getEl('reg-password').value;
                 if (!name || !email || !password) {
                     showToast('Please fill all fields to register.', 'error');
                     return;
                 }
                 state.user = { name, email, membership: null };
                 saveState();
                 renderUserActions();
                 renderCart();
                 hideModal();
                 showToast(`Welcome, ${name}! Your account has been created.`, 'success');
                 break;
            case 'show-profile':
                const memberStatus = state.user.membership ? `<p class="splash-text" style="text-decoration:none;"><i class="fa-solid fa-star"></i> Galaxy ${state.user.membership.charAt(0).toUpperCase() + state.user.membership.slice(1)} Member</p>` : `<p>Not a member? <a href="#" data-action="show-membership-modal">Join Now!</a></p>`;
                showModal(`
                    <div class="modal-tabs"><div class="modal-tab active" data-tab="profile">Profile</div><div class="modal-tab" data-tab="history">Order History</div><div class="modal-tab" data-tab="wishlist">Wishlist</div></div>
                    <div id="profile" class="modal-tab-content active"><h3>${state.user.name}</h3><p>${state.user.email}</p>${memberStatus}<button data-action="logout" class="btn-primary" style="margin-top:1rem;">Logout</button></div>
                    <div id="history" class="modal-tab-content">${state.orderHistory.length > 0 ? state.orderHistory.map(o => `<div class="order-history-item"><span>Order #${o.id} - $${o.total.toFixed(2)} on ${new Date(o.date).toLocaleDateString()}</span><button data-action="reorder" data-order-id="${o.id}" class="btn-primary reorder-btn">Reorder</button></div>`).join('') : '<p>No past orders found.</p>'}</div>
                    <div id="wishlist" class="modal-tab-content">${state.wishlist.length > 0 ? state.wishlist.map(wId => { const item = menu.find(m => m.id === wId); return `<div class="wishlist-modal-item"><div class="wishlist-item-info"><img src="${item.image}" class="wishlist-item-img" referrerpolicy="no-referrer"/><span>${item.name}</span></div><div class="wishlist-item-actions"><button data-id="${item.id}" data-action="add-to-cart" class="btn-primary wishlist-add-btn">Add</button><button data-id="${item.id}" data-action="toggle-wishlist" class="remove-item-btn" title="Remove from wishlist"><i class="fa-solid fa-trash"></i></button></div></div>`}).join('') : '<p>Your wishlist is empty. Add items by clicking the heart icon!</p>'}</div>
                `, '600px');
                break;
            case 'logout':
                state.user = null;
                saveState();
                renderUserActions();
                renderCart();
                hideModal();
                showToast('You have been logged out.');
                break;
            case 'add-to-cart':
                const menuItemToAdd = menu.find(m => m.id === id);
                const isCustomizable = menuItemToAdd.customizations && menuItemToAdd.customizations.length > 0;
                const isFromModal = target.closest('.modal-content');

                if (isCustomizable && !isFromModal) {
                    showItemModal(id);
                    if (target.closest('.wishlist-modal-item')) {
                        hideModal();
                        setTimeout(() => showItemModal(id), 400);
                    }
                    return;
                }

                let selectedCustomizations = {};
                if (isCustomizable && isFromModal) {
                    isFromModal.querySelectorAll('.customization-options button.active').forEach(btn => {
                        const key = btn.dataset.key;
                        const value = btn.dataset.value;
                        selectedCustomizations[key] = value;
                    });
                }
                
                const customIdPart = Object.keys(selectedCustomizations).sort().map(key => `${key}:${selectedCustomizations[key]}`).join('-');
                const cartEntryIdToAdd = isCustomizable ? `${id}-${customIdPart}` : `${id}`;
                
                const existingItem = state.cart.find(item => item.cartEntryId === cartEntryIdToAdd);
                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    state.cart.push({ cartEntryId: cartEntryIdToAdd, itemId: id, quantity: 1, customizations: selectedCustomizations });
                }

                showToast(`${menuItemToAdd.name} added to cart!`, 'success');
                saveState();
                renderCart();
                break;
            case 'change-quantity':
                const cartItem = state.cart.find(item => item.cartEntryId === cartEntryId);
                if(cartItem) {
                    cartItem.quantity += parseInt(target.dataset.change);
                    if (cartItem.quantity <= 0) state.cart = state.cart.filter(item => item.cartEntryId !== cartEntryId);
                }
                saveState();
                renderCart();
                break;
            case 'remove-from-cart':
                state.cart = state.cart.filter(i => i.cartEntryId !== cartEntryId);
                saveState();
                renderCart();
                break;
            case 'apply-coupon':
                const code = getEl('coupon-code').value.toUpperCase();
                if (code === 'GALAXY20') {
                    const subtotal = state.cart.reduce((sum, item) => sum + (menu.find(m => m.id === item.itemId).price * item.quantity), 0);
                    state.cartTotals.couponDiscount = subtotal * 0.2;
                    showToast('Coupon applied!', 'success');
                } else {
                    state.cartTotals.couponDiscount = 0;
                    showToast('Invalid coupon code.', 'error');
                }
                renderCartFooter();
                break;
            case 'toggle-wishlist':
                e.stopPropagation(); 
                const wasInWishlist = state.wishlist.includes(id);

                if (wasInWishlist) {
                    state.wishlist = state.wishlist.filter(wId => wId !== id);
                    showToast('Removed from wishlist.', 'info');
                } else {
                    state.wishlist.push(id);
                    showToast('Added to wishlist!', 'success');
                }
                saveState();
                renderMenuItems(); 

                const wishlistItemInModal = target.closest('.wishlist-modal-item');
                if (wishlistItemInModal && wasInWishlist) {
                    wishlistItemInModal.style.transition = 'opacity 0.3s ease';
                    wishlistItemInModal.style.opacity = '0';
                    setTimeout(() => {
                        wishlistItemInModal.remove();
                        const wishlistTab = getEl('wishlist');
                        if (wishlistTab && wishlistTab.querySelectorAll('.wishlist-modal-item').length === 0) {
                            wishlistTab.innerHTML = '<p>Your wishlist is empty. Add items by clicking the heart icon!</p>';
                        }
                    }, 300);
                }
                break;
            case 'show-membership-modal':
                if (!state.user) { showToast("Please login to view memberships.", 'info'); return; }
                hideModal();
                showModal(`
                    <div class="membership-modal-content">
                        <h2><i class="fa-solid fa-crown" style="color:var(--splash-cyan);"></i> Galaxy Memberships</h2>
                        <p>Upgrade to unlock exclusive benefits and elevate your dining experience.</p>
                        <div class="membership-tiers">
                            <div class="membership-tier">
                                <h3 class="tier-title">Bronze</h3>
                                <ul>
                                    <li><i class="fa-solid fa-check"></i> Basic Support</li>
                                    <li><i class="fa-solid fa-check"></i> Newsletter Access</li>
                                </ul>
                                <p class="tier-price">$19 / year</p>
                                <button class="btn-primary" data-action="join-tier" data-tier="bronze">Join Bronze</button>
                            </div>
                            <div class="membership-tier">
                                <h3 class="tier-title">Silver</h3>
                                <ul>
                                    <li><i class="fa-solid fa-check"></i> All Bronze Perks</li>
                                    <li><i class="fa-solid fa-check"></i> 50% Off Delivery</li>
                                    <li><i class="fa-solid fa-check"></i> Monthly Vouchers</li>
                                </ul>
                                <p class="tier-price">$49 / year</p>
                                <button class="btn-primary" data-action="join-tier" data-tier="silver">Join Silver</button>
                            </div>
                            <div class="membership-tier">
                                <h3 class="tier-title">Gold</h3>
                                <ul>
                                    <li><i class="fa-solid fa-check"></i> All Silver Perks</li>
                                    <li><i class="fa-solid fa-check"></i> FREE Delivery</li>
                                    <li><i class="fa-solid fa-check"></i> Exclusive Deals</li>
                                    <li><i class="fa-solid fa-check"></i> Priority Support</li>
                                </ul>
                                <p class="tier-price">$99 / year</p>
                                <button class="btn-primary" data-action="join-tier" data-tier="gold">Join Gold</button>
                            </div>
                        </div>
                    </div>`, '800px');
                break;
            case 'join-tier':
                const tier = target.dataset.tier;
                if (state.user) {
                    state.user.membership = tier;
                    saveState();
                    renderUserActions();
                    renderCart();
                    hideModal();
                    showToast(`Welcome to Galaxy ${tier.charAt(0).toUpperCase() + tier.slice(1)}! Enjoy your perks.`, 'success');
                }
                break;
            case 'place-order':
                const orderId = Math.floor(Math.random() * 9000) + 1000;
                const total = parseFloat(query('.price-line.total span:last-child').textContent.replace('$', ''));
                state.orderHistory.unshift({ id: orderId, date: new Date(), items: [...state.cart], total });
                if(state.orderHistory.length > 10) state.orderHistory.pop();
                state.cart = [];
                state.cartTotals = { couponDiscount: 0, tipAmount: 0 };
                saveState();
                renderCart();
                getEl('cart-sidebar').classList.remove('open');
                
                const statusFloater = getEl('delivery-status-floater');
                statusFloater.innerHTML = `<div id="delivery-status-container"><i class="fa-solid fa-receipt"></i> Order #${orderId}: Placed <div class="progress-bar-container"><div class="progress-bar"></div></div></div>`;
                statusFloater.style.display = 'block';
                const progressBar = statusFloater.querySelector('.progress-bar');
                progressBar.style.animationName = 'progress';
                setTimeout(() => {
                    statusFloater.innerHTML = `<div id="delivery-status-container"><i class="fa-solid fa-truck-fast"></i> Order #${orderId}: Out for Delivery</div>`;
                }, 2000);
                setTimeout(() => { statusFloater.style.display = 'none'; statusFloater.innerHTML=''; }, 7000);

                showToast("Order placed successfully!", "success");
                break;
            case 'show-support-chat':
                showModal(`
                    <div id="support-chat-body">
                        <h3><i class="fa-solid fa-headset"></i> Support Assistant</h3>
                        <div id="chat-window" class="chat-window">
                             <div class="chat-message bot">Hello! I'm the Gourmet Galaxy assistant. How can I help you today? You can ask about "delivery", "payment", or "offers".</div>
                        </div>
                        <form id="chat-input-form">
                            <input type="text" id="chat-input" placeholder="Type your message..." autocomplete="off">
                            <button type="submit" class="btn-primary">Send</button>
                        </form>
                    </div>
                `, '500px');
                break;
            case 'reorder':
                const orderToReorder = state.orderHistory.find(o => o.id === parseInt(target.dataset.orderId));
                if (orderToReorder) {
                    orderToReorder.items.forEach(item => {
                        const existingCartItem = state.cart.find(ci => ci.cartEntryId === item.cartEntryId);
                        if (existingCartItem) {
                            existingCartItem.quantity += item.quantity;
                        } else {
                            state.cart.push({ ...item });
                        }
                    });
                    saveState();
                    renderCart();
                    hideModal();
                    getEl('cart-sidebar').classList.add('open');
                    showToast('Items from your past order have been added to the cart!', 'success');
                }
                break;
            case 'show-related-item':
                hideModal();
                setTimeout(() => showItemModal(id), 300);
                break;
        }
    };
    
    document.body.addEventListener('click', handleAction);
    
    // Non-action clicks & other event listeners
    document.body.addEventListener('click', e => {
        const tile = e.target.closest('.food-tile');
        if (tile && !e.target.closest('[data-action]')) {
            showItemModal(parseInt(tile.dataset.id));
        }
        
        if (e.target.closest('#cart-icon')) getEl('cart-sidebar').classList.add('open');
        if (e.target.id === 'cart-close-btn' || e.target.id === 'cart-overlay') getEl('cart-sidebar').classList.remove('open');
        
        if (e.target.classList.contains('modal-close-btn') || e.target.id === 'modal-container') hideModal();
        
        if(e.target.classList.contains('category-btn')) {
            document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
            e.target.classList.add('active');
            state.filters.category = e.target.dataset.category;
            renderMenuItems();
        }
        
        if (e.target.classList.contains('modal-tab')) {
            const tabName = e.target.dataset.tab;
            e.target.parentElement.querySelectorAll('.modal-tab').forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
e.target.closest('.modal-content').querySelectorAll('.modal-tab-content').forEach(c => c.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
        }

        const custButton = e.target.closest('.customization-options button');
        if (custButton) {
            custButton.parentElement.querySelectorAll('button').forEach(btn => btn.classList.remove('active'));
            custButton.classList.add('active');
        }

        const recommendation = e.target.closest('.recommendation-item');
        if (recommendation) {
            showItemModal(parseInt(recommendation.dataset.id));
            getEl('search-recommendations').style.display = 'none';
            getEl('search-bar').value = '';
        }
    });
    
    getEl('location-input').addEventListener('change', e => {
        const pincode = e.target.value.trim();
        if (/^\d{5,6}$/.test(pincode)) {
             showToast(`Delivery location set to pincode ${pincode}.`, 'success');
        } else if (pincode !== '') {
             showToast('Please enter a valid 5 or 6 digit pincode.', 'error');
             e.target.value = '';
        }
    });

    getEl('search-bar').addEventListener('input', e => {
        const term = e.target.value.toLowerCase();
        const recommendations = getEl('search-recommendations');
        if (term.length > 1) {
            const results = menu.filter(i => i.name.toLowerCase().includes(term) || i.category.toLowerCase().includes(term) || i.restaurant.toLowerCase().includes(term));
            recommendations.innerHTML = results.slice(0, 5).map(i => `<div class="recommendation-item" data-id="${i.id}"><img src="${i.image}" class="recommendation-img" referrerpolicy="no-referrer"><div><div>${i.name}</div><small>${i.category} from ${i.restaurant}</small></div></div>`).join('');
            recommendations.style.display = 'block';
        } else {
            recommendations.style.display = 'none';
        }
    });

    query('.filters-and-sorting').addEventListener('change', e => {
        state.filters.isVeg = getEl('filter-veg').checked;
        state.filters.hasOffers = getEl('filter-offers').checked;
        state.filters.sortBy = getEl('sort-by').value;
        renderMenuItems();
    });

    getEl('cart-footer').addEventListener('change', e => {
        if (e.target.id === 'tip-amount') {
            state.cartTotals.tipAmount = parseFloat(e.target.value) || 0;
            renderCartFooter();
        }
    });
    
    document.body.addEventListener('submit', e => {
        if (e.target.id === 'chat-input-form') {
            e.preventDefault();
            const input = getEl('chat-input');
            const message = input.value.trim();
            if (!message) return;

            const chatWindow = getEl('chat-window');
            chatWindow.innerHTML += `<div class="chat-message user">${message}</div>`;
            input.value = '';
            chatWindow.scrollTop = chatWindow.scrollHeight;

            setTimeout(() => {
                let botResponse = "I'm not sure how to help with that. Could you try asking about 'delivery', 'payment', or 'offers'?";
                if (message.toLowerCase().includes('delivery')) {
                    botResponse = "Our standard delivery takes 30-45 minutes. Silver members get 50% off delivery, and Gold members get it for free!";
                } else if (message.toLowerCase().includes('payment')) {
                    botResponse = "We accept all major credit cards, PayPal, and Galaxy Credits.";
                } else if (message.toLowerCase().includes('offer')) {
                    botResponse = "Check the 'Offers' filter on the menu page for current deals! Members get exclusive discounts.";
                }
                chatWindow.innerHTML += `<div class="chat-message bot">${botResponse}</div>`;
                chatWindow.scrollTop = chatWindow.scrollHeight;
            }, 1000);
        }
    });

    // Slider Logic
    const sliderWrapper = query('.slider-wrapper');
    const prevBtn = query('.slider-nav.prev');
    const nextBtn = query('.slider-nav.next');
    let currentSlide = 0;
    const nextSlide = () => { 
        if(heroSlides.length === 0) return;
        currentSlide = (currentSlide + 1) % heroSlides.length; 
        sliderWrapper.style.transform = `translateX(-${currentSlide * 100}%)`; 
    };
    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', () => { 
        if(heroSlides.length === 0) return;
        currentSlide = (currentSlide - 1 + heroSlides.length) % heroSlides.length; 
        sliderWrapper.style.transform = `translateX(-${currentSlide * 100}%)`; 
    });
    setInterval(nextSlide, 5000);
    
    // ===== SCROLL OBSERVER LOGIC =====
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    // FIX: Updated callback for better performance
    const observerCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // Once an element is visible, we don't need to keep watching it.
                observer.unobserve(entry.target); 
            }
        });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    // Observe the main sections that have the 'reveal' class
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    // The food-tile observer is now handled by the 'observeFoodTiles' function

    // ===== INITIAL LOAD =====
    renderInitialComponents();
});