// script.js
import products from './data.js';

// Function to show alert messages
function showAlert(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`; // Use class names for styling
    notification.classList.add('show');

    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000); // Hide after 3 seconds
}


// Smooth Scrolling - EXCLUDE SOCIAL LINKS
document.querySelectorAll('a[href^="#"]:not(.social-links a)').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');

        if (targetId && targetId !== "#") { // Check if targetId exists and is not just '#'
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        }
    });
});

// Basic Form Validation (Simple example)
const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
        const nameInput = this.querySelector('input[name="name"]');
        const emailInput = this.querySelector('input[name="email"]');
        const messageInput = this.querySelector('textarea[name="message"]');

        if (!nameInput.value || !emailInput.value || !messageInput.value) {
            showAlert('Please fill in all fields.', 'error');
            event.preventDefault(); // Prevent form submission
            return; // Stop further execution
        }

        //Basic email validation (More robust validation is recommended)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailInput.value)) {
            showAlert('Please enter a valid email address.', 'error');
            event.preventDefault();
            return; // Stop further execution
        }
        event.preventDefault(); // Prevent form submission
        showAlert('Form submitted successfully!', 'success'); // Show success message
        this.reset(); // Clear form fields on successful submission
    });
}

// Pagination Logic
const productsPerPage = 8;
let currentPage = 1;

function displayProducts(page) {
    const collectionGrid = document.getElementById('collection-grid');
    collectionGrid.innerHTML = ''; // Clear existing products

    const startIndex = (page - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const productsToDisplay = products.slice(startIndex, endIndex);

    if (productsToDisplay.length === 0 && page > 1) {
        // If somehow navigating to an empty page, go back to the last valid page
        currentPage--;
        displayProducts(currentPage);
        return;
    }

    productsToDisplay.forEach(product => {
        const productHTML = `
            <div class="collection-item" data-aos="fade-up">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <a href="#" class="details-button" data-product-id="${product.id}">View Details</a>
            </div>
        `;
        collectionGrid.innerHTML += productHTML;
    });
    AOS.refresh(); //refresh the aos after products are displayed
}

function displayPagination() {
    const paginationDiv = document.getElementById('pagination');
    paginationDiv.innerHTML = ''; // Clear existing pagination links

    const totalPages = Math.ceil(products.length / productsPerPage);

    if (totalPages <= 1) { // Hide pagination if only one page
        paginationDiv.style.display = 'none';
        return;
    } else {
        paginationDiv.style.display = 'block';
    }

    for (let i = 1; i <= totalPages; i++) {
        const pageLink = document.createElement('a');
        pageLink.href = '#';
        pageLink.textContent = i;
        pageLink.classList.add('page-link'); // Add a class for styling

        if (i === currentPage) {
            pageLink.classList.add('active'); // Highlight the current page
        }

        pageLink.addEventListener('click', (event) => {  // Add event argument
            event.preventDefault(); // Prevent scroll to top
            currentPage = i;
            displayProducts(currentPage);
            updateActivePageLink();
            // Scroll to the collections section when changing page
            document.getElementById('collections').scrollIntoView({ behavior: 'smooth' });
        });

        paginationDiv.appendChild(pageLink);
    }
}

function updateActivePageLink() {
    const pageLinks = document.querySelectorAll('.page-link');
    pageLinks.forEach(link => {
        link.classList.remove('active');
        if (parseInt(link.textContent) === currentPage) {
            link.classList.add('active');
        }
    });
}

// Initial display
displayProducts(currentPage);
displayPagination();

// Social Links - Direct assignment after DOM is ready - Attempt 2
document.addEventListener('DOMContentLoaded', function() {
    const facebookLink = document.querySelector('.social-links a.facebook');
    const twitterLink = document.querySelector('.social-links a.twitter');
    const instagramLink = document.querySelector('.social-links a.instagram');
    const linkedinLink = document.querySelector('.social-links a.linkedin');

    if (facebookLink) {
        facebookLink.href = 'https://www.facebook.com/yourpage';
    }
    if (twitterLink) {
        twitterLink.href = 'https://www.twitter.com/yourhandle';
    }
    if (instagramLink) {
        instagramLink.href = 'https://www.instagram.com/yourprofile';
    }
    if (linkedinLink) {
        linkedinLink.href = 'https://www.linkedin.com/in/yourprofile';
    }

    // Search Overlay Elements
    const searchIcon = document.getElementById('search-icon');
    const searchOverlay = document.getElementById('search-overlay');
    const closeSearch = document.getElementById('close-search');
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const clearSearchButton = document.getElementById('clear-search-button');

    // Cart Overlay Elements
    const cartIcon = document.getElementById('cart-icon');
    const cartOverlay = document.getElementById('cart-overlay');
    const closeCart = document.getElementById('close-cart');
    const cartItemsList = document.getElementById('cart-items');
    const cartTotalSpan = document.getElementById('cart-total');
    const checkoutButton = document.getElementById('checkout-button');
    const clearAllCartButton = document.getElementById('clear-all-cart-button'); // New
    const continueShoppingButton = document.getElementById('continue-shopping-button'); // New

    // Initialize cart from localStorage if available, otherwise empty array
    let cart = JSON.parse(localStorage.getItem('greedCart')) || [];

    // Account Overlay Elements
    const accountIcon = document.getElementById('account-icon');
    const accountOverlay = document.getElementById('account-overlay');
    const closeAccount = document.getElementById('close-account');
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');
    const loggedInSection = document.getElementById('logged-in-section');
    const loggedInUsernameSpan = document.getElementById('logged-in-username');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const logoutButton = document.getElementById('logout-button');

    let loggedInUser = JSON.parse(localStorage.getItem('greedLoggedInUser')) || null;

    // Product Modal Elements
    const productModal = document.getElementById('product-modal');
    const closeModal = document.getElementById('close-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalImage = document.getElementById('modal-image');
    const modalDescription = document.getElementById('modal-description');
    const productDetailsDiv = document.getElementById('product-details');
    const productReviewsDiv = document.getElementById('product-reviews');
    const productRatingsDiv = document.getElementById('product-ratings');
    const addToCartButton = document.getElementById('add-to-cart');
    let currentProduct = null; // To store the product currently displayed in the modal

    // Function to adjust overlay padding and max-height for scrolling
    function adjustOverlayPadding() {
        const header = document.querySelector('header');
        const headerHeight = header.offsetHeight;

        // Calculate available height for modal content
        const viewportHeight = window.innerHeight;
        // Subtract header height and some top/bottom margin/padding for the modal itself
        const availableContentHeight = viewportHeight - (headerHeight + 80); // 80px for top/bottom margins/padding

        document.querySelectorAll('.search-content, .cart-content, .account-content, .product-modal-content').forEach(content => {
            content.style.maxHeight = `${Math.max(availableContentHeight, 300)}px`; // Min height of 300px
        });
    }

    // --- Cart Functionality ---
    function saveCart() {
        localStorage.setItem('greedCart', JSON.stringify(cart));
    }

    function addItemToCart(product) {
        const existingItem = cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            // Ensure product has a price before adding to cart
            if (typeof product.price === 'undefined' || product.price === null) {
                console.warn(`Product '${product.name}' (ID: ${product.id}) is missing a 'price' property or it is null. Defaulting to 0.`);
                product.price = 0; // Default to 0 to prevent errors
            }
            cart.push({ ...product, quantity: 1 });
        }
        saveCart();
        renderCart();
    }

    function removeItemFromCart(productId) {
        cart = cart.filter(item => item.id !== productId);
        saveCart();
        renderCart();
        showAlert('Item removed from cart.', 'info');
    }

    function changeItemQuantity(productId, change) {
        const item = cart.find(item => item.id === productId);
        if (item) {
            item.quantity += change;
            if (item.quantity <= 0) {
                removeItemFromCart(productId); // Remove if quantity drops to 0 or less
            } else {
                saveCart();
                renderCart();
            }
        }
    }

    function renderCart() {
        cartItemsList.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            cartItemsList.innerHTML = '<li class="empty-cart-message" style="text-align: center; color: #ccc;">Your cart is empty.</li>';
        } else {
            cart.forEach(item => {
                const li = document.createElement('li');
                li.classList.add('cart-item');
                const itemSubtotal = (item.price * item.quantity).toFixed(2);
                total += parseFloat(itemSubtotal);

                li.innerHTML = `
                    <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                    <div class="cart-item-details">
                        <span class="cart-item-name">${item.name}</span>
                        <div class="cart-item-quantity-controls">
                            <button class="quantity-minus" data-id="${item.id}">-</button>
                            <span class="cart-item-quantity">${item.quantity}</span>
                            <button class="quantity-plus" data-id="${item.id}">+</button>
                        </div>
                        <span class="cart-item-price">$${item.price.toFixed(2)} ea.</span>
                        <span class="cart-item-subtotal">Total: $${itemSubtotal}</span>
                    </div>
                    <button class="remove-item" data-id="${item.id}">×</button>
                `;
                cartItemsList.appendChild(li);
            });
        }
        cartTotalSpan.textContent = total.toFixed(2);

        // Add event listeners for remove and quantity buttons using event delegation
        // This is more efficient than adding listeners in the loop for each item
        cartItemsList.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                removeItemFromCart(productId);
            });
        });

        cartItemsList.querySelectorAll('.quantity-minus').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                changeItemQuantity(productId, -1);
            });
        });

        cartItemsList.querySelectorAll('.quantity-plus').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                changeItemQuantity(productId, 1);
            });
        });
    }

    // --- Event Listeners for Overlays ---
    searchIcon.addEventListener('click', (e) => {
        e.preventDefault();
        searchOverlay.style.display = 'flex';
        adjustOverlayPadding();
        searchInput.focus();
    });

    closeSearch.addEventListener('click', () => {
        searchOverlay.style.display = 'none';
        searchInput.value = '';
        displayProducts(currentPage); // Re-display all products when search is closed
        displayPagination();
    });

    cartIcon.addEventListener('click', (e) => {
        e.preventDefault();
        cartOverlay.style.display = 'flex';
        adjustOverlayPadding();
        renderCart(); // Render cart items when opening
    });

    closeCart.addEventListener('click', () => {
        cartOverlay.style.display = 'none';
    });

    accountIcon.addEventListener('click', (e) => {
        e.preventDefault();
        updateAccountOverlay(); // Update view based on login status
        accountOverlay.style.display = 'flex';
        adjustOverlayPadding();
    });

    closeAccount.addEventListener('click', () => {
        accountOverlay.style.display = 'none';
    });

    // --- Account Overlay Logic ---
    function updateAccountOverlay() {
        if (loggedInUser) {
            loginSection.style.display = 'none';
            registerSection.style.display = 'none';
            loggedInSection.style.display = 'block';
            loggedInUsernameSpan.textContent = loggedInUser.name;
        } else {
            loginSection.style.display = 'block'; // Default to login view
            registerSection.style.display = 'none';
            loggedInSection.style.display = 'none';
        }
    }

    showRegisterLink.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.reset(); // Clear login form
        loginSection.style.display = 'none';
        registerSection.style.display = 'block';
    });

    showLoginLink.addEventListener('click', function(e) {
        e.preventDefault();
        registerForm.reset(); // Clear register form
        registerSection.style.display = 'none';
        loginSection.style.display = 'block';
    });

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = e.target.elements['login-email'].value;
        const password = e.target.elements['login-password'].value;

        // Basic mock login: In a real app, you'd send this to a server for validation
        if (email && password) {
            // Simulate successful login
            loggedInUser = { name: email.split('@')[0], email: email };
            localStorage.setItem('greedLoggedInUser', JSON.stringify(loggedInUser));
            showAlert(`Welcome back, ${loggedInUser.name}!`, 'success');
            updateAccountOverlay();
            accountOverlay.style.display = 'none'; // Close modal on successful login
        } else {
            showAlert('Please enter both email and password.', 'error');
        }
    });

    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = e.target.elements['register-name'].value;
        const email = e.target.elements['register-email'].value;
        const password = e.target.elements['register-password'].value;

        // Basic mock registration: In a real app, you'd send this to a server
        if (name && email && password) {
            // Simulate successful registration and immediate login
            loggedInUser = { name: name, email: email };
            localStorage.setItem('greedLoggedInUser', JSON.stringify(loggedInUser));
            showAlert(`Account created and logged in successfully, ${loggedInUser.name}!`, 'success');
            updateAccountOverlay();
            accountOverlay.style.display = 'none'; // Close modal on successful registration
        } else {
            showAlert('Please fill all registration fields.', 'error');
        }
    });

    logoutButton.addEventListener('click', function() {
        loggedInUser = null;
        localStorage.removeItem('greedLoggedInUser');
        showAlert('Logged out successfully.', 'info');
        updateAccountOverlay();
        accountOverlay.style.display = 'none'; // Close modal on logout
    });

    // Initial update of account overlay on page load
    updateAccountOverlay();

    // --- Product Modal Functionality ---
    document.getElementById('collection-grid').addEventListener('click', (e) => {
        if (e.target.classList.contains('details-button')) {
            e.preventDefault();
            const productId = parseInt(e.target.dataset.productId);
            currentProduct = products.find(p => p.id === productId); // Store the entire product object

            if (currentProduct) {
                modalTitle.textContent = currentProduct.name;
                modalImage.src = currentProduct.image;
                modalImage.alt = currentProduct.name;
                modalDescription.textContent = currentProduct.description;

                // Populate Details section
                productDetailsDiv.innerHTML = '';
                if (currentProduct.details) {
                    for (const key in currentProduct.details) {
                        if (Object.hasOwnProperty.call(currentProduct.details, key)) {
                            const p = document.createElement('p');
                            p.innerHTML = `<strong>${key}:</strong> ${currentProduct.details[key]}`;
                            productDetailsDiv.appendChild(p);
                        }
                    }
                } else {
                    productDetailsDiv.innerHTML = '<p>No additional details available.</p>';
                }

                // Populate Reviews section (Mock Data)
                productReviewsDiv.innerHTML = '';
                const mockReviews = [
                    { name: 'Alice Smith', rating: 5, comment: 'Absolutely stunning! Exceeded my expectations.' },
                    { name: 'Bob Johnson', rating: 4, comment: 'Great quality, but delivery took a bit longer than expected.' },
                    { name: 'Charlie Brown', rating: 5, comment: 'A truly luxurious item. Worth every penny!' },
                    { name: 'Diana Prince', rating: 3, comment: 'Good, but the color was slightly different than pictured.'},
                    { name: 'Eve Adams', rating: 5, comment: 'Perfect gift! My friend loved it.'}
                ];
                if (mockReviews.length > 0) {
                    mockReviews.forEach(review => {
                        const reviewItem = document.createElement('div');
                        reviewItem.classList.add('review-item');
                        reviewItem.innerHTML = `
                            <div class="reviewer-name">${review.name}</div>
                            <div class="star-rating">${generateStarRating(review.rating)}</div>
                            <div class="review-comment">${review.comment}</div>
                        `;
                        productReviewsDiv.appendChild(reviewItem);
                    });
                } else {
                    productReviewsDiv.innerHTML = '<p>No reviews yet. Be the first to review!</p>';
                }

                // Populate Ratings section (Average based on mock reviews)
                const totalRatingSum = mockReviews.reduce((sum, review) => sum + review.rating, 0);
                const averageRating = mockReviews.length > 0 ? totalRatingSum / mockReviews.length : 0;
                productRatingsDiv.innerHTML = generateStarRating(averageRating) + ` (${averageRating.toFixed(1)} out of 5)`;


                productModal.style.display = 'flex';
                adjustOverlayPadding(); // Adjust padding when opening
            }
        }
    });

    // Helper function to generate star ratings
    function generateStarRating(rating) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                stars += '<i class="fas fa-star"></i>'; // Filled star
            } else if (i - 0.5 === rating && rating % 1 !== 0) { // Check for half star
                stars += '<i class="fas fa-star-half-alt"></i>'; // Half star
            }
            else {
                stars += '<i class="far fa-star"></i>'; // Empty star
            }
        }
        return stars;
    }


    closeModal.addEventListener('click', () => {
        productModal.style.display = 'none';
        currentProduct = null; // Clear current product when modal closes
    });

    // Add to cart functionality from product modal
    addToCartButton.addEventListener('click', () => {
        if (currentProduct) {
            addItemToCart(currentProduct);
            showAlert(`${currentProduct.name} added to cart!`, 'success');
            productModal.style.display = 'none';
        }
    });

    // --- Cart Overlay Buttons ---
    checkoutButton.addEventListener('click', () => {
        if (cart.length > 0) {
            showAlert('Proceeding to checkout!', 'success');
            cart = []; // Clear cart after "checkout"
            saveCart(); // Save empty cart
            renderCart(); // Update cart display
            cartOverlay.style.display = 'none'; // Close cart overlay
        } else {
            showAlert('Your cart is empty. Add items before checking out.', 'error');
        }
    });

    clearAllCartButton.addEventListener('click', () => {
        if (cart.length > 0) {
            cart = [];
            saveCart();
            renderCart();
            showAlert('Your cart has been cleared.', 'info');
        } else {
            showAlert('Your cart is already empty!', 'info');
        }
    });

    continueShoppingButton.addEventListener('click', () => {
        cartOverlay.style.display = 'none';
    });


    // --- Search Functionality ---
    searchButton.addEventListener('click', () => {
      const searchTerm = searchInput.value.toLowerCase().trim(); // Trim whitespace
      if (searchTerm) {
        const searchResults = products.filter(product =>
          product.name.toLowerCase().includes(searchTerm) ||
          product.description.toLowerCase().includes(searchTerm)
        );

        if (searchResults.length > 0) {
          displayProducts(1); // Display search results on page 1
          document.getElementById('pagination').style.display = 'none'; // Hide pagination for search results
          displaySearchResults(searchResults);
          searchOverlay.style.display = 'none';
          showAlert(`Found ${searchResults.length} results for "${searchTerm}"`, 'success');
        } else {
          showAlert(`No products found matching "${searchTerm}".`, 'error');
          // If no results, clear the collection grid and show a message
          document.getElementById('collection-grid').innerHTML = '<p style="text-align: center; color: #a76b09; font-size: 1.2em; padding: 50px;">No products found matching your search criteria. Please try a different term.</p>';
          document.getElementById('pagination').style.display = 'none'; // Hide pagination
        }
      } else {
        showAlert('Please enter a search term.', 'error');
      }
    });

    // Clear Search Button functionality
    clearSearchButton.addEventListener('click', () => {
        searchInput.value = ''; // Clear the search input
        displayProducts(1); // Display all products from page 1
        displayPagination(); // Show pagination again
        searchOverlay.style.display = 'none'; // Close search overlay
        showAlert('Search cleared. Showing all products.', 'info');
    });


    function displaySearchResults(results) {
      const collectionGrid = document.getElementById('collection-grid');
      collectionGrid.innerHTML = ''; // Clear existing products
      results.forEach(product => {
        const productHTML = `
            <div class="collection-item" data-aos="fade-up">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <a href="#" class="details-button" data-product-id="${product.id}">View Details</a>
            </div>
        `;
        collectionGrid.innerHTML += productHTML;
      });
      document.getElementById('pagination').style.display = 'none'; // Hide pagination for search results
      AOS.refresh();
    }

    // Call on load and resize
    adjustOverlayPadding();
    window.addEventListener('resize', adjustOverlayPadding);

    // Initial render of cart when page loads (if items are in localStorage)
    renderCart();
});