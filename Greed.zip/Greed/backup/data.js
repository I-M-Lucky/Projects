// data.js
const products = [
    {
        id: 1,
        name: "Elegance Timepiece 1",
        description: "Crafted with precision and adorned with diamonds. A timeless piece that speaks volumes about your sophistication. Featuring a luxurious leather strap and a scratch-resistant sapphire crystal.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 1500.00,
        details: {
            Material: "Gold Plated Stainless Steel",
            Movement: "Automatic",
            WaterResistance: "50m",
            Strap: "Genuine Leather"
        }
    },
    {
        id: 2,
        name: "Iconic Handbag 1",
        description: "A statement of style and sophistication. This handcrafted leather bag offers ample space with multiple compartments for all your essentials.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 850.00,
        details: {
            Material: "Genuine Italian Leather",
            Color: "Classic Black",
            Dimensions: "30x25x15cm",
            Closure: "Magnetic Snap"
        }
    },
    {
        id: 3,
        name: "Exclusive Fragrance 1",
        description: "Captivating scents that leave a lasting impression. A unique blend of floral and woody notes, perfect for any occasion. Presented in an elegant crystal bottle.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 120.00,
        details: {
            Volume: "100ml",
            Notes: "Jasmine, Sandalwood, Bergamot",
            Type: "Eau de Parfum"
        }
    },
    {
        id: 4,
        name: "Elegance Timepiece 2",
        description: "Crafted with precision and adorned with diamonds. A robust and elegant watch, ideal for daily wear or special events. Features a date display and luminous hands.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 1800.00,
        details: {
            Material: "Platinum & Sapphire",
            Movement: "Quartz",
            WaterResistance: "100m",
            Strap: "Titanium Bracelet"
        }
    },
    {
        id: 5,
        name: "Iconic Handbag 2",
        description: "A statement of style and sophistication. This chic handbag is versatile and can be carried by hand or worn as a shoulder bag. Comes with a dust bag for storage.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 790.00,
        details: {
            Material: "Vegan Leather",
            Color: "Burgundy",
            Dimensions: "25x20x10cm",
            Strap: "Detachable Shoulder Strap"
        }
    },
    {
        id: 6,
        name: "Exclusive Fragrance 2",
        description: "Captivating scents that leave a lasting impression. A light and refreshing scent, perfect for daytime use. Infused with natural essential oils.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 95.00,
        details: {
            Volume: "75ml",
            Notes: "Citrus, Green Tea, Cedarwood",
            Type: "Eau de Toilette"
        }
    },
    {
        id: 7,
        name: "Elegance Timepiece 3",
        description: "Crafted with precision and adorned with diamonds. A minimalist design with maximum impact. Features a precise Swiss movement.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 2100.00,
        details: {
            Material: "Rose Gold",
            Movement: "Swiss Quartz",
            WaterResistance: "30m",
            Strap: "Milanese Mesh"
        }
    },
    {
        id: 8,
        name: "Iconic Handbag 3",
        description: "A statement of style and sophistication. Designed for the modern woman, this bag combines practicality with high fashion. Features a secure zip closure.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 1100.00,
        details: {
            Material: "Embossed Leather",
            Color: "Deep Red",
            Dimensions: "35x28x18cm",
            Pockets: "Internal Zip Pocket"
        }
    },
    {
        id: 9,
        name: "Exclusive Fragrance 3",
        description: "Captivating scents that leave a lasting impression. A rich, warm, and sophisticated fragrance for evening wear. Comes in a luxurious velvet pouch.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 180.00,
        details: {
            Volume: "120ml",
            Notes: "Vanilla, Amber, Patchouli",
            Type: "Extrait de Parfum"
        }
    },
    {
        id: 10,
        name: "Elegance Timepiece 4",
        description: "Crafted with precision and adorned with diamonds. A sporty yet elegant watch with chronograph functions. Perfect for those with an active lifestyle.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 2500.00,
        details: {
            Material: "Carbon Fiber & Steel",
            Movement: "Automatic Chronograph",
            WaterResistance: "200m",
            Features: "Chronograph, Date"
        }
    },
    {
        id: 11,
        name: "Iconic Handbag 4",
        description: "A statement of style and sophistication. This versatile tote bag is perfect for daily use, fitting laptops and more. Features sturdy handles and a removable pouch.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 980.00,
        details: {
            Material: "Canvas & Leather Trim",
            Color: "Navy Blue",
            Dimensions: "40x30x16cm",
            Style: "Tote Bag"
        }
    },
    {
        id: 12,
        name: "Exclusive Fragrance 4",
        description: "Captivating scents that leave a lasting impression. A refreshing and invigorating aquatic fragrance. Ideal for summer days.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 110.00,
        details: {
            Volume: "90ml",
            Notes: "Sea Salt, Grapefruit, Vetiver",
            Type: "Eau de Parfum"
        }
    },
    {
        id: 13,
        name: "Elegance Timepiece 5",
        description: "Crafted with precision and adorned with diamonds. A vintage-inspired watch with modern mechanics. Limited edition piece.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 3200.00,
        details: {
            Material: "Stainless Steel",
            Movement: "Manual Winding",
            WaterResistance: "30m",
            Edition: "Limited Edition"
        }
    },
    {
        id: 14,
        name: "Iconic Handbag 5",
        description: "A statement of style and sophistication. This compact clutch is perfect for evening events. Features a detachable chain strap.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 600.00,
        details: {
            Material: "Satin & Crystal Embellishments",
            Color: "Silver",
            Dimensions: "20x12x5cm",
            Strap: "Detachable Chain"
        }
    },
    {
        id: 15,
        name: "Exclusive Fragrance 5",
        description: "Captivating scents that leave a lasting impression. A sweet and playful scent with hints of fruit and candy. For the young at heart.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 85.00,
        details: {
            Volume: "60ml",
            Notes: "Strawberry, Caramel, Musk",
            Type: "Eau de Toilette"
        }
    },
    {
        id: 16,
        name: "Elegance Timepiece 6",
        description: "Crafted with precision and adorned with diamonds. A sturdy diving watch built for performance. High visibility in all conditions.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 2800.00,
        details: {
            Material: "Marine-Grade Steel",
            Movement: "Automatic",
            WaterResistance: "300m",
            Bezel: "Unidirectional Rotating"
        }
    },
    {
        id: 17,
        name: "Iconic Handbag 6",
        description: "A statement of style and sophistication. A structured top-handle bag, perfect for professional settings. Elegant and spacious.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 1300.00,
        details: {
            Material: "Calf Leather",
            Color: "Cognac Brown",
            Dimensions: "32x22x14cm",
            Handles: "Double Top Handles"
        }
    },
    {
        id: 18,
        name: "Exclusive Fragrance 6",
        description: "Captivating scents that leave a lasting impression. A bold and masculine fragrance, ideal for the confident individual. Long-lasting and intense.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 160.00,
        details: {
            Volume: "100ml",
            Notes: "Leather, Tobacco, Spices",
            Type: "Eau de Parfum"
        }
    },
    {
        id: 19,
        name: "Elegance Timepiece 7",
        description: "Crafted with precision and adorned with diamonds. A slim and elegant dress watch. Understated luxury for formal occasions.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 1950.00,
        details: {
            Material: "White Gold",
            Movement: "Ultra-Thin Mechanical",
            WaterResistance: "30m",
            Dial: "Mother of Pearl"
        }
    },
    {
        id: 20,
        name: "Iconic Handbag 7",
        description: "A statement of style and sophistication. A unique bucket bag design with a drawstring closure. Modern and functional.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 720.00,
        details: {
            Material: "Suede & Leather",
            Color: "Olive Green",
            Dimensions: "28x20x20cm",
            Closure: "Drawstring"
        }
    },
    {
        id: 21,
        name: "Exclusive Fragrance 7",
        description: "Captivating scents that leave a lasting impression. A floral explosion, vibrant and long-lasting. Perfect for spring.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 130.00,
        details: {
            Volume: "80ml",
            Notes: "Rose, Peony, Freesia",
            Type: "Eau de Parfum"
        }
    },
    {
        id: 22,
        name: "Elegance Timepiece 8",
        description: "Crafted with precision and adorned with diamonds. A tourbillon watch, showcasing masterful horology. A true collector's item.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 15000.00,
        details: {
            Material: "Platinum & Diamonds",
            Movement: "Tourbillon Mechanical",
            WaterResistance: "30m",
            Features: "Open-heart Dial"
        }
    },
    {
        id: 23,
        name: "Iconic Handbag 8",
        description: "A statement of style and sophistication. A practical and stylish crossbody bag. Ideal for travel or busy days.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 650.00,
        details: {
            Material: "Nylon & Leather",
            Color: "Charcoal Grey",
            Dimensions: "22x18x8cm",
            Strap: "Adjustable Crossbody"
        }
    },
    {
        id: 24,
        name: "Exclusive Fragrance 8",
        description: "Captivating scents that leave a lasting impression. A mystical and oriental fragrance with deep, alluring notes. Long-lasting.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 190.00,
        details: {
            Volume: "100ml",
            Notes: "Oud, Incense, Myrrh",
            Type: "Extrait de Parfum"
        }
    },
    {
        id: 25,
        name: "Elegance Timepiece 9",
        description: "Crafted with precision and adorned with diamonds. A classic pilot watch with a clear, readable dial. Functional and stylish.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 2000.00,
        details: {
            Material: "Stainless Steel",
            Movement: "Automatic",
            WaterResistance: "100m",
            Dial: "Black with Luminous Markers"
        }
    },
    {
        id: 26,
        name: "Iconic Handbag 9",
        description: "A statement of style and sophistication. A charming mini bag, perfect for carrying just the essentials. Adorned with a delicate chain strap.",
        image: "https://image.made-in-china.com/2f0j00qCWYgnMkZioG/Wholesale-Handbag-Small-Shoulder-Bag-Purses-Ladies-Luxury-Bags-Women-Handbags-for-Lady-Wholesales-Distributor.webp",
        price: 550.00,
        details: {
            Material: "Quilted Leather",
            Color: "Cream",
            Dimensions: "18x10x5cm",
            Strap: "Chain Shoulder Strap"
        }
    },
    {
        id: 27,
        name: "Exclusive Fragrance 9",
        description: "Captivating scents that leave a lasting impression. A fresh and green fragrance, reminiscent of a spring garden. Light and airy.",
        image: "https://c.ndtvimg.com/2021-03/vfe70nq_perfumes650_625x300_08_March_21.jpg",
        price: 105.00,
        details: {
            Volume: "75ml",
            Notes: "Green Apple, Lily of the Valley, Musk",
            Type: "Eau de Toilette"
        }
    },
    {
        id: 28,
        name: "Elegance Timepiece 10",
        description: "Crafted with precision and adorned with diamonds. A skeleton watch, showcasing its intricate inner workings. A true conversation piece.",
        image: "https://vrimlo.com/cdn/shop/files/main-image-6_84c75103-e1e4-4692-b28d-14adae67fc29.jpg?v=1726600169",
        price: 4500.00,
        details: {
            Material: "Titanium",
            Movement: "Automatic Skeleton",
            WaterResistance: "50m",
            Dial: "Open-worked"
        }
    }
];

export default products;