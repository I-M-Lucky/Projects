// Movie Data
const movies = {
    trending: [
        { id: 1, title: "Avengers: Endgame", year: 2019, rating: 8.4, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://rukminim2.flixcart.com/image/850/1000/kv5kfww0/wall-decoration/a/t/e/avengers-endgame-marvel-cinematic-universe-marvel-comics-movie-original-imag846zqncggb8t.jpeg?q=20&crop=false", overview: "After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos' actions and restore balance to the universe.", trailer: "https://www.youtube.com/embed/TcMBFSGVi1c" },
        { id: 2, title: "Spider-Man: No Way Home", year: 2021, rating: 8.2, genre: ["Action", "Adventure", "Fantasy"], poster: "https://m.media-amazon.com/images/M/MV5BMmFiZGZjMmEtMTA0Ni00MzA2LTljMTYtZGI2MGJmZWYzZTQ2XkEyXkFqcGc@._V1_.jpg", overview: "With Spider-Man's identity now revealed, Peter asks Doctor Strange for help. When a spell goes wrong, dangerous foes from other worlds start to appear, forcing Peter to discover what it truly means to be Spider-Man.", trailer: "https://www.youtube.com/embed/JfVOs4VSpmA" },
        { id: 3, title: "Dune", year: 2021, rating: 8.0, genre: ["Adventure", "Sci-Fi"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/Dune_%282021_film%29.jpg/250px-Dune_%282021_film%29.jpg", overview: "Feature adaptation of Frank Herbert's science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset and most vital element in the galaxy.", trailer: "https://www.youtube.com/embed/n9xhJrPXop4" },
        { id: 4, title: "The Batman", year: 2022, rating: 7.9, genre: ["Action", "Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BMmU5NGJlMzAtMGNmOC00YjJjLTgyMzUtNjAyYmE4Njg5YWMyXkEyXkFqcGc@._V1_.jpg", overview: "When a sadistic serial killer begins murdering key political figures in Gotham, Batman is forced to investigate the city's hidden corruption and question his family's involvement.", trailer: "https://www.youtube.com/embed/mqqft2x_Aa4" },
        { id: 5, title: "Top Gun: Maverick", year: 2022, rating: 8.3, genre: ["Action", "Drama"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/1/13/Top_Gun_Maverick_Poster.jpg/250px-Top_Gun_Maverick_Poster.jpg", overview: "After more than thirty years of service as one of the Navy's top aviators, Pete Mitchell is where he belongs, pushing the envelope as a courageous test pilot and dodging the advancement in rank that would ground him.", trailer: "https://www.youtube.com/embed/giXco2jaZ_4" },
        { id: 6, title: "Black Panther: Wakanda Forever", year: 2022, rating: 7.2, genre: ["Action", "Adventure", "Drama"], poster: "https://upload.wikimedia.org/wikipedia/en/3/3b/Black_Panther_Wakanda_Forever_poster.jpg", overview: "The people of Wakanda fight to protect their home from intervening world powers as they mourn the death of King T'Challa.", trailer: "https://www.youtube.com/embed/_Z3QKkl1WyM" },
        { id: 7, title: "Everything Everywhere All at Once", year: 2022, rating: 8.1, genre: ["Action", "Adventure", "Comedy"], poster: "https://m.media-amazon.com/images/M/MV5BOWNmMzAzZmQtNDQ1NC00Nzk5LTkyMmUtNGI2N2NkOWM4MzEyXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A middle-aged Chinese immigrant is swept up into an insane adventure in which she alone can save existence by exploring other universes connecting with the lives she could have led.", trailer: "https://www.youtube.com/embed/wxN1T1uxQ2g" },
        { id: 8, title: "Avatar: The Way of Water", year: 2022, rating: 7.6, genre: ["Action", "Adventure", "Fantasy"], poster: "https://m.media-amazon.com/images/M/MV5BNmQxNjZlZTctMWJiMC00NGMxLWJjNTctNTFiNjA1Njk3ZDQ5XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na'vi race to protect their home.", trailer: "https://www.youtube.com/embed/d9MyW72ELq0" },
        { id: 9, title: "Jurassic World Dominion", year: 2022, rating: 5.6, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BNzIxMjYwNDEwN15BMl5BanBnXkFtZTgwMzk5MDI3NTM@._V1_FMjpg_UX1000_.jpg", overview: "Four years after the destruction of Isla Nublar, dinosaurs now live and hunt alongside humans all over the world. This fragile balance will reshape the future and determine, once and for all, whether human beings are to remain the apex predators on a planet they now share with history's most fearsome creatures.", trailer: "https://www.youtube.com/embed/fb5ELWi-ekk" },
        { id: 10, title: "Doctor Strange in the Multiverse of Madness", year: 2022, rating: 6.9, genre: ["Action", "Adventure", "Fantasy"], poster: "https://upload.wikimedia.org/wikipedia/en/1/17/Doctor_Strange_in_the_Multiverse_of_Madness_poster.jpg", overview: "Doctor Strange teams up with a mysterious teenage girl from his dreams who can travel across multiverses, to battle multiple threats, including other-universe versions of himself, which threaten to wipe out millions across the multiverse.", trailer: "https://www.youtube.com/embed/aWzlQ2N6qqg" },
        { id: 11, title: "The Northman", year: 2022, rating: 7.0, genre: ["Action", "Adventure", "Drama"], poster: "https://upload.wikimedia.org/wikipedia/en/8/8c/The_Northman.png", overview: "A young Viking prince is on a quest to avenge his father's murder.", trailer: "https://www.youtube.com/embed/oMSdFM12hOw" },
        { id: 12, title: "Bullet Train", year: 2022, rating: 7.3, genre: ["Action", "Comedy", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/1/13/Bullet_Train_%28poster%29.jpeg", overview: "Five assassins aboard a swiftly-moving bullet train find out that their missions have something in common.", trailer: "https://www.youtube.com/embed/0IOsk2Vlc4o" }
    ],
    newReleases: [
        { id: 13, title: "John Wick: Chapter 4", year: 2023, rating: 8.5, genre: ["Action", "Crime", "Thriller"], poster: "https://images.justwatch.com/poster/304195811/s718/john-wick-chapter-4.jpg", overview: "John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.", trailer: "https://www.youtube.com/embed/qEVUtrk8_B4" },
        { id: 14, title: "Creed III", year: 2023, rating: 7.1, genre: ["Drama", "Sport"], poster: "https://m.media-amazon.com/images/M/MV5BOWY0MTRmY2YtMzBlYi00NjlkLThkZWYtMmE2NzJiZmIzODFkXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "After dominating the boxing world, Adonis Creed has been thriving in both his career and family life. When a childhood friend and former boxing prodigy resurfaces, the face-off is more than just a fight.", trailer: "https://www.youtube.com/embed/AHmCH7iB_IM" },
        { id: 15, title: "Ant-Man and the Wasp: Quantumania", year: 2023, rating: 6.1, genre: ["Action", "Adventure", "Comedy"], poster: "https://m.media-amazon.com/images/M/MV5BMThkYWY5ZjQtYjJlMS00MDFmLWFkYzEtODEzZjg5YWFmMGY4XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "Scott Lang and Hope Van Dyne are dragged into the Quantum Realm, along with Hope's parents and Scott's daughter Cassie. Together they must find a way to escape, but what secrets is Hope's mother hiding? And who is the mysterious Kang?", trailer: "https://www.youtube.com/embed/ZnV6QfHy4Dk" },
        { id: 16, title: "Shazam! Fury of the Gods", year: 2023, rating: 6.1, genre: ["Action", "Adventure", "Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/f/fb/Shazam%21_Fury_of_the_Gods_%282023%29_Main_Poster.png", overview: "Billy Batson and his foster siblings, who transform into superheroes by saying \"Shazam!\", are forced to get back into action and fight the Daughters of Atlas, who they must stop from using a weapon that could destroy the world.", trailer: "https://www.youtube.com/embed/AIc671o9yCI" },
        { id: 17, title: "Scream VI", year: 2023, rating: 6.5, genre: ["Horror", "Mystery", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/c/c9/Scream_VI_poster.jpg", overview: "In the next installment, the survivors of the Ghostface killings leave Woodsboro behind and start a fresh chapter in New York City.", trailer: "https://www.youtube.com/embed/h74AXqw4Opc" },
        { id: 18, title: "65", year: 2023, rating: 5.4, genre: ["Action", "Adventure", "Drama"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/c/c4/65_film_teaser_poster.jpg/250px-65_film_teaser_poster.jpg", overview: "An astronaut crash lands on a mysterious planet only to discover he's not alone.", trailer: "https://www.youtube.com/embed/bHXejJq5vr0" },
        { id: 19, title: "Cocaine Bear", year: 2023, rating: 6.1, genre: ["Comedy", "Crime", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMjg3MmNiNWQtOWI1OS00MjE2LWFhYzYtMWY0NWRhZmVkMGFiXkEyXkFqcGc@._V1_.jpg", overview: "An oddball group of cops, criminals, tourists and teens converge on a Georgia forest where a huge black bear goes on a murderous rampage after unintentionally ingesting cocaine.", trailer: "https://www.youtube.com/embed/DuWEEKeJLMI" },
        { id: 20, title: "M3GAN", year: 2023, rating: 6.4, genre: ["Horror", "Sci-Fi", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BYjU1ZWMxYTUtNzQ1ZC00ZTcxLTg0NTMtMzY1ZmQyZjhmYjMyXkEyXkFqcGc@._V1_.jpg", overview: "A robotics engineer at a toy company builds a life-like doll that begins to take on a life of its own.", trailer: "https://www.youtube.com/embed/BRb4U99OU80" },
        { id: 21, title: "Knock at the Cabin", year: 2023, rating: 6.1, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMzU1ODIzYjAtNjUzNi00YmNjLWI5ZDAtNDgzOWY3MDU1OThlXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "While vacationing at a remote cabin, a young girl and her two fathers are taken hostage by four armed strangers who demand that the family make an unthinkable choice to avert the apocalypse.", trailer: "https://www.youtube.com/embed/5yQ6Sv2HUFU" },
        { id: 22, title: "Magic Mike's Last Dance", year: 2023, rating: 5.5, genre: ["Comedy", "Drama", "Romance"], poster: "https://upload.wikimedia.org/wikipedia/en/5/5d/Magic_Mike_Last_Dance_Poster.png", overview: "Mike Lane takes to the stage again after a lengthy hiatus, following a business deal that went bust, leaving him broke and taking bartender gigs in Florida.", trailer: "https://www.youtube.com/embed/1KflDtJzG5w" },
        { id: 21, title: "Knock at the Cabin", year: 2023, rating: 6.1, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMzU1ODIzYjAtNjUzNi00YmNjLWI5ZDAtNDgzOWY3MDU1OThlXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "While vacationing at a remote cabin, a young girl and her two fathers are taken hostage by four armed strangers who demand that the family make an unthinkable choice to avert the apocalypse.", trailer: "https://www.youtube.com/embed/5yQ6Sv2HUFU" },
        { id: 21, title: "Knock at the Cabin", year: 2023, rating: 6.1, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMzU1ODIzYjAtNjUzNi00YmNjLWI5ZDAtNDgzOWY3MDU1OThlXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "While vacationing at a remote cabin, a young girl and her two fathers are taken hostage by four armed strangers who demand that the family make an unthinkable choice to avert the apocalypse.", trailer: "https://www.youtube.com/embed/5yQ6Sv2HUFU" }

    ],
    popularMovies: [
        { id: 23, title: "The Shawshank Redemption", year: 1994, rating: 9.3, genre: ["Drama"], poster: "https://m.media-amazon.com/images/I/71QykliX-0S._AC_UF1000,1000_QL80_.jpg", overview: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.", trailer: "https://www.youtube.com/embed/6hB3S9bIaco" },
        { id: 24, title: "The Godfather", year: 1972, rating: 9.2, genre: ["Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BNGEwYjgwOGQtYjg5ZS00Njc1LTk2ZGEtM2QwZWQ2NjdhZTE5XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.", trailer: "https://www.youtube.com/embed/sY1S34973zA" },
        { id: 25, title: "The Dark Knight", year: 2008, rating: 9.0, genre: ["Action", "Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg", overview: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.", trailer: "https://www.youtube.com/embed/EXeTwQWrcwY" },
        { id: 26, title: "Pulp Fiction", year: 1994, rating: 8.9, genre: ["Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BYTViYTE3ZGQtNDBlMC00ZTAyLTkyODMtZGRiZDg0MjA2YThkXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.", trailer: "https://www.youtube.com/embed/s7EdQ4FqbhY" },
        { id: 27, title: "Fight Club", year: 1999, rating: 8.8, genre: ["Drama"], poster: "https://m.media-amazon.com/images/M/MV5BOTgyOGQ1NDItNGU3Ny00MjU3LTg2YWEtNmEyYjBiMjI1Y2M5XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "An insomniac office worker and a devil-may-care soapmaker form an underground fight club that evolves into something much, much more.", trailer: "https://www.youtube.com/embed/qtRKdVHc-cE" },
        { id: 28, title: "Inception", year: 2010, rating: 8.8, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_FMjpg_UX1000_.jpg", overview: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.", trailer: "https://www.youtube.com/embed/YoHD9XEInc0" },
        { id: 29, title: "The Matrix", year: 1999, rating: 8.7, genre: ["Action", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BN2NmN2VhMTQtMDNiOS00NDlhLTliMjgtODE2ZTY0ODQyNDRhXkEyXkFqcGc@._V1_.jpg", overview: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.", trailer: "https://www.youtube.com/embed/vKQi3bBA1y8" },
        { id: 30, title: "Goodfellas", year: 1990, rating: 8.7, genre: ["Biography", "Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BN2E5NzI2ZGMtY2VjNi00YTRjLWI1MDUtZGY5OWU1MWJjZjRjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "The story of Henry Hill and his life in the mob, covering his relationship with his wife Karen Hill and his mob partners Jimmy Conway and Tommy DeVito in the Italian-American crime syndicate.", trailer: "https://www.youtube.com/embed/qo5jJpHtI1Y" },
        { id: 31, title: "The Silence of the Lambs", year: 1991, rating: 8.6, genre: ["Crime", "Drama", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BNDdhOGJhYzctYzYwZC00YmI2LWI0MjctYjg4ODdlMDExYjBlXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A young F.B.I. cadet must receive the help of an incarcerated and manipulative cannibal killer to help catch another serial killer, a madman who skins his victims.", trailer: "https://www.youtube.com/embed/W6Mm8Sbe__o" },
        { id: 32, title: "Interstellar", year: 2014, rating: 8.6, genre: ["Adventure", "Drama", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BYzdjMDAxZGItMjI2My00ODA1LTlkNzItOWFjMDU5ZDJlYWY3XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.", trailer: "https://www.youtube.com/embed/zSWdZVtXT7E" },
        { id: 32, title: "Interstellar", year: 2014, rating: 8.6, genre: ["Adventure", "Drama", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BYzdjMDAxZGItMjI2My00ODA1LTlkNzItOWFjMDU5ZDJlYWY3XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.", trailer: "https://www.youtube.com/embed/zSWdZVtXT7E" },
        { id: 32, title: "Interstellar", year: 2014, rating: 8.6, genre: ["Adventure", "Drama", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BYzdjMDAxZGItMjI2My00ODA1LTlkNzItOWFjMDU5ZDJlYWY3XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.", trailer: "https://www.youtube.com/embed/zSWdZVtXT7E" }

    ],
    tvShows: [
        { id: 33, title: "Game of Thrones", year: "2011-2019", rating: 9.2, genre: ["Action", "Adventure", "Drama"], poster: "https://resizing.flixster.com/ajtANROYYdtHssw6m0iLLlSY9Rw=/fit-in/705x460/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p8681514_b_v8_aa.jpg", overview: "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia.", trailer: "https://www.youtube.com/embed/KPLWWIOCOOQ" },
        { id: 34, title: "Breaking Bad", year: "2008-2013", rating: 9.5, genre: ["Crime", "Drama", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMzU5ZGYzNmQtMTdhYy00OGRiLTg0NmQtYjVjNzliZTg1ZGE4XkEyXkFqcGc@._V1_.jpg", overview: "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.", trailer: "https://www.youtube.com/embed/HhesaQXLuRY" },
        { id: 35, title: "Stranger Things", year: "2016-Present", rating: 8.7, genre: ["Drama", "Fantasy", "Horror"], poster: "https://m.media-amazon.com/images/M/MV5BMjg2NmM0MTEtYWY2Yy00NmFlLTllNTMtMjVkZjEwMGVlNzdjXkEyXkFqcGc@._V1_.jpg", overview: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.", trailer: "https://www.youtube.com/embed/b9EkMc79ZSU" },
        { id: 36, title: "The Last of Us", year: "2023-Present", rating: 8.9, genre: ["Action", "Adventure", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BYWI3ODJlMzktY2U5NC00ZjdlLWE1MGItNWQxZDk3NWNjN2RhXkEyXkFqcGc@._V1_.jpg", overview: "After a global pandemic destroys civilization, a hardened survivor takes charge of a 14-year-old girl who may be humanity's last hope.", trailer: "https://www.youtube.com/embed/uLtkt8BonwM" },
        { id: 37, title: "The Mandalorian", year: "2019-Present", rating: 8.7, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://static.wikia.nocookie.net/starwars/images/f/fa/MandoS3Poster.jpg", overview: "The travels of a lone bounty hunter in the outer reaches of the galaxy, far from the authority of the New Republic.", trailer: "https://www.youtube.com/embed/eW7Twd85m2g" },
        { id: 38, title: "House of the Dragon", year: "2022-Present", rating: 8.5, genre: ["Action", "Adventure", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BM2QzMGVkNjUtN2Y4Yi00ODMwLTg3YzktYzUxYjJlNjFjNDY1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "The story of the House of Targaryen set 200 years before the events of Game of Thrones.", trailer: "https://www.youtube.com/embed/DotnJ7tTA34" },
        { id: 39, title: "The Witcher", year: "2019-Present", rating: 8.0, genre: ["Action", "Adventure", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BMTQ5MDU5MTktMDZkMy00NDU1LWIxM2UtODg5OGFiNmRhNDBjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.", trailer: "https://www.youtube.com/embed/ndl1W4ltcmg" },
        { id: 40, title: "Wednesday", year: "2022-Present", rating: 8.2, genre: ["Comedy", "Crime", "Fantasy"], poster: "https://m.media-amazon.com/images/M/MV5BZGQxYWFlNzgtODZjMS00YmM5LWEzZWMtOGVmODMzYjIyODZiXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "Follows Wednesday Addams' years as a student, when she attempts to master her emerging psychic ability, thwart a killing spree, and solve the mystery that affected her family 25 years ago.", trailer: "https://www.youtube.com/embed/Di310WS8zLk" },
        { id: 41, title: "The Boys", year: "2019-Present", rating: 8.7, genre: ["Action", "Comedy", "Crime"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/1/14/The_Boys_Season_2.jpg/250px-The_Boys_Season_2.jpg", overview: "A group of vigilantes set out to take down corrupt superheroes who abuse their superpowers.", trailer: "https://www.youtube.com/embed/tcrNsIaQkb4" },
        { id: 42, title: "Peaky Blinders", year: "2013-2022", rating: 8.8, genre: ["Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BOGM0NGY3ZmItOGE2ZC00OWIxLTk0N2EtZWY4Yzg3ZDlhNGI3XkEyXkFqcGc@._V1_.jpg", overview: "A notorious gang in 1919 Birmingham, England, is led by the fierce Tommy Shelby, a crime boss set on moving up in the world no matter the cost.", trailer: "https://www.youtube.com/embed/oVzVdvGIC7U" },
        { id: 42, title: "Peaky Blinders", year: "2013-2022", rating: 8.8, genre: ["Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BOGM0NGY3ZmItOGE2ZC00OWIxLTk0N2EtZWY4Yzg3ZDlhNGI3XkEyXkFqcGc@._V1_.jpg", overview: "A notorious gang in 1919 Birmingham, England, is led by the fierce Tommy Shelby, a crime boss set on moving up in the world no matter the cost.", trailer: "https://www.youtube.com/embed/oVzVdvGIC7U" },
        { id: 42, title: "Peaky Blinders", year: "2013-2022", rating: 8.8, genre: ["Crime", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BOGM0NGY3ZmItOGE2ZC00OWIxLTk0N2EtZWY4Yzg3ZDlhNGI3XkEyXkFqcGc@._V1_.jpg", overview: "A notorious gang in 1919 Birmingham, England, is led by the fierce Tommy Shelby, a crime boss set on moving up in the world no matter the cost.", trailer: "https://www.youtube.com/embed/oVzVdvGIC7U" }

    ],
    action: [
        { id: 43, title: "Mad Max: Fury Road", year: 2015, rating: 8.1, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BZDRkODJhOTgtOTc1OC00NTgzLTk4NjItNDgxZDY4YjlmNDY2XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search for her homeland with the aid of a group of female prisoners, a psychotic worshiper, and a drifter named Max.", trailer: "https://www.youtube.com/embed/hEJnMQG9ev8" },
        { id: 44, title: "Die Hard", year: 1988, rating: 8.2, genre: ["Action", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/c/ca/Die_Hard_%281988_film%29_poster.jpg/250px-Die_Hard_%281988_film%29_poster.jpg", overview: "A New York City police officer tries to save his estranged wife and several others taken hostage by terrorists during a Christmas party at the Nakatomi Plaza in Los Angeles.", trailer: "https://www.youtube.com/embed/jaJuwKCmJbY" },
        { id: 45, title: "Mission: Impossible - Fallout", year: 2018, rating: 7.7, genre: ["Action", "Adventure", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BOGZjNDlkMTYtMTJkZi00OTkzLWI4NDEtYTA2ODQyMjcwYTdlXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "Ethan Hunt and his IMF team, along with some familiar allies, race against time after a mission gone wrong.", trailer: "https://www.youtube.com/embed/wb49-oV0F78" },
        { id: 46, title: "John Wick", year: 2014, rating: 7.4, genre: ["Action", "Crime", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/9/98/John_Wick_TeaserPoster.jpg/250px-John_Wick_TeaserPoster.jpg", overview: "An ex-hitman comes out of retirement to track down the gangsters who killed his dog and stole his car.", trailer: "https://www.youtube.com/embed/2AUmvWm5ZDQ" },
        { id: 47, title: "The Raid", year: 2011, rating: 7.6, genre: ["Action", "Crime", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/9/9a/The_Raid_2011_poster.jpg", overview: "A S.W.A.T. team becomes trapped in a tenement run by a ruthless mobster and his army of killers and thugs.", trailer: "https://www.youtube.com/embed/m6Q7KnXpNOg" },
        { id: 48, title: "Kill Bill: Vol. 1", year: 2003, rating: 8.2, genre: ["Action", "Crime", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BZmMyYzJlZmYtY2I3NC00NjAyLTkyZWItZjdjZDI1YTYyYTEwXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "After awakening from a four-year coma, a former assassin wreaks vengeance on the team of assassins who betrayed her.", trailer: "https://www.youtube.com/embed/7kSuas6mRpk" },
        { id: 49, title: "Gladiator", year: 2000, rating: 8.5, genre: ["Action", "Adventure", "Drama"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/f/fb/Gladiator_%282000_film_poster%29.png/250px-Gladiator_%282000_film_poster%29.png", overview: "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.", trailer: "https://www.youtube.com/embed/P5ieIbInFpg" },
        { id: 50, title: "The Bourne Identity", year: 2002, rating: 7.9, genre: ["Action", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BYTk1ZTcyMWMtMWUxYS00MmEzLTlmODYtOTk1MGRjOTg1ZjlmXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A man is picked up by a fishing boat, bullet-riddled and suffering from amnesia, before racing to elude assassins and attempting to regain his memory.", trailer: "https://www.youtube.com/embed/cD-uQreIwEk" },
        { id: 51, title: "The Dark Knight Rises", year: 2012, rating: 8.4, genre: ["Action", "Adventure"], poster: "https://m.media-amazon.com/images/M/MV5BMTk4ODQzNDY3Ml5BMl5BanBnXkFtZTcwODA0NTM4Nw@@._V1_FMjpg_UX1000_.jpg", overview: "Eight years after the Joker's reign of anarchy, Batman, with the help of the enigmatic Catwoman, is forced from his exile to save Gotham City from the brutal guerrilla terrorist Bane.", trailer: "https://www.youtube.com/embed/GokKUqLcvD8" },
        { id: 52, title: "Furiosa", year: 1981, rating: 7.6, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BNTcwYWE1NTYtOWNiYy00NzY3LWIwY2MtNjJmZDkxNDNmOWE1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "In the post-apocalyptic Australian wasteland, a cynical drifter agrees to help a small, gasoline-rich community escape a band of bandits.", trailer: "https://youtu.be/XJMuhwVlca4?t=2" },
        { id: 52, title: "Furiosa", year: 1981, rating: 7.6, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BNTcwYWE1NTYtOWNiYy00NzY3LWIwY2MtNjJmZDkxNDNmOWE1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "In the post-apocalyptic Australian wasteland, a cynical drifter agrees to help a small, gasoline-rich community escape a band of bandits.", trailer: "https://youtu.be/XJMuhwVlca4?t=2" },
        { id: 52, title: "Furiosa", year: 1981, rating: 7.6, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BNTcwYWE1NTYtOWNiYy00NzY3LWIwY2MtNjJmZDkxNDNmOWE1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "In the post-apocalyptic Australian wasteland, a cynical drifter agrees to help a small, gasoline-rich community escape a band of bandits.", trailer: "https://youtu.be/XJMuhwVlca4?t=2" }

    ],
    comedy: [
        { id: 53, title: "Superbad", year: 2007, rating: 7.6, genre: ["Comedy"], poster: "https://m.media-amazon.com/images/M/MV5BNjk0MzdlZGEtNTRkOC00ZDRiLWJkYjAtMzUzYTRiNzk1YTViXkEyXkFqcGc@._V1_.jpg", overview: "Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to stage a booze-soaked party goes awry.", trailer: "https://www.youtube.com/embed/MNpoTxeydiY" },
        { id: 54, title: "The Hangover", year: 2009, rating: 7.7, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/b/b9/Hangoverposter09.jpg/250px-Hangoverposter09.jpg", overview: "Three buddies wake up from a bachelor party in Las Vegas, with no memory of the previous night and the bachelor missing. They make their way around the city in order to find their friend before his wedding.", trailer: "https://www.youtube.com/embed/tcdUhdOlz9M" },
        { id: 55, title: "Bridesmaids", year: 2011, rating: 6.8, genre: ["Comedy", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMjAyOTMyMzUxNl5BMl5BanBnXkFtZTcwODI4MzE0NA@@._V1_FMjpg_UX1000_.jpg", overview: "Competition between the maid of honor and a bridesmaid, over who is the bride's best friend, threatens to upend the life of an out-of-work pastry chef.", trailer: "https://www.youtube.com/embed/FNppLrmdyug" },
        { id: 56, title: "Anchorman: The Legend of Ron Burgundy", year: 2004, rating: 7.1, genre: ["Comedy"], poster: "https://m.media-amazon.com/images/M/MV5BMTQ2MzYwMzk5Ml5BMl5BanBnXkFtZTcwOTI4NzUyMw@@._V1_.jpg", overview: "In the 1970s, San Diego anchorman Ron Burgundy is the top dog in local TV, but that's all about to change when ambitious reporter Veronica Corningstone arrives as a new employee.", trailer: "https://www.youtube.com/embed/NJQ4qEWm9lU" },
        { id: 57, title: "Step Brothers", year: 2008, rating: 6.9, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/d/d9/StepbrothersMP08.jpg", overview: "Two aimless middle-aged losers still living at home are forced against their will to become roommates when their parents marry.", trailer: "https://www.youtube.com/embed/8QKE96wZTkw" },
        { id: 58, title: "Dumb and Dumber", year: 1994, rating: 7.3, genre: ["Comedy"], poster: "https://m.media-amazon.com/images/M/MV5BNGQxZDA1MmMtYWQ1Ni00NTJmLTljMjgtZWVmODllODVhMzgyXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "The cross-country adventures of two good-hearted but incredibly stupid friends.", trailer: "https://www.youtube.com/embed/l13yPhimE3o" },
        { id: 59, title: "Airplane!", year: 1980, rating: 7.7, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/2/21/Airplane%21_%281980_film%29.jpg", overview: "A man afraid to fly must ensure that a plane lands safely after the pilots become sick.", trailer: "https://www.youtube.com/embed/HMnVs287AJ4" },
        { id: 60, title: "The Grand Budapest Hotel", year: 2014, rating: 8.1, genre: ["Adventure", "Comedy", "Crime"], poster: "https://m.media-amazon.com/images/M/MV5BMzM5NjUxOTEyMl5BMl5BanBnXkFtZTgwNjEyMDM0MDE@._V1_FMjpg_UX1000_.jpg", overview: "A writer encounters the owner of an aging high-class hotel, who tells him of his early years serving as a lobby boy in the hotel's glorious years under an exceptional concierge.", trailer: "https://www.youtube.com/embed/1Fg5iWmQjwk" },
        { id: 61, title: "Groundhog Day", year: 1993, rating: 8.0, genre: ["Comedy", "Fantasy", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BOWE3MjQ3ZDAtNDQ2MC00YjBjLTk0ZWYtNjQ0YzQ4YWE3YTEyXkEyXkFqcGc@._V1_.jpg", overview: "A weatherman finds himself inexplicably living the same day over and over again.", trailer: "https://www.youtube.com/embed/tSVeDx9fk60" },
        { id: 62, title: "Office Space", year: 1999, rating: 7.7, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/8/8e/Office_space_poster.jpg", overview: "Three company workers who hate their jobs decide to rebel against their greedy boss.", trailer: "https://www.youtube.com/embed/dMIrlP61Z9s" },
        { id: 62, title: "Office Space", year: 1999, rating: 7.7, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/8/8e/Office_space_poster.jpg", overview: "Three company workers who hate their jobs decide to rebel against their greedy boss.", trailer: "https://www.youtube.com/embed/dMIrlP61Z9s" },
        { id: 62, title: "Office Space", year: 1999, rating: 7.7, genre: ["Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/8/8e/Office_space_poster.jpg", overview: "Three company workers who hate their jobs decide to rebel against their greedy boss.", trailer: "https://www.youtube.com/embed/dMIrlP61Z9s" }
    ],
    sciFi: [
        { id: 63, title: "Blade Runner 2049", year: 2017, rating: 8.0, genre: ["Drama", "Mystery", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BNzA1Njg4NzYxOV5BMl5BanBnXkFtZTgwODk5NjU3MzI@._V1_.jpg", overview: "A young blade runner's discovery of a long-buried secret leads him to track down former blade runner Rick Deckard, who's been missing for thirty years.", trailer: "https://www.youtube.com/embed/gCcx85zbxz4" },
        { id: 64, title: "Arrival", year: 2016, rating: 7.9, genre: ["Drama", "Mystery", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMTExMzU0ODcxNDheQTJeQWpwZ15BbWU4MDE1OTI4MzAy._V1_FMjpg_UX1000_.jpg", overview: "A linguist works with the military to communicate with alien lifeforms after twelve mysterious spacecraft appear around the world.", trailer: "https://www.youtube.com/embed/tFMo3UJ4B4g" },
        { id: 65, title: "Ex Machina", year: 2014, rating: 7.7, genre: ["Drama", "Sci-Fi", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMTUxNzc0OTIxMV5BMl5BanBnXkFtZTgwNDI3NzU2NDE@._V1_FMjpg_UX1000_.jpg", overview: "A young programmer is selected to participate in a ground-breaking experiment in synthetic intelligence by evaluating the human qualities of a highly advanced humanoid A.I.", trailer: "https://www.youtube.com/embed/EoQuVnKhxaM" },
        { id: 66, title: "The Martian", year: 2015, rating: 8.0, genre: ["Adventure", "Drama", "Sci-Fi"], poster: "https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p10980706_p_v13_ar.jpg", overview: "An astronaut becomes stranded on Mars after his team assume him dead, and must rely on his ingenuity to find a way to signal to Earth that he is alive.", trailer: "https://www.youtube.com/embed/ej3ioOneTy8" },
        { id: 67, title: "Annihilation", year: 2018, rating: 6.8, genre: ["Adventure", "Drama", "Horror"], poster: "https://m.media-amazon.com/images/M/MV5BMTk2Mjc2NzYxNl5BMl5BanBnXkFtZTgwMTA2OTA1NDM@._V1_.jpg", overview: "A biologist signs up for a dangerous, secret expedition into a mysterious zone where the laws of nature don't apply.", trailer: "https://www.youtube.com/embed/89OP78l9oF0" },
        { id: 68, title: "Looper", year: 2012, rating: 7.4, genre: ["Action", "Sci-Fi", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMTg5NTA3NTg4NF5BMl5BanBnXkFtZTcwNTA0NDYzOA@@._V1_FMjpg_UX1000_.jpg", overview: "In 2074, when the mob wants to get rid of someone, the target is sent 30 years into the past, where a hired gun awaits. Someone is sent back to kill the man who invented time travel.", trailer: "https://www.youtube.com/embed/2iQuhsmtfHw" },
        { id: 69, title: "District 9", year: 2009, rating: 7.9, genre: ["Action", "Sci-Fi", "Thriller"], poster: "https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p177953_p_v8_ae.jpg", overview: "An extraterrestrial race forced to live in slum-like conditions on Earth suddenly finds a kindred spirit in a government agent who is exposed to their biotechnology.", trailer: "https://www.youtube.com/embed/DyLUwOcR5pk" },
        { id: 70, title: "Children of Men", year: 2006, rating: 7.9, genre: ["Drama", "Sci-Fi", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMzVlNzZhNDEtNzc4Yy00ZGQ4LTkyNjAtYzhiZDMxNGM4Y2I4XkEyXkFqcGdeQW1pYnJ5YW50._V1_.jpg", overview: "In 2027, in a chaotic world in which women have become somehow infertile, a former activist agrees to help transport a miraculously pregnant woman to a sanctuary at sea.", trailer: "https://www.youtube.com/embed/2VT2apoX90o" },
        { id: 71, title: "Snowpiercer", year: 2013, rating: 7.1, genre: ["Action", "Drama", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMmM1ODg0MjktY2U3ZC00ZDc4LTkxMjAtMzljY2VkZmI3MmE5XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "In a future where a failed climate-change experiment has killed all life except for the survivors who boarded the Snowpiercer, a train that travels around the globe, a new class system emerges.", trailer: "https://www.youtube.com/embed/6L-_eZ5tN8g" },
        { id: 72, title: "Edge of Tomorrow", year: 2014, rating: 7.9, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMTc5OTk4MTM3M15BMl5BanBnXkFtZTgwODcxNjg3MDE@._V1_.jpg", overview: "A soldier fighting aliens gets to relive the same day over and over again, the day restarting every time he dies.", trailer: "https://www.youtube.com/embed/vw61gCe2oqI" },
        { id: 72, title: "Edge of Tomorrow", year: 2014, rating: 7.9, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMTc5OTk4MTM3M15BMl5BanBnXkFtZTgwODcxNjg3MDE@._V1_.jpg", overview: "A soldier fighting aliens gets to relive the same day over and over again, the day restarting every time he dies.", trailer: "https://www.youtube.com/embed/vw61gCe2oqI" },
        { id: 72, title: "Edge of Tomorrow", year: 2014, rating: 7.9, genre: ["Action", "Adventure", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMTc5OTk4MTM3M15BMl5BanBnXkFtZTgwODcxNjg3MDE@._V1_.jpg", overview: "A soldier fighting aliens gets to relive the same day over and over again, the day restarting every time he dies.", trailer: "https://www.youtube.com/embed/vw61gCe2oqI" }

    ],
    horror: [
        { id: 73, title: "The Shining", year: 1980, rating: 8.4, genre: ["Drama", "Horror"], poster: "https://m.media-amazon.com/images/I/81ff3jlaJDL._AC_UF1000,1000_QL80_.jpg", overview: "A family heads to an isolated hotel for the winter where a sinister presence influences the father into violence, while his psychic son sees horrific forebodings from both past and future.", trailer: "https://www.youtube.com/embed/S014oGZiSdI" },
        { id: 74, title: "Hereditary", year: 2018, rating: 7.3, genre: ["Drama", "Horror", "Mystery"], poster: "https://resizing.flixster.com/5WRccfENIEAkvSolNXxeEryNVmU=/fit-in/705x460/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/NowShowing/182669/182669_ab.jpg", overview: "A grieving family is haunted by tragic and disturbing occurrences.", trailer: "https://www.youtube.com/embed/V6wWKNij_1M" },
        { id: 75, title: "Get Out", year: 2017, rating: 7.7, genre: ["Horror", "Mystery", "Thriller"], poster: "https://upload.wikimedia.org/wikipedia/en/a/a3/Get_Out_poster.png", overview: "A young African-American visits his white girlfriend's parents for the weekend, where his simmering uneasiness about their reception of him eventually reaches a boiling point.", trailer: "https://www.youtube.com/embed/sRfnevzM9kQ" },
        { id: 76, title: "A Quiet Place", year: 2018, rating: 7.5, genre: ["Drama", "Horror", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMjI0MDMzNTQ0M15BMl5BanBnXkFtZTgwMTM5NzM3NDM@._V1_FMjpg_UX1000_.jpg", overview: "In a post-apocalyptic world, a family is forced to live in silence while hiding from monsters with ultra-sensitive hearing.", trailer: "https://www.youtube.com/embed/WR7cc5t7tv8" },
        { id: 77, title: "The Conjuring", year: 2013, rating: 7.5, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMTM3NjA1NDMyMV5BMl5BanBnXkFtZTcwMDQzNDMzOQ@@._V1_.jpg", overview: "Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse.", trailer: "https://www.youtube.com/embed/k10ETZ41q5o" },
        { id: 78, title: "It", year: 2017, rating: 7.3, genre: ["Horror"], poster: "https://m.media-amazon.com/images/M/MV5BZGZmOTZjNzUtOTE4OS00OGM3LWJiNGEtZjk4Yzg2M2Q1YzYxXkEyXkFqcGc@._V1_.jpg", overview: "In the summer of 1989, a group of bullied kids band together to destroy a shape-shifting monster, which disguises itself as a clown and preys on the children of Derry, their small Maine town.", trailer: "https://www.youtube.com/embed/xKJmEC5ieOk" },
        { id: 79, title: "The Babadook", year: 2014, rating: 6.8, genre: ["Drama", "Horror"], poster: "https://m.media-amazon.com/images/M/MV5BMTk0NzMzODc2NF5BMl5BanBnXkFtZTgwOTYzNTM1MzE@._V1_.jpg", overview: "A single mother, plagued by the violent death of her husband, battles with her son's fear of a monster lurking in the house, but soon discovers a sinister presence all around her.", trailer: "https://www.youtube.com/embed/k5WQZzDRVtw" },
        { id: 80, title: "The Witch", year: 2015, rating: 7.0, genre: ["Horror", "Mystery"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/b/bf/The_Witch_poster.png/250px-The_Witch_poster.png", overview: "A family in 1630s New England is torn apart by the forces of witchcraft, black magic and possession.", trailer: "https://www.youtube.com/embed/iQXmlf3Sefg" },
        { id: 81, title: "Sinister", year: 2012, rating: 6.8, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMjI5MTg1Njg0Ml5BMl5BanBnXkFtZTcwNzg2Mjc4Nw@@._V1_.jpg", overview: "Washed-up true-crime writer Ellison Oswalt finds a box of home movies that suggest the murder he's currently researching is the work of a serial killer whose work dates back to the 1960s.", trailer: "https://www.youtube.com/embed/_kbQAJR9YWQ" },
        { id: 82, title: "The Descent", year: 2005, rating: 7.2, genre: ["Adventure", "Horror", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMjA5NzQ1NTgwNV5BMl5BanBnXkFtZTcwNjUxMzUzMw@@._V1_FMjpg_UX1000_.jpg", overview: "A caving expedition goes horribly wrong, as the explorers become trapped and ultimately pursued by a strange breed of predators.", trailer: "https://www.youtube.com/embed/3Vk6OZSlaYk" },
        { id: 81, title: "Sinister", year: 2012, rating: 6.8, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMjI5MTg1Njg0Ml5BMl5BanBnXkFtZTcwNzg2Mjc4Nw@@._V1_.jpg", overview: "Washed-up true-crime writer Ellison Oswalt finds a box of home movies that suggest the murder he's currently researching is the work of a serial killer whose work dates back to the 1960s.", trailer: "https://www.youtube.com/embed/_kbQAJR9YWQ" },
        { id: 81, title: "Sinister", year: 2012, rating: 6.8, genre: ["Horror", "Mystery", "Thriller"], poster: "https://m.media-amazon.com/images/M/MV5BMjI5MTg1Njg0Ml5BMl5BanBnXkFtZTcwNzg2Mjc4Nw@@._V1_.jpg", overview: "Washed-up true-crime writer Ellison Oswalt finds a box of home movies that suggest the murder he's currently researching is the work of a serial killer whose work dates back to the 1960s.", trailer: "https://www.youtube.com/embed/_kbQAJR9YWQ" }

    ],
    romance: [
        { id: 83, title: "The Notebook", year: 2004, rating: 7.8, genre: ["Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BZjE0ZjgzMzYtMTAxYi00NGMzLThmZDktNzFlMzA2MWRmYWQ0XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated because of their social differences.", trailer: "https://www.youtube.com/embed/FC6biTjEyZw" },
        { id: 84, title: "Pride & Prejudice", year: 2005, rating: 7.8, genre: ["Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTA1NDQ3NTcyOTNeQTJeQWpwZ15BbWU3MDA0MzA4MzE@._V1_.jpg", overview: "Sparks fly when spirited Elizabeth Bennet meets single, rich, and proud Mr. Darcy. But Mr. Darcy reluctantly finds himself falling in love with a woman beneath his class. Can each overcome their own pride and prejudice?", trailer: "https://www.youtube.com/embed/1dYv5u6v55Y" },
        { id: 85, title: "La La Land", year: 2016, rating: 8.0, genre: ["Comedy", "Drama", "Music"], poster: "https://m.media-amazon.com/images/M/MV5BMzUzNDM2NzM2MV5BMl5BanBnXkFtZTgwNTM3NTg4OTE@._V1_.jpg", overview: "While navigating their careers in Los Angeles, a pianist and an actress fall in love while attempting to reconcile their aspirations for the future.", trailer: "https://www.youtube.com/embed/0pdqf4P9MB8" },
        { id: 86, title: "Before Sunrise", year: 1995, rating: 8.1, genre: ["Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BZDZhZmI1ZTUtYWI3NC00NTMwLTk3NWMtNDc0OGNjM2I0ZjlmXkEyXkFqcGc@._V1_.jpg", overview: "A young man and woman meet on a train in Europe, and wind up spending one evening together in Vienna. Unfortunately, both know that this will probably be their only night together.", trailer: "https://www.youtube.com/embed/9v6X-Dytlko" },
        { id: 87, title: "Eternal Sunshine of the Spotless Mind", year: 2004, rating: 8.3, genre: ["Drama", "Romance", "Sci-Fi"], poster: "https://m.media-amazon.com/images/M/MV5BMTY4NzcwODg3Nl5BMl5BanBnXkFtZTcwNTEwOTMyMw@@._V1_.jpg", overview: "When their relationship turns sour, a couple undergoes a medical procedure to have each other erased from their memories.", trailer: "https://www.youtube.com/embed/07-QBnEkgXU" },
        { id: 88, title: "500 Days of Summer", year: 2009, rating: 7.7, genre: ["Comedy", "Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTk5MjM4OTU1OV5BMl5BanBnXkFtZTcwODkzNDIzMw@@._V1_.jpg", overview: "After being dumped by the girl he believes to be his soulmate, hopeless romantic Tom Hansen reflects on their relationship to try and figure out where things went wrong and how he can win her back.", trailer: "https://www.youtube.com/embed/PsD0NpFSADM" },
        { id: 89, title: "Crazy, Stupid, Love", year: 2011, rating: 7.4, genre: ["Comedy", "Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTg2MjkwMTM0NF5BMl5BanBnXkFtZTcwMzc4NDg2NQ@@._V1_FMjpg_UX1000_.jpg", overview: "A middle-aged husband's life changes dramatically when his wife asks him for a divorce. He seeks to rediscover his manhood with the help of a newfound friend, Jacob, learning to pick up girls at bars.", trailer: "https://www.youtube.com/embed/8iCwtxJejik" },
        { id: 90, title: "Silver Linings Playbook", year: 2012, rating: 7.7, genre: ["Comedy", "Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTM2MTI5NzA3MF5BMl5BanBnXkFtZTcwODExNTc0OA@@._V1_.jpg", overview: "After a stint in a mental institution, former teacher Pat Solitano moves back in with his parents and tries to reconcile with his ex-wife. Things get more challenging when Pat meets Tiffany, a mysterious girl with problems of her own.", trailer: "https://www.youtube.com/embed/Lj5_FhLaaQQ" },
        { id: 91, title: "The Fault in Our Stars", year: 2014, rating: 7.7, genre: ["Drama", "Romance"], poster: "https://m.media-amazon.com/images/I/817tHNcyAgL.jpg", overview: "Two teenage cancer patients begin a life-affirming journey to visit a reclusive author in Amsterdam.", trailer: "https://www.youtube.com/embed/9ItBvH5J6ss" },
        { id: 92, title: "About Time", year: 2013, rating: 7.8, genre: ["Comedy", "Drama", "Fantasy"], poster: "https://m.media-amazon.com/images/M/MV5BMTA1ODUzMDA3NzFeQTJeQWpwZ15BbWU3MDgxMTYxNTk@._V1_FMjpg_UX1000_.jpg", overview: "At the age of 21, Tim discovers he can travel in time and change what happens and has happened in his own life. His decision to make his world a better place by getting a girlfriend turns out not to be as easy as you might think.", trailer: "https://www.youtube.com/embed/T7A810duHvw" },
        { id: 90, title: "Silver Linings Playbook", year: 2012, rating: 7.7, genre: ["Comedy", "Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTM2MTI5NzA3MF5BMl5BanBnXkFtZTcwODExNTc0OA@@._V1_.jpg", overview: "After a stint in a mental institution, former teacher Pat Solitano moves back in with his parents and tries to reconcile with his ex-wife. Things get more challenging when Pat meets Tiffany, a mysterious girl with problems of her own.", trailer: "https://www.youtube.com/embed/Lj5_FhLaaQQ" },
        { id: 90, title: "Silver Linings Playbook", year: 2012, rating: 7.7, genre: ["Comedy", "Drama", "Romance"], poster: "https://m.media-amazon.com/images/M/MV5BMTM2MTI5NzA3MF5BMl5BanBnXkFtZTcwODExNTc0OA@@._V1_.jpg", overview: "After a stint in a mental institution, former teacher Pat Solitano moves back in with his parents and tries to reconcile with his ex-wife. Things get more challenging when Pat meets Tiffany, a mysterious girl with problems of her own.", trailer: "https://www.youtube.com/embed/Lj5_FhLaaQQ" }

    ],
    animation: [
        { id: 93, title: "Spirited Away", year: 2001, rating: 8.6, genre: ["Animation", "Adventure", "Family"], poster: "https://m.media-amazon.com/images/M/MV5BNTEyNmEwOWUtYzkyOC00ZTQ4LTllZmUtMjk0Y2YwOGUzYjRiXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg", overview: "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits, and where humans are changed into beasts.", trailer: "https://www.youtube.com/embed/ByXuk9QqQkk" },
        { id: 94, title: "Toy Story", year: 1995, rating: 8.3, genre: ["Animation", "Adventure", "Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/1/13/Toy_Story.jpg", overview: "A cowboy doll is profoundly threatened and jealous when a new spaceman figure supplants him as top toy in a boy's room.", trailer: "https://www.youtube.com/embed/v-PjgYDrg70" },
        { id: 95, title: "The Lion King", year: 1994, rating: 8.5, genre: ["Animation", "Adventure", "Drama"], poster: "https://m.media-amazon.com/images/M/MV5BMjIwMjE1Nzc4NV5BMl5BanBnXkFtZTgwNDg4OTA1NzM@._V1_FMjpg_UX1000_.jpg", overview: "Lion prince Simba and his father are targeted by his bitter uncle, who wants to ascend the throne himself.", trailer: "https://www.youtube.com/embed/4sj1MT05lAA" },
        { id: 96, title: "Spider-Man: Into the Spider-Verse", year: 2018, rating: 8.4, genre: ["Animation", "Action", "Adventure"], poster: "https://m.media-amazon.com/images/M/MV5BMjMwNDkxMTgzOF5BMl5BanBnXkFtZTgwNTkwNTQ3NjM@._V1_FMjpg_UX1000_.jpg", overview: "Teen Miles Morales becomes the Spider-Man of his universe, and must join with five spider-powered individuals from other dimensions to stop a threat for all realities.", trailer: "https://www.youtube.com/embed/g4Hbz2jLxvQ" },
        { id: 97, title: "Howl's Moving Castle", year: 2004, rating: 8.2, genre: ["Animation", "Adventure", "Family"], poster: "https://platform.polygon.com/wp-content/uploads/sites/2/chorus/uploads/chorus_asset/file/20007566/GHI_HowlsMovingCastle_Select1.jpg", overview: "When an unconfident young woman is cursed with an old body by a spiteful witch, her only chance of breaking the spell lies with a self-indulgent yet insecure young wizard and his companions in his legged, walking castle.", trailer: "https://www.youtube.com/embed/iwROgK94zcM" },
        { id: 98, title: "Wall-E", year: 2008, rating: 8.4, genre: ["Animation", "Adventure", "Family"], poster: "https://m.media-amazon.com/images/M/MV5BMjExMTg5OTU0NF5BMl5BanBnXkFtZTcwMjMxMzMzMw@@._V1_FMjpg_UX1000_.jpg", overview: "In the distant future, a small waste-collecting robot inadvertently embarks on a space journey that will ultimately decide the fate of mankind.", trailer: "https://www.youtube.com/embed/CZ1CATNbXg0" },
        { id: 99, title: "Up", year: 2009, rating: 8.3, genre: ["Animation", "Adventure", "Comedy"], poster: "https://upload.wikimedia.org/wikipedia/en/0/05/Up_%282009_film%29.jpg", overview: "78-year-old Carl Fredricksen travels to Paradise Falls in his house equipped with balloons, inadvertently taking a young stowaway.", trailer: "https://www.youtube.com/embed/qas5lWp7_R0" },
        { id: 100, title: "Coco", year: 2017, rating: 8.4, genre: ["Animation", "Adventure", "Comedy"], poster: "https://lumiere-a.akamaihd.net/v1/images/p_coco_19736_fd5fa537.jpeg?region=0%2C0%2C540%2C810", overview: "Aspiring musician Miguel, confronted with his family's ancestral ban on music, enters the Land of the Dead to find his great-great-grandfather, a legendary singer.", trailer: "https://www.youtube.com/embed/Ga6RYejo6Hk" },
        { id: 101, title: "Your Name", year: 2016, rating: 8.4, genre: ["Animation", "Drama", "Fantasy"], poster: "https://upload.wikimedia.org/wikipedia/en/0/0b/Your_Name_poster.png", overview: "Two strangers find themselves linked in a bizarre way. When a connection forms, will distance be the only thing to keep them apart?", trailer: "https://www.youtube.com/embed/xU47nhruN-Q" },
        { id: 102, title: "The Incredibles", year: 2004, rating: 8.0, genre: ["Animation", "Action", "Adventure"], poster: "https://m.media-amazon.com/images/M/MV5BMTY5OTU0OTc2NV5BMl5BanBnXkFtZTcwMzU4MDcyMQ@@._V1_.jpg", overview: "A family of undercover superheroes, while trying to live the quiet suburban life, are forced into action to save the world.", trailer: "https://www.youtube.com/embed/eZbzbC9285I" },
        { id: 102, title: "Demon Slayer-Mugen Train Arc", year: 2004, rating: 8.0, genre: ["Animation", "Action", "Adventure"], poster: "https://m.media-amazon.com/images/M/MV5BYmEwNjIyNDItNjVjOS00NjM5LWJlOGUtODI4YWFlZmQ0MjJmXkEyXkFqcGc@._V1_.jpg", overview: "A family of undercover superheroes, while trying to live the quiet suburban life, are forced into action to save the world.", trailer: "https://www.youtube.com/embed/eZbzbC9285I" },
        { id: 102, title: "Suzume", year: 2004, rating: 8.0, genre: ["Animation", "Action", "Adventure"], poster: "https://upload.wikimedia.org/wikipedia/en/thumb/7/7f/Suzume_no_Tojimari_poster.jpg/250px-Suzume_no_Tojimari_poster.jpg", overview: "A family of undercover superheroes, while trying to live the quiet suburban life, are forced into action to save the world.", trailer: "https://youtu.be/5pTcio2hTSw?feature=shared" }


    ]
};

// ========== Dummy Movie Data ==========
importScriptsIfNeeded();
const sections = ['trending', 'newReleases', 'popularMovies', 'tvShows', 'action', 'comedy', 'sciFi', 'horror', 'romance', 'animation'];

// ========== DOM Elements ==========
const elements = {
    searchInput: document.getElementById('search-input'),
    searchBtn: document.getElementById('search-btn'),
    searchResults: document.getElementById('search-results'),
    loginBtn: document.getElementById('login-btn'),
    logoutBtn: document.getElementById('logout-btn'),
    profileDropdown: document.getElementById('profile-dropdown'),
    loginModal: document.getElementById('login-modal'),
    signupModal: document.getElementById('signup-modal'),
    watchlistModal: document.getElementById('watchlist-modal'),
    loginForm: document.getElementById('login-form'),
    signupForm: document.getElementById('signup-form'),
    signupLink: document.getElementById('signup-link'),
    loginLink: document.getElementById('login-link'),
    profileImage: document.getElementById('profile-image'),
    previewImg: document.getElementById('preview-img'),
    videoModal: document.getElementById('video-modal'),
    videoFrame: document.getElementById('video-frame'),
    closeModal: document.querySelector('.close-modal'),
    closeLogin: document.querySelector('.close-login'),
    closeSignup: document.querySelector('.close-signup'),
    closeWatchlist: document.querySelector('.close-watchlist'),
    slides: document.querySelectorAll('.slide'),
    prevSlide: document.querySelector('.prev-slide'),
    nextSlide: document.querySelector('.next-slide'),
    dots: document.querySelectorAll('.dot'),
    watchlistGrid: document.getElementById('watchlist-grid'),
    watchlistEmpty: document.getElementById('watchlist-empty'),
};

let currentUser = null;
let userWatchlist = [];
let currentSlide = 0;
let slideInterval;

document.addEventListener('DOMContentLoaded', initApp);

function initApp() {
    loadUserFromStorage();
    setupEventListeners();
    initSlider();
    renderAllMovieSections();
    initMoreInfoModal();
}

function importScriptsIfNeeded() {
    // No-op placeholder
}

function setupEventListeners() {
    elements.loginBtn?.addEventListener('click', () => elements.loginModal.style.display = 'flex');
    elements.logoutBtn?.addEventListener('click', logout);
    elements.closeLogin?.addEventListener('click', () => elements.loginModal.style.display = 'none');
    elements.closeSignup?.addEventListener('click', () => elements.signupModal.style.display = 'none');
    elements.closeWatchlist?.addEventListener('click', () => elements.watchlistModal.style.display = 'none');
    elements.closeModal?.addEventListener('click', closeVideoModal);
    elements.signupLink?.addEventListener('click', (e) => {
        e.preventDefault();
        elements.loginModal.style.display = 'none';
        elements.signupModal.style.display = 'flex';
    });
    elements.loginLink?.addEventListener('click', (e) => {
        e.preventDefault();
        elements.signupModal.style.display = 'none';
        elements.loginModal.style.display = 'flex';
    });
    elements.profileImage?.addEventListener('change', previewProfileImage);
    elements.loginForm?.addEventListener('submit', handleLogin);
    elements.signupForm?.addEventListener('submit', handleSignup);
    elements.searchInput?.addEventListener('input', handleSearch);
    elements.searchBtn?.addEventListener('click', () => elements.searchInput.focus());

    document.querySelectorAll('.info-btn')?.forEach((btn, index) => {
        btn.addEventListener('click', () => openMoreInfoModal(movies.trending[index]));
    });

    document.querySelectorAll('.play-btn')?.forEach((btn, index) => {
        btn.addEventListener('click', () => openVideoModal(movies.trending[index].trailer));
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.user-section') && elements.profileDropdown.style.display === 'block') {
            elements.profileDropdown.style.display = 'none';
        }
        if (e.target === elements.loginModal) elements.loginModal.style.display = 'none';
        if (e.target === elements.signupModal) elements.signupModal.style.display = 'none';
        if (e.target === elements.watchlistModal) elements.watchlistModal.style.display = 'none';
        if (e.target === elements.videoModal) closeVideoModal();

        const infoModal = document.getElementById('more-info-modal');
        if (e.target === infoModal) infoModal.style.display = 'none';
    });
}

function initMoreInfoModal() {
    const modal = document.createElement('div');
    modal.id = 'more-info-modal';
    modal.style.display = 'none';
    modal.innerHTML = `
        <div class="info-modal-content" style="background:#111; color:#fff; padding:30px; border-radius:10px; max-width:800px; width:90%; max-height:80vh; overflow-y:auto; position:relative; transition: all 0.3s ease-in-out;">
            <span class="close-info" style="position:absolute; top:10px; right:20px; font-size:30px; cursor:pointer;">&times;</span>
            <div class="info-body"></div>
        </div>`;
    modal.classList.add('video-modal');
    modal.style.justifyContent = 'center';
    modal.style.alignItems = 'center';
    document.body.appendChild(modal);

    modal.querySelector('.close-info').addEventListener('click', () => modal.style.display = 'none');
}

function openMoreInfoModal(movie) {
    const modal = document.getElementById('more-info-modal');
    const body = modal.querySelector('.info-body');
    body.innerHTML = `
        <div style="display:flex; flex-wrap:wrap; gap:20px; align-items:flex-start;">
            <img src="${movie.poster}" style="width:200px; border-radius:10px;">
            <div style="flex:1;">
                <h2>${movie.title}</h2>
                <p><strong>Year:</strong> ${movie.year}</p>
                <p><strong>Genres:</strong> ${movie.genre.join(', ')}</p>
                <p><strong>Rating:</strong> ★ ${movie.rating}</p>
                <p style="margin-top:10px;">${movie.overview}</p>
                <button class="info-trailer-btn" style="margin-top:15px; padding:10px 20px; font-weight:bold; background:#e50914; color:#fff; border:none; border-radius:5px; cursor:pointer;">▶ Watch Trailer</button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
    const trailerBtn = body.querySelector('.info-trailer-btn');
    trailerBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        openVideoModal(movie.trailer);
    });
}

// ========== Auth ==========
function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    if (!email || !password) return alert('Please fill all fields');

    currentUser = {
        email,
        username: email.split('@')[0],
        profilePic: 'img/default-profile.png'
    };
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    updateUserUI();
    elements.loginModal.style.display = 'none';
    elements.loginForm.reset();
}

function handleSignup(e) {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirm = document.getElementById('signup-confirm').value;

    if (!username || !email || !password || !confirm) return alert('Fill all fields');
    if (password !== confirm) return alert('Passwords do not match');

    currentUser = {
        email,
        username,
        profilePic: elements.previewImg?.src || 'img/logo2.png'
    };
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    updateUserUI();
    elements.signupModal.style.display = 'none';
    elements.signupForm.reset();
}

function logout() {
    currentUser = null;
    userWatchlist = [];
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userWatchlist');
    updateUserUI();
}

function loadUserFromStorage() {
    const storedUser = localStorage.getItem('currentUser');
    const storedWatchlist = localStorage.getItem('userWatchlist');
    if (storedUser) {
        currentUser = JSON.parse(storedUser);
        userWatchlist = storedWatchlist ? JSON.parse(storedWatchlist) : [];
        updateUserUI();
    }
}

function updateUserUI() {
    const usernameSpan = document.getElementById('username');
    const profilePic = document.getElementById('profile-pic');
    if (currentUser) {
        elements.loginBtn.style.display = 'none';
        elements.profileDropdown.style.display = 'block';
        usernameSpan.textContent = currentUser.username;
        profilePic.src = currentUser.profilePic;
    } else {
        elements.loginBtn.style.display = 'block';
        elements.profileDropdown.style.display = 'none';
    }
}

// ========== Movies ==========
function renderAllMovieSections() {
    sections.forEach(key => {
        const section = document.getElementById(key.replace(/[A-Z]/g, m => `-${m.toLowerCase()}`));
        const movieList = movies[key] || [];
        if (!section || movieList.length === 0) return;

        const grid = section.querySelector('.movie-grid');
        grid.innerHTML = movieList.map(movie => movieCardHTML(movie)).join('');
    });
}

function movieCardHTML(movie) {
    return `
    <div class="movie-card">
        <img class="movie-poster" src="${movie.poster}" alt="${movie.title}" onerror="this.src='img/default-movie.png'">
        <div class="movie-info">
            <h3 class="movie-title">${movie.title}</h3>
            <div class="movie-meta">
                <span class="movie-year">${movie.year}</span>
                <span class="movie-rating">★ ${movie.rating}</span>
            </div>
            <button onclick="openVideoModal('${movie.trailer}')">▶ Watch Trailer</button>
        </div>
    </div>
    `;
}

// ========== Search ==========
function handleSearch() {
    const query = elements.searchInput.value.trim().toLowerCase();
    if (!query) return elements.searchResults.style.display = 'none';

    const allMovies = Object.values(movies).flat();
    const results = allMovies.filter(m => m.title.toLowerCase().includes(query)).slice(0, 6);

    // ========== Search Result Click Handler ==========
 elements.searchResults.addEventListener('click', (e) => {
    const item = e.target.closest('.search-result-item');
    if (!item) return;

    const trailerUrl = item.dataset.trailer;
    if (trailerUrl) {
        openVideoModal(trailerUrl);
        elements.searchResults.style.display = 'none';
        elements.searchInput.value = '';
    }
});

    // Populate the search dropdown
    elements.searchResults.innerHTML = results.length
        ? results.map(m => `
            <div class="search-result-item" data-trailer="${m.trailer}">
                <img src="${m.poster}" alt="${m.title}">
                <div class="search-result-info">
                    <h4>${m.title}</h4>
                    <p>${m.year} • ${m.genre.join(', ')}</p>
                </div>
            </div>
        `).join('')
        : '<div class="search-result-item">No results found</div>';

    elements.searchResults.style.display = 'block';
}


// ========== Video Modal ==========
function openVideoModal(url) {
    const videoId = (url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/) || [])[1];
    if (!videoId) return;
    elements.videoFrame.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    elements.videoModal.style.display = 'flex';
}

function closeVideoModal() {
    elements.videoFrame.src = '';
    elements.videoModal.style.display = 'none';
}

// ========== Profile ==========
function previewProfileImage(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = event => elements.previewImg.src = event.target.result;
        reader.readAsDataURL(file);
    }
}

// ========== Slider ==========
function initSlider() {
    const total = elements.slides.length;
    if (!total) return;

    slideInterval = setInterval(() => changeSlide((currentSlide + 1) % total), 5000);
    elements.prevSlide?.addEventListener('click', () => changeSlide((currentSlide - 1 + total) % total));
    elements.nextSlide?.addEventListener('click', () => changeSlide((currentSlide + 1) % total));
    elements.dots.forEach((dot, i) => dot.addEventListener('click', () => changeSlide(i)));
}

function changeSlide(index) {
    elements.slides.forEach(s => s.classList.remove('active'));
    elements.dots.forEach(d => d.classList.remove('active'));
    elements.slides[index].classList.add('active');
    elements.dots[index].classList.add('active');
    currentSlide = index;
}


