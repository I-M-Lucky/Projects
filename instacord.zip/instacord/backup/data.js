// data.js
// This file provides the initial "database" for the application.
// In a real-world scenario, this data would come from a server API.

// --- DATA FOR GENERATING DEMO USERS ---

const firstNames = ["Liam", "Olivia", "Noah", "Emma", "Oliver", "Ava", "Elijah", "Charlotte", "William", "Sophia", "James", "Amelia", "Benjamin", "Isabella", "Lucas", "Mia", "Henry", "Evelyn", "Alexander", "Harper"];
const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"];
const sampleBios = [
    "Just living my best life.", "Explorer | Dreamer | Doer", "Coffee and confidence.",
    "Creating my own sunshine.", "Digital nomad on a journey.", "Spreading positivity.",
];

// A collection of profile picture URLs from Unsplash.
const profilePics = [
    "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80",
    "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=761&q=80",
    "https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80",
    "https://images.unsplash.com/photo-1527980965255-d3b416303d12?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80",
    "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
];

// A collection of post image URLs.
const postImages = [
    "https://i.pinimg.com/736x/37/58/1e/37581e92775d69807d5ce324d9a51dfb.jpg",
    "https://picfiles.alphacoders.com/656/thumb-1920-656002.jpg",
    "https://c4.wallpaperflare.com/wallpaper/120/746/436/anime-original-wallpaper-preview.jpg",
    "https://toolbox.finland.fi/wp-content/uploads/sites/2/2021/03/florian-olivo-mf23rf8xary-unsplash-736x414.jpg",
    "https://live.staticflickr.com/1852/30720417038_ebcd882218_c.jpg",
    "https://i.pinimg.com/736x/2a/97/d9/2a97d9dd99cceda780014b5a269c9b94.jpg",
];

// --- NEW DEMO GIFS "DATABASE" ---
const demoGifs = [
    { url: 'https://ultimateqa.com/wp-content/uploads/2018/09/2.-minions-clapping-and-super-excited-gif.gif', tags: ['shocked', 'wow', 'mind blown', 'woah'] },
    { url: 'https://media.tenor.com/l3v8zkUJEKkAAAAM/gojo-satoru.gif', tags: ['ok', 'peace', 'snap', 'done'] },
    { url: 'https://media.tenor.com/3yNUtUfO_mgAAAAM/cats-anime.gif', tags: ['ok', 'okay', 'deal', 'sounds good'] },
    { url: 'https://64.media.tumblr.com/b3426b755d9ce47a6edec261a7ee0251/913dd2f4f38dcdbc-a1/s500x750/ac3e6f02a24f97ed6f993ddffaf127d7480a5155.gifv', tags: ['kermit', 'typing', 'work', 'computer', 'stressed'] },
    { url: 'https://i.pinimg.com/originals/fd/17/51/fd175129e200299ec0dba35fcffd87fc.gif', tags: ['cat', 'meme', 'funny', 'vibe', 'dance'] },
    { url: 'https://media.tenor.com/kfXicpYoZMAAAAAM/anime-lily.gif', tags: ['homer', 'simpsons', 'hide', 'bush', 'awkward'] },
    { url: 'https://media.tenor.com/qs5pVKHIyTUAAAAM/kakashi-hatake-kakashi.gif', tags: ['happy', 'dance', 'excited', 'yay'] },
    { url: 'https://media.tenor.com/2SgtWqyQZBYAAAAM/like.gif', tags: ['thumbs up', 'good job', 'nice', 'great', 'ok'] },
    { url: 'https://media.tenor.com/emzi9a2GKA8AAAAM/oreki.gif', tags: ['popcorn', 'watching', 'drama', 'movie'] },
    { url: 'https://media.tenor.com/uDviGvD1FKAAAAAM/nyochio-d4dj.gif', tags: ['laugh', 'lol', 'funny', 'haha'] },
    { url: 'https://media.tenor.com/c59Df-MNG-QAAAAM/nobara-nobara-kugisaki.gif', tags: ['spongebob', 'waiting', 'bored', 'patrick'] },
    { url: 'https://c.tenor.com/jNi9LjM-dAQAAAAC/tenor.gif', tags: ['celebrate', 'party', 'yay', 'happy'] },
    { url: 'https://c.tenor.com/DkqIfxH2jr8AAAAd/tenor.gif', tags: ['what', 'confused', 'huh', 'question'] },
    { url: 'https://media.tenor.com/bjzxou1nfqkAAAAM/reloco-anime.gif', tags: ['cat', 'wink', 'cute', 'funny'] }
];

// --- NEW DEMO CRIPS "DATABASE" ---
const demoCrips = [
    {
        id: 1,
        videoUrl: 'https://storage.googleapis.com/gweb-gemini-cdn/gemini/uploads/a67e69028b547c044c242974242456ab313ea43c.mp4',
        userId: 10, // martinez
        caption: 'This is an amazing trick shot! 🤯',
        likes: [1, 2, 3, 4, 5, 8, 12, 15, 18, 20],
        comments: [ { userId: 2, text: "Wow!", reactions: {} }, { userId: 4, text: "Insane!", reactions: {} } ],
        audioName: 'Original Audio'
    },
    {
        id: 2,
        videoUrl: 'https://storage.googleapis.com/gweb-gemini-cdn/gemini/uploads/a67e69028b547c044c242974242456ab313ea43c.mp4',
        userId: 5, // oliverjones
        caption: 'Beautiful sunset view today. #sunset #nature',
        likes: [1, 5, 9, 13, 17],
        comments: [],
        audioName: 'lofi hip hop - beats to relax/study to'
    },
    {
        id: 3,
        videoUrl: 'https://storage.googleapis.com/gweb-gemini-cdn/gemini/uploads/a67e69028b547c044c242974242456ab313ea43c.mp4',
        userId: 8, // charlottedavis
        caption: 'My cute cat doing cute things 😻',
        likes: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24],
        comments: [ { userId: 1, text: "So cute!!", reactions: {} } ],
        audioName: 'Funny Cat Meows'
    },
    {
        id: 4,
        videoUrl: 'https://storage.googleapis.com/gweb-gemini-cdn/gemini/uploads/a67e69028b547c044c242974242456ab313ea43c.mp4',
        userId: 1, // liamsmith1
        caption: 'Cooking up a storm!',
        likes: [2, 3, 5, 7, 11, 13],
        comments: [],
        audioName: 'Upbeat Cooking Show Music'
    }
];


// --- GENERATED DEMO DATA ---

// `demoUsers`: An array to hold all user objects for the application.
const demoUsers = [];

// Loop to programmatically generate 50 demo users.
for (let i = 1; i <= 50; i++) {
    const user = {
        id: i,
        username: `${firstNames[i % firstNames.length].toLowerCase()}${lastNames[i % lastNames.length].toLowerCase()}${i}`,
        // By setting a complex, unknown password, we make demo users non-loginable,
        // forcing the real user to sign up. This makes the auth system feel more realistic.
        password: `very_secure_demo_password_${Math.random().toString(36)}`,
        fullName: `${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`,
        profilePic: profilePics[i % profilePics.length],
        bio: sampleBios[i % sampleBios.length],
        // Generate a random list of follower and following IDs.
        followers: Array.from({ length: Math.floor(Math.random() * 25) + 5 }, () => Math.floor(Math.random() * 50) + 1),
        following: Array.from({ length: Math.floor(Math.random() * 25) + 5 }, () => Math.floor(Math.random() * 50) + 1),
        notifications: [],
        // --- NEW PROPERTIES FOR FRIEND REQUEST SYSTEM ---
        isDemo: true,       // Mark demo users
        friendRequests: [], // Array of { from: userId, status: 'pending' }
        sentRequests: [],   // Array of { to: userId, status: 'pending' }
    };
    // Ensure users don't follow or are followed by themselves, and remove duplicates.
    user.followers = [...new Set(user.followers.filter(id => id !== i))];
    user.following = [...new Set(user.following.filter(id => id !== i))];
    demoUsers.push(user);
}

// --- IMPORTANT: Set a simple password for the first user for easy testing ---
demoUsers[0].password = "password"; // Login with username 'liamsmith1' and password 'password'


// `demoPosts`: An array to hold all post objects.
const demoPosts = [];
// Loop to generate 20 demo posts, assigning them to random users.
for (let i = 1; i <= 20; i++) {
    const postUser = demoUsers[Math.floor(Math.random() * demoUsers.length)];
    const postTags = [];
    if (i % 3 === 0 || i % 6 === 0) postTags.push('EldenRingDLC');
    if (i % 4 === 0) postTags.push('TechWeek2025');
    if (i % 2 === 0 || i % 5 === 0) postTags.push('AI');

    demoPosts.push({
        id: i,
        userId: postUser.id, // The ID of the user who created the post.
        imgUrl: postImages[i % postImages.length],
        caption: `Post number ${i} by ${postUser.username}. Enjoying the view!`,
        likes: Array.from({ length: Math.floor(Math.random() * 30) }, () => Math.floor(Math.random() * 50) + 1), // Array of user IDs who liked the post.
        tags: postTags, // New: Added tags to posts. Stored without '#'.
        comments: [ // Array of comment objects.
            { userId: demoUsers[Math.floor(Math.random() * demoUsers.length)].id, text: "Great shot!", reactions: { '👍': [1, 5, 10] } },
            { userId: demoUsers[Math.floor(Math.random() * demoUsers.length)].id, text: "Love this! ❤️", reactions: {} },
            { userId: postUser.id, type: 'gif', url: 'https://media1.tenor.com/m/y2mP-i4h4g4AAAAC/mind-blown-woah.gif', reactions: { '😂': [3, 4]} }
        ],
    });
}

// `demoChats`: An object representing the chat database.
// The keys are unique chat IDs, typically formed by combining the user IDs.
const demoChats = {
    "1-2": { // A direct message between user 1 and user 2.
        isGroup: false,
        members: [1, 2],
        messages: [
            { senderId: 2, text: "Hey! Just saw your new post.", ts: "1h", reactions: {} },
            { senderId: 1, text: "Thanks! Glad you liked it.", ts: "1h", reactions: { '❤️': [2]} }
        ]
    },
    "1-4": { // A direct message between user 1 and user 4.
        isGroup: false,
        members: [1, 4],
        messages: [
            { senderId: 4, text: "Are we still on for this weekend?", ts: "3h", reactions: {} },
            { senderId: 1, text: "Yes! Can't wait.", ts: "2h", reactions: {} }
        ]
    },
     // --- NEW DEMO GROUPS ---
    "group-1": {
        isGroup: true,
        ownerId: 1,
        groupName: "Elden Ring Fans",
        groupPic: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHJ1hfpGKaeZ4BDieMN-q3AXL8yO_rmn1Q7g&s",
        members: [1, 3, 5, 8, 11, 20],
        messages: [
            { senderId: 3, text: "The DLC is amazing!", reactions: {} },
            { senderId: 1, text: "I know right! Messmer is tough.", reactions: { '😮': [3, 5]} },
            { senderId: 8, text: "Anyone free to help me with a boss?", reactions: {} }
        ]
    },
    "group-2": {
        isGroup: true,
        ownerId: 2,
        groupName: "Tech Planners",
        groupPic: "https://i.pinimg.com/736x/37/58/1e/37581e92775d69807d5ce324d9a51dfb.jpg",
        members: [2, 4, 6, 10, 1], // Added user 1 for testing
        messages: [
             { senderId: 4, text: "Finalized the speaker list for #TechWeek2025", reactions: { '👍': [1, 2, 6] } },
             { senderId: 2, text: "Looks great, thanks for sharing!", reactions: {} }
        ]
    },
    "group-3": {
        isGroup: true,
        ownerId: 7,
        groupName: "AI Enthusiasts",
        groupPic: "https://picfiles.alphacoders.com/656/thumb-1920-656002.jpg",
        members: [7, 1, 9, 14, 18],
        messages: [
            { senderId: 9, text: "Did you guys see the latest paper on diffusion models?", reactions: {} },
            { senderId: 1, text: "Yeah, mind-blowing stuff.", reactions: {} },
            { senderId: 1, type: 'gif', url: 'https://media1.tenor.com/m/y2mP-i4h4g4AAAAC/mind-blown-woah.gif', reactions: { '😂': [9, 7]} }
        ]
    },
    "group-4": {
        isGroup: true,
        ownerId: 15,
        groupName: "Weekend Hikers",
        groupPic: "https://i.pinimg.com/236x/09/b3/3a/09b33ae1d7f365e3a89a9673817a84a5.jpg",
        members: [15, 1, 2, 19, 25, 30],
        messages: [
            { senderId: 19, text: "Weather looks good for Saturday morning.", reactions: {} },
            { senderId: 2, text: "Count me in!", reactions: {} }
        ]
    }
};


// `demoHashtags`: An array to hold all trending topics.
const demoHashtags = [
    { tag: '#EldenRingDLC', category: 'Gaming', posts: '302k' },
    { tag: '#TechWeek2025', category: 'Technology', posts: '155k' },
    { tag: '#AI', category: 'Technology', posts: '76k' },
];