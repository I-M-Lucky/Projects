// script.js
// This file contains the core logic for the InstaClone application.
// It handles state management, rendering UI components, user interactions, and routing.

// --- TEMPLATE FUNCTIONS ---
// These functions generate the HTML content for different parts of the application.
// They act as templates, making the rendering logic cleaner and more maintainable.

const getLoginPageHTML = () => `
    <div class="login-page">
        <div class="login-background"></div>
        <div class="login-form-container">
            <h1 class="login-title">InstaClone</h1>
            <p class="login-subtitle">Connect with friends and the world around you.</p>
            <form class="login-form" data-action="login">
                <div class="form-group"><input type="text" name="username" placeholder="Username or Email" required></div>
                <div class="form-group"><input type="password" name="password" placeholder="Password" required></div>
                <button type="submit" class="btn-primary login-btn">Log In</button>
            </form>
            <div class="login-divider"><span>OR</span></div>
            <button class="btn-social google" data-action="social-login"><i class="fab fa-google"></i> Continue with Google</button>
            <div class="auth-switcher">Don't have an account? <a href="#" data-action="show-signup">Sign Up</a></div>
        </div>
    </div>`;

const getSignupPageHTML = () => `
    <div class="login-page">
        <div class="login-background"></div>
        <div class="login-form-container">
            <h1 class="login-title">InstaClone</h1>
            <p class="login-subtitle">Sign up to see photos and videos from your friends.</p>
             <button class="btn-social google" data-action="social-login"><i class="fab fa-google"></i> Sign up with Google</button>
            <div class="login-divider"><span>OR</span></div>
            <form class="login-form" data-action="signup">
                <div class="form-group"><input type="text" name="fullName" placeholder="Full Name" required></div>
                <div class="form-group"><input type="text" name="username" placeholder="Username" required></div>
                <div class="form-group"><input type="password" name="password" placeholder="Password (min. 6 characters)" required></div>
                <div class="form-group"><input type="password" name="confirmPassword" placeholder="Confirm Password" required></div>
                <button type="submit" class="btn-primary login-btn">Sign Up</button>
            </form>
            <div class="auth-switcher">Have an account? <a href="#" data-action="show-login">Log In</a></div>
        </div>
    </div>`;

const getAppShellHTML = () => `
    <div class="top-left-logo-container">
        <a href="#" class="navbar-logo" data-action="navigate" data-path="/home">InstaClone</a>
    </div>
    <!-- NEW GROUP NAV PANEL -->
    <nav class="group-nav-panel" id="group-nav-panel"></nav>
    <!-- NEW TRENDING POSTS SLIDER -->
    <div class="trending-posts-slider-container" id="trending-posts-slider-container"></div>
    <header class="top-navbar">
        <div class="navbar-center">
            <ul class="nav-links">
                <li><a href="#" class="nav-link active" data-action="navigate" data-path="/home" title="Home"><i class="fas fa-home"></i></a></li>
                <li><a href="#" class="nav-link" data-action="open-search" title="Search"><i class="fas fa-search"></i></a></li>
                <li><a href="#" class="nav-link" data-action="create-post" title="Create Post"><i class="fas fa-plus-square"></i></a></li>
                <li><a href="#" class="nav-link" data-action="navigate" data-path="/reels" title="Reels"><i class="fas fa-video"></i></a></li>
                <li><a href="#" class="nav-link" data-action="open-chat" title="Messages"><i class="fas fa-comment-dots"></i></a></li>
            </ul>
        </div>
    </header>
    <div class="main-wrapper">
        <main class="primary-view" id="primary-view"></main>
        <div class="secondary-view" id="secondary-view"></div>
    </div>
    <!-- NEW INFO TILES PANEL -->
    <div class="info-tiles-panel" id="info-tiles-panel">
        <!-- Populated by JS -->
    </div>
    <div class="user-panel">
        <div class="user-panel-info" data-action="view-profile" title="View Profile">
            <img id="currentUserPfpBottom" src="" alt="My Profile">
            <span id="currentUserUsernameBottom" class="username"></span>
        </div>
        <div class="user-panel-actions">
            <button class="action-btn" data-action="navigate" data-path="/settings" title="Settings"><i class="fas fa-cog"></i></button>
            <button class="action-btn" data-action="logout" title="Log Out"><i class="fas fa-sign-out-alt"></i></button>
        </div>
    </div>
    <div class="modal-container" id="modal-container"></div>
    <div class="history-nav-buttons">
        <button class="history-btn" data-action="history-back" title="Go Back"><i class="fas fa-arrow-left"></i></button>
        <button class="history-btn" data-action="history-forward" title="Go Forward"><i class="fas fa-arrow-right"></i></button>
    </div>`;

const getSpinnerHTML = () => `<div class="spinner-container"><div class="spinner"></div></div>`;

const getEmptyStateHTML = (message, iconClass) => `<div class="empty-state"><i class="fas ${iconClass}"></i><p>${message}</p></div>`;

const getProfilePageHTML = (user, posts, isCurrentUser, isFollowing) => `
    <div class="profile-page">
        <header class="profile-header">
            <div class="profile-avatar-container"><img class="profile-avatar" src="${user.profilePic}" alt="Profile Avatar"></div>
            <div class="profile-details">
                <div class="profile-title">
                    <h2 class="profile-username">${user.username}</h2>
                    <div class="profile-actions">
                        ${isCurrentUser ? `<button class="btn-secondary" data-action="navigate" data-path="/settings">Edit Profile</button>` : `<button class="btn-${isFollowing ? 'secondary' : 'primary'}" data-action="toggle-follow" data-user-id="${user.id}">${isFollowing ? 'Unfollow' : 'Follow'}</button><button class="btn-secondary" data-action="open-message" data-user-id="${user.id}">Message</button><button class="action-btn" data-action="block-user" data-user-id="${user.id}" title="Block"><i class="fas fa-ban"></i></button>`}
                    </div>
                </div>
                <div class="profile-stats">
                    <span><strong>${posts.length}</strong> posts</span>
                    <button class="profile-stat-btn" data-action="show-followers" data-user-id="${user.id}"><strong>${user.followers.length}</strong> followers</button>
                    <button class="profile-stat-btn" data-action="show-following" data-user-id="${user.id}"><strong>${user.following.length}</strong> following</button>
                </div>
                <div class="profile-bio"><p class="profile-fullname">${user.fullName}</p><p class="profile-bio-text">${user.bio}</p></div>
            </div>
        </header>
        <div class="profile-posts-grid">${posts.length > 0 ? posts.map(post => `<div class="grid-post-item" data-action="open-comments" data-post-id="${post.id}"><img src="${post.imgUrl}" alt="Post by ${user.username}"><div class="grid-post-overlay"><span><i class="fas fa-heart"></i> ${post.likes.length}</span><span><i class="far fa-comment"></i> ${post.comments.length}</span></div></div>`).join('') : getEmptyStateHTML("This user hasn't posted anything yet.", "fa-camera-retro")}</div>
    </div>`;

const getSettingsPageHTML = (user, blockedUsers) => `
    <div class="settings-page">
        <h1>Settings</h1>
        <div class="settings-section">
            <h2><i class="fas fa-user-edit"></i> Edit Profile</h2>
            <form id="edit-profile-form" data-action="save-profile">
                <div class="form-group"><label for="edit-username">Username</label><input type="text" id="edit-username" name="username" value="${user.username}"></div>
                <div class="form-group"><label for="edit-fullname">Full Name</label><input type="text" id="edit-fullname" name="fullName" value="${user.fullName}"></div>
                <div class="form-group"><label for="edit-bio">Bio</label><textarea id="edit-bio" name="bio" rows="3">${user.bio}</textarea></div>
                <button type="submit" class="btn-primary">Save Changes</button>
            </form>
        </div>
        <div class="settings-section">
            <h2><i class="fas fa-heart"></i> Your Activity</h2>
            <a href="#" class="setting-action-item" data-action="navigate" data-path="/settings/liked-posts"><span>View Liked Posts</span><i class="fas fa-chevron-right"></i></a>
            <!-- NEW: Link to Liked Reels -->
            <a href="#" class="setting-action-item" data-action="navigate" data-path="/settings/liked-reels"><span>View Liked Reels</span><i class="fas fa-chevron-right"></i></a>
        </div>
        <div class="settings-section">
            <h2><i class="fas fa-paint-brush"></i> Appearance</h2>
            <div class="setting-item"><span>Dark Mode</span><label class="switch"><input type="checkbox" id="theme-toggle-checkbox" data-action="toggle-theme" ${user.theme === 'dark' ? 'checked' : ''}><span class="slider round"></span></label></div>
        </div>
        <div class="settings-section">
            <h2><i class="fas fa-user-slash"></i> Blocked Users</h2>
            <div id="blocked-users-list" class="blocked-users-list">${blockedUsers.length > 0 ? blockedUsers.map(u => `<div class="blocked-user-item"><span>${u.username}</span><button class="btn-secondary" data-action="unblock-user" data-user-id="${u.id}">Unblock</button></div>`).join('') : getEmptyStateHTML("You haven't blocked anyone.", "fa-user-check")}</div>
        </div>
        <div class="settings-section">
            <h2><i class="fas fa-sign-out-alt"></i> Account</h2>
            <button class="btn-danger" data-action="logout">Log Out</button>
        </div>
    </div>`;

const getLikedPostsPageHTML = (posts) => `
    <div class="liked-posts-page">
        <div class="page-header"><button class="btn-secondary" data-action="navigate" data-path="/settings"><i class="fas fa-arrow-left"></i> Back to Settings</button><h1>Liked Posts</h1></div>
        <div class="profile-posts-grid">${posts.length > 0 ? posts.map(post => `<div class="grid-post-item" data-action="open-comments" data-post-id="${post.id}"><img src="${post.imgUrl}" alt="A liked post"><div class="grid-post-overlay"><span><i class="fas fa-heart"></i> ${post.likes.length}</span><span><i class="far fa-comment"></i> ${post.comments.length}</span></div></div>`).join('') : getEmptyStateHTML("You haven't liked any posts yet.", "fa-heart-crack")}</div>
    </div>`;

// NEW: HTML for Liked Reels page
const getLikedReelsPageHTML = (reels) => `
    <div class="liked-posts-page">
        <div class="page-header">
            <button class="btn-secondary" data-action="navigate" data-path="/settings"><i class="fas fa-arrow-left"></i> Back to Settings</button>
            <h1>Liked Reels</h1>
        </div>
        <div class="profile-posts-grid">
            ${reels.length > 0 ? reels.map(reel => `
                <div class="grid-post-item" data-action="open-reel-comments" data-reel-id="${reel.id}">
                    <video src="${reel.videoUrl}#t=0.5" preload="metadata"></video>
                    <div class="grid-post-overlay">
                        <span><i class="fas fa-heart"></i> ${reel.likes.length}</span>
                        <span><i class="far fa-comment"></i> ${reel.comments.length}</span>
                    </div>
                </div>`).join('') : getEmptyStateHTML("You haven't liked any reels yet.", "fa-video")}
        </div>
    </div>`;

// HELPER: Generates HTML for a single comment.
const getSingleCommentHTML = (c, post, index, currentUser) => {
    if (!c.user) return ''; // Safety check

    let contentHTML = '';
    switch (c.type) {
        case 'gif': contentHTML = `<img src="${c.url}" class="comment-gif" alt="GIF">`; break;
        case 'image': contentHTML = `<img src="${c.url}" class="comment-image" alt="Comment Image">`; break;
        default: contentHTML = `<span class="comment-content">${c.text}</span>`;
    }

    const reactions = c.reactions || {};
    const reactionsHTML = Object.entries(reactions).filter(([, userIds]) => userIds.length > 0).map(([emoji, userIds]) => {
        const userHasReacted = userIds.includes(currentUser.id);
        return `<div class="reaction-tag ${userHasReacted ? 'user-reacted' : ''}" data-action="add-comment-reaction" data-post-id="${post.id}" data-comment-index="${index}" data-emoji="${emoji}">${emoji} ${userIds.length}</div>`;
    }).join('');

    return `
        <div class="comment-wrapper" data-comment-index="${index}">
            <div class="comment" data-action="view-profile" data-user-id="${c.user.id}">
                <img src="${c.user.profilePic}" alt="${c.user.username}">
                <div class="comment-details">
                    <div><span class="username">${c.user.username}</span></div>
                    ${contentHTML}
                </div>
                <!-- New Action Bar -->
                <div class="comment-actions">
                    <button class="action-btn" data-action="toggle-reaction-popover" title="Add Reaction"><i class="fas fa-plus-circle"></i></button>
                    <!-- Popover is now inside the comment actions div for better positioning context -->
                    <div class="reaction-popover">
                       <button data-action="add-comment-reaction" data-post-id="${post.id}" data-comment-index="${index}" data-emoji="👍">👍</button>
                       <button data-action="add-comment-reaction" data-post-id="${post.id}" data-comment-index="${index}" data-emoji="❤️">❤️</button>
                       <button data-action="add-comment-reaction" data-post-id="${post.id}" data-comment-index="${index}" data-emoji="😂">😂</button>
                       <button data-action="add-comment-reaction" data-post-id="${post.id}" data-comment-index="${index}" data-emoji="😮">😮</button>
                    </div>
                </div>
            </div>
            <div class="comment-reactions">${reactionsHTML}</div>
        </div>`;
};


const getCommentsModalHTML = (post, commentsWithUsers, isLiked, postAuthor, currentUser) => {
    const commentsHTML = commentsWithUsers.map((c, index) => getSingleCommentHTML(c, post, index, currentUser)).join('');

    const commentInputHTML = `
        <div class="comment-input-container">
            <div class="gif-picker" id="gif-picker-post-${post.id}"></div>
            <div class="emoji-picker" id="emoji-picker-post-${post.id}"></div>
            <div class="comment-input-main-row">
                <div class="comment-input-actions">
                    <button class="action-btn" data-action="trigger-comment-file-upload" data-post-id="${post.id}" title="Attach Image"><i class="fas fa-paperclip"></i></button>
                    <input type="file" id="comment-file-input-${post.id}" style="display: none;" data-post-id="${post.id}" accept="image/*">
                    <button class="action-btn" data-action="toggle-comment-gif-picker" data-post-id="${post.id}" title="Send GIF"><i class="fas fa-gift"></i></button>
                </div>
                <form class="comment-input-form" data-action="post-comment" data-post-id="${post.id}">
                    <input type="text" name="commentText" placeholder="Add a comment..." required autocomplete="off">
                    <button class="action-btn" type="button" data-action="toggle-comment-emoji-picker" data-post-id="${post.id}" title="Emoji"><i class="far fa-smile"></i></button>
                    <button type="submit" class="action-btn" title="Post"><i class="fas fa-paper-plane"></i></button>
                </form>
            </div>
        </div>`;
    
    const postOptionsHTML = post.userId === currentUser.id ? `
        <div class="post-options-wrapper">
            <button class="action-btn post-options-btn" data-action="toggle-post-options" data-post-id="${post.id}"><i class="fas fa-ellipsis-h"></i></button>
            <div class="post-options-menu">
                <button class="post-option-item" data-action="delete-post" data-post-id="${post.id}"><i class="fas fa-trash-alt"></i> Delete</button>
            </div>
        </div>
    ` : '';

    return `
    <div class="modal-content" style="max-width: 850px; flex-direction: row; height: 90vh; max-height: 700px;">
        <div class="post-media" style="flex-basis: 55%; background-color: var(--bg-color); display: flex; align-items: center; justify-content: center; border-right: 1px solid var(--border-color);"><img src="${post.imgUrl}" alt="Post by ${postAuthor.username}" style="max-width: 100%; max-height: 100%; object-fit: contain;"></div>
        <div class="post-details-and-comments" style="flex-basis: 45%; display: flex; flex-direction: column; width: 100%;">
            <div class="modal-header">
                <div class="post-header" data-action="view-profile" data-user-id="${postAuthor.id}" style="cursor:pointer; flex-grow: 1;"><img src="${postAuthor.profilePic}" alt="${postAuthor.username}"><span class="username">${postAuthor.username}</span></div>
                ${postOptionsHTML}
                <button class="modal-close-btn" data-action="close-modal">×</button>
            </div>
            <div class="modal-body">
                <div class="comment" data-action="view-profile" data-user-id="${postAuthor.id}"><img src="${postAuthor.profilePic}" alt="${postAuthor.username}"><div><span class="username">${postAuthor.username}</span><span class="comment-content">${post.caption}</span></div></div>
                <hr style="border: none; border-top: 1px solid var(--border-color); margin: 10px 0;">
                <div class="comment-list">${commentsWithUsers.length > 0 ? commentsHTML : getEmptyStateHTML("No comments yet.", "fa-comment-dots")}</div>
            </div>
            <div class="modal-footer" style="margin-top: auto; padding: 0; border-top: 1px solid var(--border-color);">
                <div class="post-actions" style="padding: 8px 16px;"><button class="action-btn like-btn ${isLiked ? 'liked' : ''}" data-action="like-post" data-post-id="${post.id}"><i class="fas fa-heart"></i></button><button class="action-btn" title="Comment"><i class="far fa-comment"></i></button><button class="action-btn" data-action="share-post" title="Share"><i class="far fa-paper-plane"></i></button></div>
                <div class="likes-count" style="padding: 0 16px 8px; font-size: 14px; font-weight: 600;" data-post-id="${post.id}">${post.likes.length} likes</div>
                ${commentInputHTML}
            </div>
        </div>
    </div>`;
}

const getUserListModalHTML = (title, users, currentUser) => `
    <div class="modal-content" style="max-width: 400px; height: 70vh;">
        <div class="modal-header">
            <h3 style="flex-grow: 1; text-align: center;">${title}</h3>
            <button class="modal-close-btn" data-action="close-modal">×</button>
        </div>
        <div class="modal-body" style="padding: 0; overflow-y: auto;">
            ${users.length > 0 ? `
                <div class="user-list-container">
                    ${users.map(user => {
                        const isFollowing = currentUser.following.includes(user.id);
                        const isCurrentUser = user.id === currentUser.id;
                        return `
                        <div class="user-list-item">
                            <div class="user-list-item-details" data-action="view-profile" data-user-id="${user.id}">
                                <img src="${user.profilePic}" alt="${user.username}">
                                <div class="user-info">
                                    <div class="username">${user.username}</div>
                                    <div class="fullname">${user.fullName}</div>
                                </div>
                            </div>
                            ${!isCurrentUser ? `
                                <button class="btn-sm btn-${isFollowing ? 'secondary' : 'primary'}" data-action="toggle-follow-from-list" data-user-id="${user.id}">
                                    ${isFollowing ? 'Following' : 'Follow'}
                                </button>
                            ` : ''}
                        </div>
                        `}).join('')}
                </div>
            ` : getEmptyStateHTML(title === 'Followers' ? 'No followers yet.' : 'Not following anyone yet.', "fa-users")}
        </div>
    </div>`;

const getToastHTML = (message, type) => `<div class="toast toast-${type}"><i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>${message}</div>`;

const getSuggestionsPanelHTML = (suggestionUsers) => `
    <div class="suggestions-panel-wrapper">
        <div class="suggestions-panel">
            <div class="suggestions-header">
                <span class="title">Suggestions For You</span>
                <a href="#" class="see-all-btn" data-action="show-all-suggestions">See All</a>
            </div>
            ${suggestionUsers.map(user => `
                <div class="suggestion-item">
                    <img src="${user.profilePic}" alt="${user.username}" data-action="view-profile" data-user-id="${user.id}">
                    <div class="suggestion-info" data-action="view-profile" data-user-id="${user.id}">
                        <div class="username">${user.username}</div>
                        <div class="followed-by">Suggested for you</div>
                    </div>
                    <button class="follow-btn" data-action="toggle-follow" data-user-id="${user.id}">Follow</button>
                </div>
            `).join('')}
        </div>
    </div>`;

const getTrendingPanelHTML = (hashtags) => `
    <div class="trending-panel-wrapper">
        <div class="trending-panel">
            <div class="trending-header">
                <span>What's happening</span>
                <a href="#" class="see-all-btn" data-action="show-all-trending">See All</a>
            </div>
            ${hashtags.slice(0, 3).map(item => `
                <a href="#" class="trending-item" data-action="navigate" data-path="/tags/${item.tag.substring(1)}">
                    <div class="category">Trending in ${item.category}</div>
                    <div class="tag">${item.tag}</div>
                    <div class="posts">${item.posts} posts</div>
                </a>
            `).join('')}
        </div>
    </div>`;

// New: Modal for showing all trending topics
const getTrendingListModalHTML = (title, hashtags) => `
    <div class="modal-content" style="max-width: 400px; height: 70vh;">
        <div class="modal-header">
            <h3 style="flex-grow: 1; text-align: center;">${title}</h3>
            <button class="modal-close-btn" data-action="close-modal">×</button>
        </div>
        <div class="modal-body" style="padding: 0; overflow-y: auto;">
            ${hashtags.map(item => `
                <a href="#" class="trending-item" data-action="navigate" data-path="/tags/${item.tag.substring(1)}" style="padding: 12px 16px; text-decoration: none; display: block;">
                    <div class="category">Trending in ${item.category}</div>
                    <div class="tag">${item.tag}</div>
                    <div class="posts">${item.posts} posts</div>
                </a>
            `).join('')}
        </div>
    </div>`;


const getGroupTileHTML = (chat, activeChatId) => {
    const initials = chat.groupName.split(' ').map(n => n[0]).join('').substring(0, 2);
    const pic = chat.groupPic ? `<img src="${chat.groupPic}" alt="${chat.groupName}">` : `<div class="group-initials">${initials}</div>`;
    const isActive = chat.id === activeChatId;
    return `<div class="group-tile ${isActive ? 'active' : ''}" data-action="select-chat" data-chat-id="${chat.id}" title="${chat.groupName}">${pic}</div>`;
};

const getInfoTilesHTML = (user) => {
    const unreadCount = user.notifications ? user.notifications.filter(n => !n.read).length : 0;

    return `
        <div class="info-tile" data-action="show-followers" data-user-id="${user.id}" title="View Followers">
            <span class="info-tile-number">${user.followers.length}</span>
            <span class="info-tile-label">Followers</span>
        </div>
        <div class="info-tile" data-action="show-following" data-user-id="${user.id}" title="View Following">
            <span class="info-tile-number">${user.following.length}</span>
            <span class="info-tile-label">Following</span>
        </div>
        <div class="info-tile" data-action="show-notifications" title="View Notifications">
            <span class="info-tile-number">${unreadCount}</span>
            <span class="info-tile-label">Notifications</span>
        </div>
    `;
};

const getRelativeTime = (timestamp) => {
    const now = new Date();
    const past = new Date(timestamp);
    const msPerMinute = 60 * 1000;
    const msPerHour = msPerMinute * 60;
    const msPerDay = msPerHour * 24;
    const elapsed = now - past;

    if (elapsed < msPerMinute) return `${Math.round(elapsed/1000)}s ago`;
    if (elapsed < msPerHour) return `${Math.round(elapsed/msPerMinute)}m ago`;
    if (elapsed < msPerDay ) return `${Math.round(elapsed/msPerHour )}h ago`;
    
    return `${Math.round(elapsed/msPerDay)}d ago`;
}

const getNotificationsModalHTML = (notifications) => {
    const getIconClass = (type) => {
        switch (type) {
            case 'follow': return 'fa-user-plus';
            case 'like': return 'fa-heart';
            case 'welcome': return 'fa-hands-helping';
            case 'comment': return 'fa-comment';
            case 'login': return 'fa-sign-in-alt';
            case 'logout': return 'fa-sign-out-alt';
            case 'block': return 'fa-user-slash';
            case 'unblock': return 'fa-user-check';
            case 'delete': return 'fa-trash-alt';
            case 'create': return 'fa-plus-circle';
            case 'remove-member': return 'fa-user-minus';
            default: return 'fa-bell';
        }
    }

    // Sort notifications by timestamp, newest first
    const sortedNotifications = [...notifications].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    const unreadCount = sortedNotifications.filter(n => !n.read).length;

    return `
    <div class="modal-content" style="max-width: 500px; height: 70vh;">
        <div class="modal-header">
            <h3 style="flex-grow: 1; text-align: left;">Notifications</h3>
            ${unreadCount > 0 ? `<button class="btn-sm btn-secondary" data-action="mark-all-notifications-read">Mark all as read</button>` : ''}
            <button class="modal-close-btn" data-action="close-modal">×</button>
        </div>
        <div class="modal-body" style="padding: 0; overflow-y: auto;">
            ${sortedNotifications.length > 0 ? `
                <div class="notifications-list">
                    ${sortedNotifications.map(n => `
                        <div class="notification-item ${n.read ? 'read' : 'unread'}" data-action="handle-notification-click" data-notification-id="${n.id}">
                            <div class="notification-icon"><i class="fas ${getIconClass(n.type)}"></i></div>
                            <div class="notification-content">
                                <p class="notification-text">${n.text}</p>
                                <span class="notification-time">${getRelativeTime(n.timestamp)}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : getEmptyStateHTML('No new notifications.', 'fa-bell-slash')}
        </div>
    </div>`;
}

const getCreateGroupModalHTML = (currentUser, allUsers) => {
    const friendIds = [...new Set([...currentUser.followers, ...currentUser.following])];
    const friends = friendIds.map(id => allUsers.find(u => u.id === id)).filter(Boolean);

    return `
    <div class="modal-content" style=" max-width: 500px;">
        <form data-action="submit-create-group">
            <div class="modal-header"><h3>Create New Group</h3><button class="modal-close-btn" data-action="close-modal" type="button">×</button></div>
            <div class="modal-body">
                <div class="form-group"><label for="group-name">Group Name</label><input type="text" id="group-name" name="groupName" required placeholder="Name your group..."></div>
                <div class="form-group"><label>Add Members</label>
                    <div class="user-list-container" style="max-height: 250px; overflow-y: auto; border: 1px solid var(--border-color); padding: 5px; border-radius: 6px;">
                    ${friends.length > 0 ? friends.map(user => `
                        <div class="user-list-item">
                            <label style="display: flex; align-items: center; width: 100%; cursor: pointer; padding: 5px;">
                                <input type="checkbox" name="members" value="${user.id}" style="margin-right: 15px; width: 18px; height: 18px; flex-shrink: 0;">
                                <img src="${user.profilePic}" alt="${user.username}" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;">
                                <div class="user-info">
                                    <div class="username">${user.username}</div>
                                    <div class="fullname">${user.fullName}</div>
                                </div>
                            </label>
                        </div>
                    `).join('') : getEmptyStateHTML("Add some friends to start a group.", "fa-users")}
                    </div>
                </div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn-primary">Create Group</button></div>
        </form>
    </div>`;
}

const getManageMembersModalHTML = (chat, members, currentUser, allUsers) => {
    const isOwner = chat.ownerId === currentUser.id;
    return `
    <div class="modal-content" style="max-width: 400px; height: 70vh;">
        <div class="modal-header">
            <h3 style="flex-grow: 1; text-align: center;">${chat.groupName} Members</h3>
            <button class="modal-close-btn" data-action="close-modal">×</button>
        </div>
        <div class="modal-body" style="padding: 0; overflow-y: auto;">
            <div class="user-list-container">
                ${members.map(user => `
                    <div class="user-list-item">
                        <div class="user-list-item-details" data-action="view-profile" data-user-id="${user.id}">
                            <img src="${user.profilePic}" alt="${user.username}">
                            <div class="user-info">
                                <div class="username">${user.username}</div>
                                <div class="fullname">${user.id === chat.ownerId ? 'Group Owner' : 'Member'}</div>
                            </div>
                        </div>
                        ${isOwner && user.id !== currentUser.id ? `
                            <button class="btn-sm btn-danger" data-action="remove-group-member" data-user-id="${user.id}" data-chat-id="${chat.id}">
                                Remove
                            </button>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
        ${isOwner ? `
        <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center;">
            <p style="font-size: 14px; color: var(--secondary-text-color);">Group management</p>
            <button class="btn-danger" data-action="delete-group" data-chat-id="${chat.id}">Delete Group</button>
        </div>
        ` : ''}
    </div>`;
};

const getConfirmDeleteModalHTML = (chat) => `
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header"><h3>Confirm Deletion</h3><button class="modal-close-btn" data-action="close-modal" type="button">×</button></div>
        <div class="modal-body">
            <p>Are you sure you want to permanently delete the group "<strong>${chat.groupName}</strong>"? This action cannot be undone.</p>
        </div>
        <div class="modal-footer" style="display: flex; justify-content: flex-end; gap: 10px;">
            <button class="btn-secondary" data-action="close-modal">Cancel</button>
            <button class="btn-danger" data-action="confirm-delete-group" data-chat-id="${chat.id}">Delete</button>
        </div>
    </div>`;

const getConfirmDeletePostModalHTML = (post) => `
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header"><h3>Confirm Deletion</h3><button class="modal-close-btn" data-action="close-modal" type="button">×</button></div>
        <div class="modal-body">
            <p>Are you sure you want to permanently delete this post? This action cannot be undone.</p>
            <div class="mini-post-preview"><img src="${post.imgUrl}" alt="Post preview"><span>${post.caption.substring(0, 50)}...</span></div>
        </div>
        <div class="modal-footer" style="display: flex; justify-content: flex-end; gap: 10px;">
            <button class="btn-secondary" data-action="close-modal">Cancel</button>
            <button class="btn-danger" data-action="confirm-delete-post" data-post-id="${post.id}">Delete</button>
        </div>
    </div>`;

const getFullscreenMediaModalHTML = (url, mediaType) => `
    <div class="modal-content fullscreen-media-modal" data-action="close-modal">
        <button class="modal-close-btn" data-action="close-modal" style="color: white; font-size: 30px; text-shadow: 0 0 10px black;">×</button>
        ${mediaType === 'video' ? `<video src="${url}" controls autoplay loop></video>` : `<img src="${url}" alt="Fullscreen Media">`}
    </div>`;


// New: Modal for creating a post
const getCreatePostModalHTML = () => `
    <div class="modal-content create-post-modal" style="max-width: 850px;">
        <form data-action="submit-post">
            <div class="modal-header">
                <h3>Create New Post</h3>
                <button class="modal-close-btn" data-action="close-modal" type="button">×</button>
            </div>
            <div class="modal-body create-post-body">
                <div class="post-image-upload-area">
                    <img id="post-image-preview" src="#" alt="Image Preview" style="display:none;">
                    <video id="post-video-preview" style="display:none;" controls></video>
                    <div id="post-upload-placeholder">
                        <i class="fas fa-photo-video"></i>
                        <p>Drag photos and videos here</p>
                        <label for="post-file-input" class="btn-primary">Select from computer</label>
                        <input type="file" id="post-file-input" accept="image/*,video/*" required>
                    </div>
                </div>
                <div class="post-details-form">
                    <div class="form-group">
                        <label for="post-caption">Caption</label>
                        <textarea id="post-caption" name="caption" rows="4" placeholder="Write a caption..."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="post-tags">Tags (comma-separated)</label>
                        <input type="text" id="post-tags" name="tags" placeholder="e.g. travel, food, tech">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-primary" id="submit-post-btn">Post</button>
            </div>
        </form>
    </div>
`;


// --- MAIN SCRIPT EXECUTION ---
// Waits for the DOM to be fully loaded before running the script.
document.addEventListener('DOMContentLoaded', () => {

    // --- STATE MANAGEMENT ---
    // The 'state' object holds all the dynamic data of the application.
    // This centralized state makes it easier to track and manage data flow.
    let state = {
        currentUser: null,      // The user who is currently logged in.
        users: [],              // The full list of users, loaded from localStorage or demoData.
        posts: demoPosts,       // The full list of posts.
        chats: demoChats,       // The full list of chats.
        trendingTopics: demoHashtags, // The list of trending topics.
        reels: demoReels.map(reel => ({ // UPDATE: Standardize video URLs
            ...reel,
            videoUrl: 'https://storage.googleapis.com/gweb-gemini-cdn/gemini/uploads/a67e69028b547c044c242974242456ab313ea43c.mp4'
        })),
        activePage: 'home',     // Which primary view is currently visible (e.g., 'home', 'profile').
        activeSecondaryView: null, // Which secondary panel is open (e.g., 'search', 'chat').
        activeModal: null,      // Which modal is currently open (e.g., 'comments').
        viewingProfileId: null, // The ID of the user whose profile is being viewed.
        viewingTag: null,       // The hashtag currently being viewed.
        activeChatId: null,     // The ID of the currently open chat.
        activeChatPanel: null,  // Which chat panel is open (e.g., 'emoji', 'gif').
        blockedUsers: [],       // A list of user IDs blocked by the current user.
        trendingSliderIndex: 0, // NEW: Index for the trending posts slider
    };
    
    let sliderInterval = null; // Variable to hold the slider's setInterval timer.

    // --- UTILITY & STATE PERSISTENCE FUNCTIONS ---
    const getUser = (id) => state.users.find(u => u.id === id);
    const getPost = (id) => state.posts.find(p => p.id === id);
    const getDmChatId = (userId1, userId2) => userId1 < userId2 ? `${userId1}-${userId2}` : `${userId2}-${userId1}`;

    const saveUsersToDb = () => {
        try {
            localStorage.setItem('users_db', JSON.stringify(state.users));
        } catch (e) {
            console.error("Failed to save users to localStorage", e);
        }
    };
    
    // HELPER: Generates HTML for a single REEL comment.
    const getSingleReelCommentHTML = (c, reel, index, currentUser) => {
        if (!c.user) return ''; // Safety check

        let contentHTML = '';
        switch (c.type) {
            case 'gif': contentHTML = `<img src="${c.url}" class="comment-gif" alt="GIF">`; break;
            case 'image': contentHTML = `<img src="${c.url}" class="comment-image" alt="Comment Image">`; break;
            default: contentHTML = `<span class="comment-content">${c.text}</span>`;
        }

        const reactions = c.reactions || {};
        const reactionsHTML = Object.entries(reactions).filter(([, userIds]) => userIds.length > 0).map(([emoji, userIds]) => {
            const userHasReacted = userIds.includes(currentUser.id);
            return `<div class="reaction-tag ${userHasReacted ? 'user-reacted' : ''}" data-action="add-reel-comment-reaction" data-reel-id="${reel.id}" data-comment-index="${index}" data-emoji="${emoji}">${emoji} ${userIds.length}</div>`;
        }).join('');

        return `
            <div class="comment-wrapper" data-comment-index="${index}">
                <div class="comment" data-action="view-profile" data-user-id="${c.user.id}">
                    <img src="${c.user.profilePic}" alt="${c.user.username}">
                    <div class="comment-details">
                        <div><span class="username">${c.user.username}</span></div>
                        ${contentHTML}
                    </div>
                    <div class="comment-actions">
                        <button class="action-btn" data-action="toggle-reaction-popover" title="Add Reaction"><i class="fas fa-plus-circle"></i></button>
                        <div class="reaction-popover">
                        <button data-action="add-reel-comment-reaction" data-reel-id="${reel.id}" data-comment-index="${index}" data-emoji="👍">👍</button>
                        <button data-action="add-reel-comment-reaction" data-reel-id="${reel.id}" data-comment-index="${index}" data-emoji="❤️">❤️</button>
                        <button data-action="add-reel-comment-reaction" data-reel-id="${reel.id}" data-comment-index="${index}" data-emoji="😂">😂</button>
                        <button data-action="add-reel-comment-reaction" data-reel-id="${reel.id}" data-comment-index="${index}" data-emoji="😮">😮</button>
                        </div>
                    </div>
                </div>
                <div class="comment-reactions">${reactionsHTML}</div>
            </div>`;
    };

    const getReelCommentsModalHTML = (reel, commentsWithUsers, isLiked, reelAuthor, currentUser) => {
        const commentsHTML = commentsWithUsers.map((c, index) => getSingleReelCommentHTML(c, reel, index, currentUser)).join('');

        const commentInputHTML = `
            <div class="comment-input-container">
                <div class="comment-input-main-row">
                    <form class="comment-input-form" data-action="post-reel-comment" data-reel-id="${reel.id}">
                        <input type="text" name="commentText" placeholder="Add a comment..." required autocomplete="off">
                        <button type="submit" class="action-btn" title="Post"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>`;

        return `
        <div class="modal-content reel-comments-modal">
            <div class="modal-header">
                <h3>Comments</h3>
                <button class="modal-close-btn" data-action="close-modal">×</button>
            </div>
            <div class="reel-video-container">
                <video class="reel-video" src="${reel.videoUrl}" loop muted autoplay playsinline></video>
            </div>
            <div class="modal-body">
                <div class="reel-caption-container">
                    <img src="${reelAuthor.profilePic}" alt="${reelAuthor.username}" data-action="view-profile" data-user-id="${reelAuthor.id}" style="cursor: pointer;">
                    <div>
                        <p class="caption-text">
                            <span class="username" data-action="view-profile" data-user-id="${reelAuthor.id}">${reelAuthor.username}</span>
                            ${reel.caption}
                        </p>
                    </div>
                </div>
                <hr style="border: none; border-top: 1px solid var(--border-color); margin: 10px 0;">
                <div class="comment-list">${commentsWithUsers.length > 0 ? commentsHTML : getEmptyStateHTML("No comments yet. Be the first!", "fa-comment-dots")}</div>
            </div>
            <div class="modal-footer">
                <div class="post-actions" style="padding: 8px 16px; justify-content: flex-start;">
                    <button class="action-btn like-btn ${isLiked ? 'liked' : ''}" data-action="like-reel" data-reel-id="${reel.id}"><i class="fas fa-heart"></i></button>
                    <span class="reel-likes-count" style="font-size: 14px; font-weight: 600; color: var(--primary-text-color); margin-left: -10px;">${reel.likes.length}</span>
                    <button class="action-btn" style="margin-left: 10px;"><i class="far fa-comment"></i></button>
                    <span class="reel-comments-count" style="font-size: 14px; font-weight: 600; color: var(--primary-text-color); margin-left: -10px;">${reel.comments.length}</span>
                </div>
                ${commentInputHTML}
            </div>
        </div>`;
    }

    const getReelsPageHTML = (reels, currentUser) => {
        if (!reels || reels.length === 0) {
            return getEmptyStateHTML("No reels to show right now.", "fa-video");
        }
    
        return `
        <div class="reels-container" id="reels-container">
            ${reels.map(reel => {
                const author = getUser(reel.userId);
                if (!author) return '';
                const isLiked = reel.likes.includes(currentUser.id);
    
                return `
                <div class="reel-item" data-reel-id="${reel.id}">
                    <video class="reel-video" src="${reel.videoUrl}" loop muted playsinline data-action="toggle-reel-play"></video>
                    <div class="reel-overlay">
                        <div class="reel-author" data-action="view-profile" data-user-id="${author.id}">
                            <img src="${author.profilePic}" alt="${author.username}">
                            <span>${author.username}</span>
                        </div>
                        <p class="reel-caption">${reel.caption}</p>
                        <div class="reel-audio">
                            <i class="fas fa-music"></i>
                            <span>${reel.audioName}</span>
                        </div>
                    </div>
                    <div class="reel-actions">
                        <button class="action-btn like-btn ${isLiked ? 'liked' : ''}" data-action="like-reel" data-reel-id="${reel.id}">
                            <i class="fas fa-heart"></i>
                        </button>
                        <span class="reel-likes-count">${reel.likes.length}</span>
    
                        <button class="action-btn" data-action="open-reel-comments" data-reel-id="${reel.id}">
                            <i class="far fa-comment"></i>
                        </button>
                        <span class="reel-comments-count">${reel.comments.length}</span>
    
                        <button class="action-btn" data-action="share-reel">
                            <i class="far fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
                `;
            }).join('')}
        </div>
        `;
    };

    // NEW: Centralized notification creation function
    const createNotification = (targetUserId, text, type, link = null) => {
        const targetUser = getUser(targetUserId);
        if (!targetUser) return;
        
        if (!targetUser.notifications) {
            targetUser.notifications = [];
        }

        const newNotification = {
            id: Date.now() + Math.random(), // Add random to avoid collision
            text,
            type,
            link,
            read: false,
            timestamp: new Date().toISOString()
        };

        targetUser.notifications.unshift(newNotification);
        
        // Keep notification list from getting too long
        if(targetUser.notifications.length > 50) {
            targetUser.notifications.pop();
        }

        saveUsersToDb();
        
        // If the notification is for the current user, re-render the info tiles
        if(targetUserId === state.currentUser.id) {
            renderInfoTiles();
        }
    };

    const debounce = (func, delay) => {
        let timeout;
        return (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), delay);
        };
    };

    // --- DOM ELEMENTS ---
    const appContainer = document.querySelector('.app-container');
    const toastContainer = document.getElementById('toast-container');
    let primaryView, secondaryView, modalContainer; 

    // --- ROUTING & HISTORY API ---
    const navigateTo = (path) => {
        if (window.location.pathname === path) return;
        history.pushState({ path }, '', path);
        handleRouteChange(); 
    };

    const handleRouteChange = () => {
        const path = window.location.pathname;
        const pathParts = path.split('/').filter(Boolean);

        state.activeSecondaryView = null; 

        if (path.startsWith('/profile/')) {
            state.activePage = 'profile';
            state.viewingProfileId = parseInt(pathParts[1]);
        } else if (path.startsWith('/tags/')) {
            state.activePage = 'hashtag-feed';
            state.viewingTag = pathParts[1];
        } else if (path === '/settings/liked-posts') {
            state.activePage = 'liked-posts';
        } else if (path === '/settings/liked-reels') { // NEW: Handle liked-reels route
            state.activePage = 'liked-reels';
        } else if (path === '/settings') {
            state.activePage = 'settings';
        } else if (path === '/reels') {
            state.activePage = 'reels';
        } else {
            state.activePage = 'home';
        }

        renderPrimaryView();
        updateNavLinks();
        renderSecondaryView();
        if (state.currentUser) renderGroupNav();
    };

    // --- NOTIFICATION SYSTEM ---
    const showToast = (message, type = 'success') => {
        const toastWrapper = document.createElement('div');
        toastWrapper.innerHTML = getToastHTML(message, type);
        const toastElement = toastWrapper.firstElementChild;
        toastContainer.appendChild(toastElement);
        setTimeout(() => toastElement.remove(), 3000); 
    };

    // --- AUTHENTICATION & INITIALIZATION ---
    const init = () => {
        const usersFromDb = localStorage.getItem('users_db');
        if (usersFromDb) {
            try {
                state.users = JSON.parse(usersFromDb);
            } catch (e) {
                console.error("Failed to parse users from localStorage, using default.", e);
                state.users = demoUsers;
                saveUsersToDb();
            }
        } else {
            state.users = demoUsers;
            saveUsersToDb();
        }

        document.addEventListener('submit', handleGlobalSubmit);
        document.addEventListener('click', handleGlobalClick);
        window.addEventListener('popstate', handleRouteChange);

        const loggedInUserId = localStorage.getItem('loggedInUserId');
        if (loggedInUserId) {
            const user = getUser(parseInt(loggedInUserId));
            if (user) {
                initializeAppForUser(user);
            } else {
                localStorage.removeItem('loggedInUserId');
                renderAuthPage('login');
            }
        } else {
            renderAuthPage('login');
        }
    };

    const renderAuthPage = (page) => {
        if (page === 'signup') {
            appContainer.innerHTML = getSignupPageHTML();
        } else {
            appContainer.innerHTML = getLoginPageHTML();
        }
    };

    const initializeAppForUser = (user) => {
        if (!user.notifications) {
            user.notifications = [];
            createNotification(user.id, 'Welcome to InstaClone! Explore and connect with others.', 'welcome', null);
        }
        state.currentUser = { ...user, theme: 'dark' };
        document.body.dataset.theme = state.currentUser.theme;
        renderAppShell();
        handleRouteChange();
    };

    // --- MAIN APP RENDERING ---
    const renderAppShell = () => {
        appContainer.innerHTML = getAppShellHTML();
        primaryView = document.getElementById('primary-view');
        secondaryView = document.getElementById('secondary-view');
        modalContainer = document.getElementById('modal-container');
        renderInfoTiles();
        renderGroupNav();
        renderTrendingPostsSlider();
        document.getElementById('currentUserPfpBottom').src = state.currentUser.profilePic;
        document.getElementById('currentUserUsernameBottom').innerText = state.currentUser.username;
        document.querySelector('.user-panel-info').dataset.userId = state.currentUser.id;
        addAppEventListeners();
    };

    const renderPrimaryView = () => {
        if (!primaryView) return;
        primaryView.innerHTML = getSpinnerHTML();
        setTimeout(() => {
            const visiblePosts = state.posts.filter(p => !state.blockedUsers.includes(p.userId));
            switch (state.activePage) {
                case 'home':
                    primaryView.innerHTML = '';
                    renderFeed(visiblePosts, primaryView);

                    const trendingTopics = state.trendingTopics;
                    if (trendingTopics.length > 0) {
                        const trendingContainer = document.createElement('div');
                        trendingContainer.innerHTML = getTrendingPanelHTML(trendingTopics);
                        primaryView.appendChild(trendingContainer.firstElementChild);
                    }
                    const suggestions = state.users.filter(user =>
                        user.id !== state.currentUser.id &&
                        !state.currentUser.following.includes(user.id)
                    ).slice(0, 5);

                    if (suggestions.length > 0) {
                        const suggestionsContainer = document.createElement('div');
                        suggestionsContainer.innerHTML = getSuggestionsPanelHTML(suggestions);
                        primaryView.appendChild(suggestionsContainer.firstElementChild);
                    }
                    break;
                case 'profile': renderProfilePage(state.viewingProfileId); break;
                case 'hashtag-feed': renderHashtagFeedPage(state.viewingTag); break;
                case 'settings': renderSettingsPage(); break;
                case 'liked-posts': renderLikedPostsPage(); break;
                case 'liked-reels': renderLikedReelsPage(); break; // NEW: Render liked-reels page
                case 'reels':
                    primaryView.innerHTML = getReelsPageHTML(state.reels, state.currentUser);
                    initReelsObserver();
                    break;
            }
        }, 200);
    };

    const renderSecondaryView = () => {
        if (!secondaryView) return;
        const isVisible = !!state.activeSecondaryView;
        secondaryView.classList.toggle('visible', isVisible);
        const suggestionsPanel = document.querySelector('.suggestions-panel-wrapper');
        if (suggestionsPanel) {
            suggestionsPanel.classList.toggle('docked', isVisible);
        }
        const trendingPanel = document.querySelector('.trending-panel-wrapper');
        if (trendingPanel) {
            trendingPanel.classList.toggle('docked', isVisible);
        }
        const infoTilesPanel = document.getElementById('info-tiles-panel');
        if (infoTilesPanel) {
            infoTilesPanel.classList.toggle('docked', isVisible);
        }
        const userPanel = document.querySelector('.user-panel');
        if (userPanel) {
            userPanel.classList.toggle('docked', isVisible);
        }
        const sliderContainer = document.getElementById('trending-posts-slider-container');
        if (sliderContainer) {
            sliderContainer.classList.toggle('docked', isVisible);
        }
        const groupNavPanel = document.getElementById('group-nav-panel');
        if (groupNavPanel) {
            groupNavPanel.classList.toggle('docked', isVisible);
        }
        if (!isVisible) {
            secondaryView.innerHTML = '';
            return;
        }
        switch (state.activeSecondaryView) {
            case 'search': renderSearchPanel(); break;
            case 'chat': renderChatPanel(); break;
        }
    };

    const renderFeed = (posts, container) => {
        const feedContainer = document.createElement('div');
        feedContainer.className = 'feed-container';

        if (posts.length === 0) {
            feedContainer.innerHTML = getEmptyStateHTML("No posts on your feed yet!", "fa-rss");
            container.appendChild(feedContainer);
            return;
        }
        posts.forEach(post => {
            const postUser = getUser(post.userId);
            if (!postUser) return;
            const isLiked = post.likes.includes(state.currentUser.id);
            const postElement = document.createElement('div');
            postElement.className = 'post-card';
            postElement.dataset.postId = post.id;
            
            const postOptionsHTML = post.userId === state.currentUser.id ? `
                <div class="post-options-wrapper">
                    <button class="action-btn post-options-btn" data-action="toggle-post-options" data-post-id="${post.id}"><i class="fas fa-ellipsis-h"></i></button>
                    <div class="post-options-menu">
                        <button class="post-option-item" data-action="delete-post" data-post-id="${post.id}"><i class="fas fa-trash-alt"></i> Delete</button>
                    </div>
                </div>
            ` : '';
            const mediaType = post.type || 'image';
            const mediaHTML = mediaType === 'video' 
                ? `<video src="${post.imgUrl}" class="post-media-content" controls loop muted autoplay playsinline></video>` 
                : `<img src="${post.imgUrl}" class="post-media-content" alt="Post by ${postUser.username}">`;

            postElement.innerHTML = `
                <div class="post-header" data-action="view-profile" data-user-id="${postUser.id}">
                    <img src="${postUser.profilePic}" alt="${postUser.username}"><span class="username">${postUser.username}</span>
                    ${postOptionsHTML}
                </div>
                <div class="post-media">
                    ${mediaHTML}
                    <button class="action-btn fullscreen-btn" data-action="fullscreen-media" data-media-url="${post.imgUrl}" data-media-type="${mediaType}" title="Fullscreen"><i class="fas fa-expand"></i></button>
                </div>
                <div class="post-actions"><button class="action-btn like-btn ${isLiked ? 'liked' : ''}" data-action="like-post" data-post-id="${post.id}"><i class="fas fa-heart"></i></button><button class="action-btn" data-action="open-comments" data-post-id="${post.id}"><i class="far fa-comment"></i></button><button class="action-btn" data-action="share-post"><i class="far fa-paper-plane"></i></button></div>
                <div class="post-info"><div class="likes-count" data-post-id="${post.id}">${post.likes.length} likes</div><div class="post-caption"><span class="username" data-action="view-profile" data-user-id="${postUser.id}">${postUser.username}</span> <span>${post.caption}</span></div><div class="comment-preview" data-action="open-comments" data-post-id="${post.id}">View all ${post.comments.length} comments</div></div>`;
            feedContainer.appendChild(postElement);
        });
        container.appendChild(feedContainer);
    };

    const renderProfilePage = (userId) => {
        const user = getUser(userId);
        if (!user || state.blockedUsers.includes(user.id)) {
            primaryView.innerHTML = getEmptyStateHTML("User not found or is blocked.", "fa-question-circle");
            return;
        }
        const userPosts = state.posts.filter(p => p.userId === user.id);
        const isCurrentUser = user.id === state.currentUser.id;
        const isFollowing = state.currentUser.following.includes(user.id);
        primaryView.innerHTML = getProfilePageHTML(user, userPosts, isCurrentUser, isFollowing);
    };

    const renderHashtagFeedPage = (tag) => {
        primaryView.innerHTML = '';
        const taggedPosts = state.posts.filter(p => p.tags && p.tags.includes(tag));
        const pageContainer = document.createElement('div');
        pageContainer.className = 'hashtag-feed-page';
        pageContainer.style.maxWidth = '900px';
        pageContainer.style.margin = '20px auto';
        pageContainer.style.padding = '20px';

        const headerHTML = `
            <div class="page-header">
                 <button class="btn-secondary" data-action="navigate" data-path="/home"><i class="fas fa-arrow-left"></i> Back to Home</button>
                 <h1>#${tag}</h1>
            </div>`;
        pageContainer.innerHTML = headerHTML;
        if (taggedPosts.length > 0) {
            renderFeed(taggedPosts, pageContainer);
        } else {
            const emptyStateContainer = document.createElement('div');
            emptyStateContainer.innerHTML = getEmptyStateHTML(`No posts found for #${tag}.`, "fa-hashtag");
            pageContainer.appendChild(emptyStateContainer);
        }
        primaryView.appendChild(pageContainer);
        const trendingTopics = state.trendingTopics;
        if (trendingTopics.length > 0) {
            const trendingContainer = document.createElement('div');
            trendingContainer.innerHTML = getTrendingPanelHTML(trendingTopics);
            primaryView.appendChild(trendingContainer.firstElementChild);
        }
        const suggestions = state.users.filter(user =>
            user.id !== state.currentUser.id &&
            !state.currentUser.following.includes(user.id)
        ).slice(0, 5);

        if (suggestions.length > 0) {
            const suggestionsContainer = document.createElement('div');
            suggestionsContainer.innerHTML = getSuggestionsPanelHTML(suggestions);
            primaryView.appendChild(suggestionsContainer.firstElementChild);
        }
    };

    const renderSettingsPage = () => {
        const blockedUsersWithData = state.blockedUsers.map(id => getUser(id)).filter(Boolean);
        primaryView.innerHTML = getSettingsPageHTML(state.currentUser, blockedUsersWithData);
    };

    const renderLikedPostsPage = () => {
        const likedPosts = state.posts.filter(p => p.likes.includes(state.currentUser.id)).reverse();
        primaryView.innerHTML = getLikedPostsPageHTML(likedPosts);
    };

    // NEW: Function to render the liked reels page
    const renderLikedReelsPage = () => {
        const likedReels = state.reels.filter(r => r.likes.includes(state.currentUser.id)).reverse();
        primaryView.innerHTML = getLikedReelsPageHTML(likedReels);
    };

    const renderSearchPanel = (query = '') => {
        secondaryView.innerHTML = `<div class="panel-header">Search</div><div class="panel-content"><div class="search-input-wrapper"><input type="text" id="search-input" placeholder="Search users..." value="${query}"></div><div class="search-results-list" id="search-results-list"><p style="text-align:center; padding: 20px;">Start typing to find users.</p></div></div>`;
        document.getElementById('search-input').focus();
    };

    const renderGroupNav = () => {
        const navPanel = document.getElementById('group-nav-panel');
        if (!navPanel || !state.currentUser) return;

        const myGroups = Object.entries(state.chats)
            .filter(([id, chat]) => chat.isGroup && chat.members.includes(state.currentUser.id))
            .map(([id, chat]) => ({ ...chat, id }));

        navPanel.innerHTML = myGroups.map(chat => getGroupTileHTML(chat, state.activeChatId)).join('');
    };

    const renderInfoTiles = () => {
        const panel = document.getElementById('info-tiles-panel');
        if (!panel || !state.currentUser) return;
        panel.innerHTML = getInfoTilesHTML(state.currentUser);
    };

    const renderChatPanel = () => {
        secondaryView.innerHTML = `<div class="panel-header"><span>Messages</span><button class="btn-sm btn-primary" data-action="create-group" title="Create New Group"><i class="fas fa-plus"></i> New Group</button></div><div class="chat-panel-content" id="conversation-list-container"></div><div class="chat-window" id="chat-window-container"></div>`;
        renderConversationList();
        if (state.activeChatId) {
            renderChatWindow(state.activeChatId);
            secondaryView.querySelector('#chat-window-container').classList.add('active');
        }
    };

    const renderConversationList = () => {
        const listEl = document.getElementById('conversation-list-container');
        if (!listEl) return;
        let listHTML = '';
        const myChats = Object.entries(state.chats)
            .filter(([id, chat]) => chat.members.includes(state.currentUser.id))
            .sort(([, a], [, b]) => {
                if (a.isGroup && !b.isGroup) return -1;
                if (!a.isGroup && b.isGroup) return 1;
                return 0;
            });

        myChats.forEach(([chatId, chat]) => {
            const lastMsg = chat.messages[chat.messages.length - 1] || { text: 'No messages yet.' };
            let pic, name;
            let lastMsgText = lastMsg.text;
            if (lastMsg.type === 'gif') lastMsgText = 'Sent a GIF';
            if (lastMsg.type === 'image') lastMsgText = 'Sent an image';

            if (chat.isGroup) {
                pic = chat.groupPic || profilePics[0];
                name = chat.groupName;
            } else {
                const otherUser = getUser(chat.members.find(id => id !== state.currentUser.id));
                if (!otherUser) return;
                pic = otherUser.profilePic;
                name = otherUser.username;
            }
            listHTML += `<div class="conversation-item" data-action="select-chat" data-chat-id="${chatId}"><img src="${pic}" alt="${name}"><div class="convo-details"><div class="convo-name">${name}</div><div class="last-message">${lastMsgText}</div></div></div>`;
        });
        listEl.innerHTML = listHTML || getEmptyStateHTML("No messages yet.", "fa-inbox");
    };
    
    const getSingleMessageHTML = (msg, chatId, index, currentUser, chat) => {
        const isSent = msg.senderId === currentUser.id;
        let senderNameHTML = '';
        if (chat.isGroup && !isSent) {
            const sender = getUser(msg.senderId);
            senderNameHTML = `<div class="sender-name">${sender ? sender.username : 'Unknown'}</div>`;
        }
        let messageContentHTML = '';
        const mediaType = msg.type || 'text';
        switch (mediaType) {
            case 'gif': 
            case 'image': 
                messageContentHTML = `
                <div class="media-container">
                    <img src="${msg.url}" class="message-${mediaType}" alt="${mediaType}">
                    <button class="action-btn fullscreen-btn" data-action="fullscreen-media" data-media-url="${msg.url}" data-media-type="${mediaType}"><i class="fas fa-expand"></i></button>
                </div>`;
                break;
            default: 
                messageContentHTML = `<span>${msg.text}</span>`;
        }

        const reactions = msg.reactions || {};
        const reactionsHTML = Object.entries(reactions).filter(([, userIds]) => userIds.length > 0).map(([emoji, userIds]) => {
            const userHasReacted = userIds.includes(currentUser.id);
            return `<div class="reaction-tag ${userHasReacted ? 'user-reacted' : ''}" data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${index}" data-emoji="${emoji}">${emoji} ${userIds.length}</div>`;
        }).join('');

        return `
            <div class="message-wrapper" data-message-index="${index}">
                <div class="message-bubble ${isSent ? 'sent' : 'received'}">
                    ${senderNameHTML}
                    ${messageContentHTML}
                    <div class="message-actions">
                        <button class="action-btn" data-action="toggle-reaction-popover" title="Add Reaction"><i class="fas fa-plus-circle"></i></button>
                        <div class="reaction-popover">
                           <button data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${index}" data-emoji="👍">👍</button>
                           <button data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${index}" data-emoji="❤️">❤️</button>
                           <button data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${index}" data-emoji="😂">😂</button>
                           <button data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${index}" data-emoji="😮">😮</button>
                        </div>
                    </div>
                </div>
                <div class="message-reactions">${reactionsHTML}</div>
            </div>`;
    };

    const renderChatWindow = (chatId) => {
        const windowEl = document.getElementById('chat-window-container');
        if (!windowEl || !chatId) return;
        const chat = state.chats[chatId];
        if(!chat) return;

        let headerHTML;
        if (chat.isGroup) {
            headerHTML = `
                <div class="chat-header">
                    <button data-action="close-chat-window"><i class="fas fa-arrow-left"></i></button>
                    <img src="${chat.groupPic || profilePics[0]}" alt="${chat.groupName}">
                    <span class="group-name">${chat.groupName}</span>
                    <div class="chat-actions">
                        <button class="btn-sm btn-secondary" data-action="manage-group-members" data-chat-id="${chatId}" title="Manage Members"><i class="fas fa-user-cog"></i> Members</button>
                    </div>
                </div>`;
        } else {
            const otherUser = getUser(chat.members.find(id => id !== state.currentUser.id));
            if (!otherUser) return;
            headerHTML = `<div class="chat-header"><button data-action="close-chat-window"><i class="fas fa-arrow-left"></i></button><img src="${otherUser.profilePic}" alt="${otherUser.username}"><span class="username">${otherUser.username}</span></div>`;
        }
        
        const messagesHTML = chat.messages.map((msg, index) => 
            getSingleMessageHTML(msg, chatId, index, state.currentUser, chat)
        ).join('');

        const formContainerHTML = `
            <div class="chat-input-container">
                 <div class="gif-picker" id="gif-picker-${chatId}"></div>
                 <div class="emoji-picker" id="emoji-picker-${chatId}"></div>
                 <div class="chat-input-main-row">
                    <div class="chat-input-actions">
                         <button class="action-btn" data-action="trigger-file-upload" data-chat-id="${chatId}" title="Attach File"><i class="fas fa-paperclip"></i></button>
                         <input type="file" id="chat-file-input-${chatId}" class="chat-file-input" style="display: none;" data-chat-id="${chatId}" accept="image/png, image/jpeg, image/gif, image/webp">
                         <button class="action-btn" data-action="toggle-gif-picker" data-chat-id="${chatId}" title="Send GIF"><i class="fas fa-gift"></i></button>
                    </div>
                    <form class="chat-input-form" data-action="send-message" data-chat-id="${chatId}">
                        <input type="text" name="messageText" placeholder="Message..." required autocomplete="off">
                        <button class="action-btn" type="button" data-action="toggle-emoji-picker" data-chat-id="${chatId}" title="Emoji"><i class="far fa-smile"></i></button>
                        <button type="submit" class="action-btn" title="Send"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>`;

        windowEl.innerHTML = headerHTML + `<div class="chat-messages" id="chat-messages-area">${messagesHTML}</div>` + formContainerHTML;
        
        document.getElementById(`chat-file-input-${chatId}`).addEventListener('change', handleFileUpload);

        const messageArea = windowEl.querySelector('#chat-messages-area');
        messageArea.scrollTop = messageArea.scrollHeight;
    };

    const renderModal = () => {
        if (!modalContainer) return;
        modalContainer.classList.toggle('visible', !!state.activeModal);
        modalContainer.innerHTML = '';
        if (!state.activeModal) return;

        switch (state.activeModal.type) {
            case 'user-list': {
                const { listType, userId, title, users } = state.activeModal;
                let usersToList = users;
                let modalTitle = title;
                if (!usersToList) {
                    const user = getUser(userId);
                    if (!user) {
                        modalContainer.innerHTML = getEmptyStateHTML("User not found.", "fa-question-circle");
                        return;
                    }
                    const listIds = listType === 'Followers' ? user.followers : user.following;
                    usersToList = listIds.map(id => getUser(id)).filter(Boolean);
                    modalTitle = listType;
                }
                modalContainer.innerHTML = getUserListModalHTML(modalTitle, usersToList, state.currentUser);
                break;
            }
            case 'comments': {
                const post = getPost(state.activeModal.postId);
                const postAuthor = getUser(post.userId);
                if (!post || !postAuthor) {
                    modalContainer.innerHTML = getEmptyStateHTML("Post or author not found.", "fa-question-circle");
                    return;
                }
                const commentsWithUsers = post.comments.map(c => ({ ...c, user: getUser(c.userId) })).filter(c => c.user);
                const isLiked = post.likes.includes(state.currentUser.id);
                modalContainer.innerHTML = getCommentsModalHTML(post, commentsWithUsers, isLiked, postAuthor, state.currentUser);
                const fileInput = document.getElementById(`comment-file-input-${post.id}`);
                if (fileInput) fileInput.addEventListener('change', handleCommentFileUpload);
                break;
            }
            case 'reel-comments': {
                const reel = state.reels.find(r => r.id === state.activeModal.reelId);
                if (!reel) {
                    modalContainer.innerHTML = getEmptyStateHTML("Reel not found.", "fa-question-circle");
                    return;
                }
                const reelAuthor = getUser(reel.userId);
                const commentsWithUsers = reel.comments.map(c => ({ ...c, user: getUser(c.userId) })).filter(c => c.user);
                const isLiked = reel.likes.includes(state.currentUser.id);
                modalContainer.innerHTML = getReelCommentsModalHTML(reel, commentsWithUsers, isLiked, reelAuthor, state.currentUser);
                break;
            }
            case 'create-post': {
                modalContainer.innerHTML = getCreatePostModalHTML();
                const fileInput = document.getElementById('post-file-input');
                const imagePreview = document.getElementById('post-image-preview');
                const videoPreview = document.getElementById('post-video-preview');
                const placeholder = document.getElementById('post-upload-placeholder');
                
                fileInput.addEventListener('change', (e) => {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            const dataUrl = event.target.result;
                            const mediaType = file.type.startsWith('image') ? 'image' : 'video';
                            
                            imagePreview.style.display = 'none';
                            videoPreview.style.display = 'none';

                            if (mediaType === 'image') {
                                imagePreview.src = dataUrl;
                                imagePreview.style.display = 'block';
                            } else {
                                videoPreview.src = dataUrl;
                                videoPreview.style.display = 'block';
                            }
                            
                            placeholder.style.display = 'none';
                            const form = document.querySelector('form[data-action="submit-post"]');
                            form.dataset.mediaUrl = dataUrl;
                            form.dataset.mediaType = mediaType;
                        }
                        reader.readAsDataURL(file);
                    }
                });
                break;
            }
            case 'create-group': {
                modalContainer.innerHTML = getCreateGroupModalHTML(state.currentUser, state.users);
                break;
            }
            case 'manage-group-members': {
                const { chatId } = state.activeModal;
                const chat = state.chats[chatId];
                if (!chat) {
                    state.activeModal = null;
                    renderModal();
                    return;
                }
                const members = chat.members.map(id => getUser(id)).filter(Boolean);
                modalContainer.innerHTML = getManageMembersModalHTML(chat, members, state.currentUser, state.users);
                break;
            }
            case 'trending-list': {
                const { title, hashtags } = state.activeModal;
                modalContainer.innerHTML = getTrendingListModalHTML(title, hashtags);
                break;
            }
            case 'confirm-delete': {
                const { chatId } = state.activeModal;
                const chat = state.chats[chatId];
                modalContainer.innerHTML = getConfirmDeleteModalHTML(chat);
                break;
            }
            case 'confirm-delete-post': {
                const post = getPost(state.activeModal.postId);
                if (post) modalContainer.innerHTML = getConfirmDeletePostModalHTML(post);
                break;
            }
            case 'fullscreen-media': {
                const { url, mediaType } = state.activeModal;
                modalContainer.innerHTML = getFullscreenMediaModalHTML(url, mediaType);
                break;
            }
            case 'notifications': {
                modalContainer.innerHTML = getNotificationsModalHTML(state.currentUser.notifications || []);
                break;
            }
        }
    };

    // --- EVENT HANDLERS ---
    const handleLogin = (formData) => {
        const username = formData.get('username').trim().toLowerCase();
        const password = formData.get('password').trim();
        const user = state.users.find(u => u.username === username && u.password === password);
        if (user) {
            showToast(`Welcome back, ${user.username}!`);
            localStorage.setItem('loggedInUserId', user.id);
            initializeAppForUser(user);
            createNotification(user.id, 'You successfully logged in.', 'login');
        } else {
            showToast("Invalid username or password.", "error");
        }
    };

    const handleSignup = (formData) => {
        const fullName = formData.get('fullName').trim();
        const username = formData.get('username').trim().toLowerCase();
        const password = formData.get('password');
        const confirmPassword = formData.get('confirmPassword');
        if (!fullName || !username || !password) return showToast("Please fill out all fields.", "error");
        if (password.length < 6) return showToast("Password must be at least 6 characters.", "error");
        if (password !== confirmPassword) return showToast("Passwords do not match.", "error");
        if (state.users.some(u => u.username === username)) return showToast("Username is already taken.", "error");
        const newId = Math.max(...state.users.map(u => u.id), 0) + 1;
        const newUser = { id: newId, username, password, fullName, profilePic: profilePics[Math.floor(Math.random() * profilePics.length)], bio: "Excited to be on InstaClone!", followers: [], following: [], notifications: [] };
        state.users.push(newUser);
        saveUsersToDb();
        showToast(`Welcome, ${username}! Your account has been created.`, "success");
        localStorage.setItem('loggedInUserId', newUser.id);
        initializeAppForUser(newUser);
    };

    const handleSocialLogin = () => {
        showToast("Signing in with Google...");
        setTimeout(() => {
            const newId = Math.max(...state.users.map(u => u.id), 0) + 1;
            const username = `googleuser${newId}`;
            const newUser = {
                id: newId,
                username: username,
                password: `social_login_password_${Math.random()}`,
                fullName: "Google User",
                profilePic: profilePics[Math.floor(Math.random() * profilePics.length)],
                bio: "Just joined via Google!",
                followers: [],
                following: [],
                notifications: []
            };
            state.users.push(newUser);
            saveUsersToDb();
            showToast(`Welcome, ${newUser.fullName}!`, "success");
            localStorage.setItem('loggedInUserId', newUser.id);
            initializeAppForUser(newUser);
            createNotification(newUser.id, 'You successfully logged in with Google.', 'login');
        }, 1500);
    };
    
    const handleLogout = () => {
        showToast("You have been logged out.");
        createNotification(state.currentUser.id, 'You logged out.', 'logout');
        localStorage.removeItem('loggedInUserId');
        state.currentUser = null;
        removeAppEventListeners();
        history.replaceState(null, '', '/');
        init();
    };

    const handleGlobalClick = (e) => {
        if (!e.target.closest('.emoji-picker, .gif-picker, .reaction-popover, [data-action="toggle-reaction-popover"], .post-options-menu, [data-action="toggle-post-options"]')) {
            document.querySelectorAll('.reaction-popover.visible, .emoji-picker.visible, .gif-picker.visible, .post-options-menu.visible').forEach(p => p.classList.remove('visible'));
        }
        
        const target = e.target.closest('[data-action]');
        if (!target) return;

        const { action, userId, postId, path, chatId, messageIndex, commentIndex, emoji, gifUrl, mediaUrl, mediaType, direction, notificationId, reelId } = target.dataset;

        if (!state.currentUser) {
            e.preventDefault();
            if (action === 'show-signup') renderAuthPage('signup');
            if (action === 'show-login') renderAuthPage('login');
            if (action === 'social-login') handleSocialLogin();
            return;
        }
        
        const actionsToPrevent = [
            'navigate', 'view-profile', 'open-search', 'open-chat', 'open-comments', 'close-modal', 'show-followers', 'show-following',
            'show-all-suggestions', 'show-all-trending', 'share-post', 'open-message', 'select-chat', 'close-chat-window',
            'create-post', 'create-group', 'manage-group-members', 'delete-group', 'confirm-delete-group', 'logout',
            'toggle-emoji-picker', 'select-emoji', 'toggle-gif-picker', 'select-gif', 'trigger-file-upload', 'add-reaction',
            'toggle-comment-emoji-picker', 'select-comment-emoji', 'toggle-comment-gif-picker', 'post-comment-gif', 'trigger-comment-file-upload',
            'add-comment-reaction', 'like-post', 'toggle-follow', 'toggle-follow-from-list', 'toggle-reaction-popover',
            'toggle-post-options', 'delete-post', 'confirm-delete-post', 'fullscreen-media', 'slider-nav',
            'show-notifications', 'mark-all-notifications-read', 'handle-notification-click',
            'toggle-reel-play', 'like-reel', 'open-reel-comments', 'share-reel', 'add-reel-comment-reaction'
        ];
        
        if (actionsToPrevent.includes(action)) e.preventDefault();
        
        if (action.includes('picker') || action === 'toggle-reaction-popover' || action === 'toggle-post-options') {
             e.stopPropagation();
        }

        switch (action) {
            case 'navigate': if (state.activeModal) { state.activeModal = null; renderModal(); } navigateTo(path); break;
            case 'view-profile': state.activeModal = null; renderModal(); navigateTo(`/profile/${userId}`); break;
            case 'history-back': window.history.back(); break;
            case 'history-forward': window.history.forward(); break;
            case 'open-search': state.activeSecondaryView = state.activeSecondaryView === 'search' ? null : 'search'; renderSecondaryView(); break;
            case 'open-chat': state.activeSecondaryView = state.activeSecondaryView === 'chat' ? null : 'chat'; state.activeChatId = null; renderSecondaryView(); renderGroupNav(); break;
            case 'open-comments': state.activeModal = { type: 'comments', postId: parseInt(postId) }; renderModal(); break;
            case 'close-modal': state.activeModal = null; renderModal(); break;
            case 'like-post': {
                const postIdNum = parseInt(postId);
                handleLikeStateChange(postIdNum);
                
                const post = getPost(postIdNum);
                const isLiked = post.likes.includes(state.currentUser.id);

                document.querySelectorAll(`.like-btn[data-post-id="${postId}"]`).forEach(btn => {
                    btn.classList.toggle('liked', isLiked);
                    if (isLiked) {
                        btn.style.animation = 'like-pop 0.3s ease';
                        btn.addEventListener('animationend', () => btn.style.animation = '', { once: true });
                    }
                });
                document.querySelectorAll(`.likes-count[data-post-id="${postId}"]`).forEach(el => { el.textContent = `${post.likes.length} likes`; });
                if (state.activePage === 'liked-posts' && !isLiked) renderLikedPostsPage();
                
                renderTrendingPostsSlider();
                break;
            }
            case 'toggle-follow':
            case 'toggle-follow-from-list': {
                const userIdNum = parseInt(userId);
                handleFollow(userIdNum);
                updateFollowUI(userIdNum);
                break;
            }
            case 'show-followers': state.activeModal = { type: 'user-list', listType: 'Followers', userId: parseInt(userId) }; renderModal(); break;
            case 'show-following': state.activeModal = { type: 'user-list', listType: 'Following', userId: parseInt(userId) }; renderModal(); break;
            case 'show-notifications': state.activeModal = { type: 'notifications' }; renderModal(); break;
            case 'mark-all-notifications-read': handleMarkAllRead(); break;
            case 'handle-notification-click': handleNotificationClick(notificationId); break;
            case 'show-all-suggestions': handleShowAllSuggestions(); break;
            case 'show-all-trending': handleShowAllTrending(); break;
            case 'block-user': handleBlock(parseInt(userId)); break;
            case 'unblock-user': handleUnblock(parseInt(userId)); renderSettingsPage(); break;
            case 'share-post': handleSharePost(); break;
            case 'open-message': handleOpenMessage(parseInt(userId)); renderSecondaryView(); renderGroupNav(); break;
            case 'select-chat': state.activeChatId = chatId; state.activeSecondaryView = 'chat'; renderSecondaryView(); renderChatWindow(chatId); secondaryView.querySelector('#chat-window-container').classList.add('active'); renderGroupNav(); break;
            case 'close-chat-window': state.activeChatId = null; secondaryView.querySelector('#chat-window-container').classList.remove('active'); renderGroupNav(); break;
            case 'toggle-theme': handleThemeToggle(); break;
            case 'create-post': {
                 if (!window.FileReader) { return showToast("Your browser does not support file uploads.", "error"); }
                state.activeModal = { type: 'create-post' }; 
                renderModal(); 
                break;
            }
            case 'create-group': state.activeModal = { type: 'create-group' }; renderModal(); break;
            case 'manage-group-members': state.activeModal = { type: 'manage-group-members', chatId }; renderModal(); break;
            case 'remove-group-member': handleRemoveGroupMember(chatId, parseInt(userId)); break;
            case 'delete-group': state.activeModal = { type: 'confirm-delete', chatId }; renderModal(); break;
            case 'confirm-delete-group': handleDeleteGroup(chatId); break;
            case 'logout': handleLogout(); break;
            
            case 'toggle-post-options': handleTogglePostOptions(target); break;
            case 'delete-post': state.activeModal = { type: 'confirm-delete-post', postId: parseInt(postId) }; renderModal(); break;
            case 'confirm-delete-post': handleDeletePost(parseInt(postId)); break;

            case 'fullscreen-media': state.activeModal = { type: 'fullscreen-media', url: mediaUrl, mediaType: mediaType }; renderModal(); break;
            
            case 'slider-nav': handleSliderNav(direction); break;

            case 'toggle-emoji-picker': handleTogglePicker(chatId, 'emoji', 'chat'); break;
            case 'select-emoji': handleSelectEmoji(chatId, target.innerText); break;
            case 'toggle-gif-picker': handleTogglePicker(chatId, 'gif', 'chat'); break;
            case 'select-gif': handleSendGif(chatId, gifUrl); break;
            case 'trigger-file-upload': document.getElementById(`chat-file-input-${chatId}`).click(); break;
            case 'toggle-reaction-popover': handleToggleReactionPopover(e.target); break;
            case 'add-reaction': handleReaction(chatId, parseInt(messageIndex), emoji); break;

            case 'toggle-comment-emoji-picker': handleTogglePicker(postId, 'emoji', 'post'); break;
            case 'select-comment-emoji': handleSelectCommentEmoji(postId, target.innerText); break;
            case 'toggle-comment-gif-picker': handleTogglePicker(postId, 'gif', 'post'); break;
            case 'post-comment-gif': handlePostCommentGif(parseInt(postId), gifUrl); break;
            case 'trigger-comment-file-upload': document.getElementById(`comment-file-input-${postId}`).click(); break;
            case 'add-comment-reaction': handleCommentReaction(parseInt(postId), parseInt(commentIndex), emoji); break;

            case 'toggle-reel-play': e.target.paused ? e.target.play() : e.target.pause(); break;
            case 'like-reel': handleReelLike(parseInt(reelId)); break;
            case 'open-reel-comments': state.activeModal = { type: 'reel-comments', reelId: parseInt(reelId) }; renderModal(); break;
            case 'share-reel': handleSharePost(); break;
            case 'add-reel-comment-reaction': handleReelCommentReaction(parseInt(reelId), parseInt(commentIndex), emoji); break;
        }

        updateNavLinks();
    };

    const handleGlobalSubmit = (e) => {
        e.preventDefault();
        const target = e.target.closest('[data-action]');
        if (!target) return;
        const { action, postId, chatId, reelId } = target.dataset;

        if (action === 'login') { handleLogin(new FormData(target)); return; }
        if (action === 'signup') { handleSignup(new FormData(target)); return; }
        if (!state.currentUser) return;

        switch (action) {
            case 'submit-post': {
                const form = e.target;
                const mediaUrl = form.dataset.mediaUrl;
                const mediaType = form.dataset.mediaType || 'image';
                if (!mediaUrl) { return showToast("Please select an image or video to post.", "error"); }
                const formData = new FormData(form);
                const caption = formData.get('caption').trim();
                const tags = formData.get('tags').split(',').map(tag => tag.trim().replace(/#/g, '')).filter(Boolean);
                const newId = Math.max(...state.posts.map(p => p.id), 0) + 1;
                const newPost = { id: newId, userId: state.currentUser.id, imgUrl: mediaUrl, type: mediaType, caption: caption, likes: [], comments: [], tags: tags };
                state.posts.unshift(newPost);
                showToast("Post created successfully!", "success");
                state.activeModal = null;
                renderModal();
                if (state.activePage === 'home' || (state.activePage === 'profile' && state.viewingProfileId === state.currentUser.id)) {
                    renderPrimaryView();
                }
                renderTrendingPostsSlider();
                break;
            }
            case 'post-comment': handlePostComment(parseInt(postId), new FormData(target)); target.reset(); break;
            case 'post-reel-comment': handlePostReelComment(parseInt(reelId), new FormData(target)); target.reset(); break;
            case 'send-message': handleSendMessage(chatId, new FormData(target)); target.reset(); target.querySelector('input').focus(); break;
            case 'save-profile': handleSaveProfile(new FormData(target), e.submitter); break;
            case 'submit-create-group': handleCreateGroup(new FormData(target)); break;
        }
    };

    const handleSearchInput = debounce((e) => {
        const query = e.target.value;
        const resultsList = document.getElementById('search-results-list');
        if (!resultsList) return;
        if (query.length < 2) { resultsList.innerHTML = `<p style="text-align:center; padding: 20px;">Enter at least 2 characters.</p>`; return; }
        resultsList.innerHTML = getSpinnerHTML();
        setTimeout(() => {
            const results = state.users.filter(user => user.username.toLowerCase().includes(query.toLowerCase()));
            resultsList.innerHTML = results.length > 0 ? results.map(user => `<div class="user-list-item" data-action="view-profile" data-user-id="${user.id}"><img src="${user.profilePic}" alt="${user.username}"><div class="user-info"><div class="username">${user.username}</div><div class="fullname">${user.fullName}</div></div></div>`).join('') : getEmptyStateHTML("No users found.", "fa-user-times");
        }, 300);
    }, 300);

    const addAppEventListeners = () => {
        document.addEventListener('input', (e) => { 
            if (e.target.matches('#search-input')) {
                handleSearchInput(e);
            }
        });
    };

    const removeAppEventListeners = () => {
        document.removeEventListener('submit', handleGlobalSubmit);
        document.removeEventListener('click', handleGlobalClick);
    };

    // --- ACTION LOGIC FUNCTIONS ---
    const handleLikeStateChange = (postId) => {
        const post = getPost(postId);
        if (!post) return;
        const idx = post.likes.indexOf(state.currentUser.id);
        if (idx > -1) {
            post.likes.splice(idx, 1);
        } else {
            post.likes.push(state.currentUser.id);
            const postAuthor = getUser(post.userId);
            if (postAuthor && postAuthor.id !== state.currentUser.id) {
                createNotification(postAuthor.id, `<strong>${state.currentUser.username}</strong> liked your post.`, 'like', `post-comments:${post.id}`);
            }
        }
    };
    
    const handleFollow = (userId) => {
        const user = getUser(userId);
        if (!user) return;
        const idx = state.currentUser.following.indexOf(userId);
        if (idx > -1) {
            state.currentUser.following.splice(idx, 1);
            const followerIndex = user.followers.indexOf(state.currentUser.id);
            if(followerIndex > -1) user.followers.splice(followerIndex, 1);
            createNotification(state.currentUser.id, `You unfollowed <strong>${user.username}</strong>.`, 'unfollow', `/profile/${user.id}`);
        } else {
            state.currentUser.following.push(userId);
            user.followers.push(state.currentUser.id);
            if (user.id !== state.currentUser.id) {
                createNotification(user.id, `<strong>${state.currentUser.username}</strong> started following you.`, 'follow', `/profile/${state.currentUser.id}`);
            }
            createNotification(state.currentUser.id, `You started following <strong>${user.username}</strong>.`, 'follow', `/profile/${user.id}`);
        }
        saveUsersToDb();
        renderInfoTiles();
    };

    const updateFollowUI = (userId) => {
        const userToUpdate = getUser(userId); if (!userToUpdate) return;
        const isFollowing = state.currentUser.following.includes(userId);
        document.querySelectorAll(`button[data-action='toggle-follow'][data-user-id='${userId}'], button[data-action='toggle-follow-from-list'][data-user-id='${userId}']`).forEach(button => { button.textContent = isFollowing ? (button.dataset.action === 'toggle-follow-from-list' ? 'Following' : 'Unfollow') : 'Follow'; button.className = isFollowing ? button.className.replace('btn-primary', 'btn-secondary') : button.className.replace('btn-secondary', 'btn-primary'); });
        document.querySelectorAll(`.suggestion-item .follow-btn[data-user-id='${userId}']`).forEach(button => { button.textContent = isFollowing ? 'Following' : 'Follow'; button.disabled = isFollowing; });
        if (state.activePage === 'profile' && state.viewingProfileId === userId) { const followerCountEl = document.querySelector('.profile-stats button[data-action="show-followers"] strong'); if (followerCountEl) followerCountEl.textContent = userToUpdate.followers.length; }
        if (state.activePage === 'profile' && state.viewingProfileId === state.currentUser.id) { const followingCountEl = document.querySelector('.profile-stats button[data-action="show-following"] strong'); if (followingCountEl) followingCountEl.textContent = state.currentUser.following.length; }
    };

    const handleBlock = (userId) => {
        const user = getUser(userId);
        if (!user) return;
        showToast(`Blocked ${user.username}`, "error");
        if (!state.blockedUsers.includes(userId)) state.blockedUsers.push(userId);
        createNotification(state.currentUser.id, `You blocked <strong>${user.username}</strong>.`, 'block', `/profile/${user.id}`);
        navigateTo('/home');
    };

    const handleUnblock = (userId) => {
        const user = getUser(userId);
        if (!user) return;
        showToast(`Unblocked ${user.username}`);
        state.blockedUsers = state.blockedUsers.filter(id => id !== userId);
        createNotification(state.currentUser.id, `You unblocked <strong>${user.username}</strong>.`, 'unblock', `/profile/${user.id}`);
    };

    const handleSaveProfile = (formData, submitButton) => {
        const originalText = submitButton.innerHTML; submitButton.innerHTML = `Saving... <span class="btn-spinner"></span>`; submitButton.disabled = true;
        setTimeout(() => {
            const userInDb = state.users.find(u => u.id === state.currentUser.id);
            if (userInDb) { userInDb.username = formData.get('username').trim(); userInDb.fullName = formData.get('fullName').trim(); userInDb.bio = formData.get('bio').trim(); state.currentUser.username = userInDb.username; state.currentUser.fullName = userInDb.fullName; state.currentUser.bio = userInDb.bio; saveUsersToDb(); }
            submitButton.innerHTML = originalText; submitButton.disabled = false; showToast("Profile saved successfully!"); renderPrimaryView();
        }, 1000);
    };
    
    const handleShowAllSuggestions = () => { const allSuggestedUsers = state.users.filter(user => user.id !== state.currentUser.id && !state.currentUser.following.includes(user.id)); state.activeModal = { type: 'user-list', title: 'Suggestions', users: allSuggestedUsers }; renderModal(); };
    
    const handleShowAllTrending = () => { state.activeModal = { type: 'trending-list', title: 'Trending', hashtags: state.trendingTopics }; renderModal(); };
    
    const handleCreateGroup = (formData) => {
        const groupName = formData.get('groupName').trim();
        const memberIds = formData.getAll('members').map(id => parseInt(id));
        if (!groupName) return showToast("Group name is required.", "error");
        if (memberIds.length < 1) return showToast("You must select at least one member.", "error");
        const newChatId = `group-${Date.now()}`;
        const newGroup = { id: newChatId, isGroup: true, ownerId: state.currentUser.id, groupName: groupName, groupPic: profilePics[Math.floor(Math.random() * profilePics.length)], members: [state.currentUser.id, ...memberIds], messages: [{ senderId: state.currentUser.id, text: `Created the group "${groupName}"`, reactions: {} }] };
        state.chats[newChatId] = newGroup;
        showToast(`Group "${groupName}" created!`, "success");
        createNotification(state.currentUser.id, `You created the group "<strong>${groupName}</strong>".`, 'create', `chat:${newChatId}`);
        state.activeModal = null;
        renderModal();
        renderGroupNav();
        renderConversationList();
    };
    
    const handleDeleteGroup = (chatId) => {
        const chat = state.chats[chatId];
        if (!chat || chat.ownerId !== state.currentUser.id) { return showToast("You do not have permission to delete this group.", "error"); }
        createNotification(state.currentUser.id, `You deleted the group "<strong>${chat.groupName}</strong>".`, 'delete', null);
        delete state.chats[chatId];
        showToast("Group deleted successfully.", "success");
        state.activeModal = null;
        renderModal();
        if (state.activeChatId === chatId) { state.activeChatId = null; if (state.activeSecondaryView === 'chat') { renderSecondaryView(); } } else if (state.activeSecondaryView === 'chat') { renderConversationList(); }
        renderGroupNav();
    };

    const handleRemoveGroupMember = (chatId, userIdToRemove) => {
        const chat = state.chats[chatId];
        const userToRemove = getUser(userIdToRemove);
        if (!chat || !userToRemove || chat.ownerId !== state.currentUser.id) {
            showToast("You don't have permission to remove members.", "error");
            return;
        }
        chat.members = chat.members.filter(id => id !== userIdToRemove);
        chat.messages.push({ senderId: state.currentUser.id, text: `Removed ${userToRemove.username} from the group.`, reactions: {} });
        
        createNotification(state.currentUser.id, `You removed <strong>${userToRemove.username}</strong> from "<strong>${chat.groupName}</strong>".`, 'remove-member', `chat:${chatId}`);
        createNotification(userIdToRemove, `You were removed from "<strong>${chat.groupName}</strong>" by <strong>${state.currentUser.username}</strong>.`, 'remove-member', null);

        showToast(`Removed ${userToRemove.username}`, "success");
        renderModal();
        renderChatWindow(chatId);
    };

    const handleThemeToggle = () => { state.currentUser.theme = state.currentUser.theme === 'dark' ? 'light' : 'dark'; document.body.dataset.theme = state.currentUser.theme; document.getElementById('theme-toggle-checkbox').checked = state.currentUser.theme === 'dark'; };
    const handleSharePost = () => { navigator.clipboard.writeText(window.location.href).then(() => showToast("Post link copied to clipboard!")); };
    const handleOpenMessage = (userId) => { const chatId = getDmChatId(state.currentUser.id, userId); if (!state.chats[chatId]) { state.chats[chatId] = { isGroup: false, members: [state.currentUser.id, userId], messages: [] }; } state.activeSecondaryView = 'chat'; state.activeChatId = chatId; };
    const handleTogglePostOptions = (button) => { const menu = button.nextElementSibling; if (menu) menu.classList.toggle('visible'); };
    
    const handleDeletePost = (postId) => {
        const postIndex = state.posts.findIndex(p => p.id === postId);
        if (postIndex === -1) return;
        const post = state.posts[postIndex];
        if (post.userId !== state.currentUser.id) return showToast("You can only delete your own posts.", "error");

        state.posts.splice(postIndex, 1);
        showToast("Post deleted.", "success");
        createNotification(state.currentUser.id, `You deleted your post.`, 'delete', null);
        state.activeModal = null;
        renderModal();
        renderPrimaryView();
        renderTrendingPostsSlider();
    };
    
    const handleMarkAllRead = () => {
        if (state.currentUser.notifications) {
            state.currentUser.notifications.forEach(n => n.read = true);
            saveUsersToDb();
            renderModal();
            renderInfoTiles();
            showToast("All notifications marked as read.");
        }
    };
    
    const handleNotificationClick = (notificationId) => {
        if (!state.currentUser.notifications) return;
        const notification = state.currentUser.notifications.find(n => n.id == notificationId);
        if (!notification) return;

        notification.read = true;
        saveUsersToDb();

        if (notification.link) {
            if (notification.link.startsWith('post-comments:')) {
                const postId = parseInt(notification.link.split(':')[1]);
                state.activeModal = { type: 'comments', postId };
                renderModal(); 
            } else if (notification.link.startsWith('chat:')) {
                const chatId = notification.link.split(':')[1];
                state.activeModal = null;
                renderModal();
                state.activeSecondaryView = 'chat';
                state.activeChatId = chatId;
                renderSecondaryView();
            } else if (notification.link.startsWith('/')) {
                state.activeModal = null; 
                renderModal();
                navigateTo(notification.link);
            }
        } else {
            renderModal();
        }
        
        renderInfoTiles();
    };

    // --- CHAT & COMMENT FEATURE HANDLERS ---
    const handleTogglePicker = (id, type, context = 'chat') => {
        const pickerId = `${type}-picker-${context === 'post' ? 'post-' : ''}${id}`; const otherPickerId = `${type === 'emoji' ? 'gif' : 'emoji'}-picker-${context === 'post' ? 'post-' : ''}${id}`;
        const picker = document.getElementById(pickerId); const otherPicker = document.getElementById(otherPickerId); if (!picker) return;
        otherPicker.classList.remove('visible');
        if (picker.classList.contains('visible')) { picker.classList.remove('visible'); } else {
            if (!picker.innerHTML) {
                if (type === 'emoji') { const emojis = ['😀', '😂', '❤️', '👍', '😮', '😢', '🙏', '🎉', '🔥', '💯', '🤔', '😎', '🥳', '🤯', '😱']; picker.innerHTML = `<div class="emoji-grid">${emojis.map(e => `<button data-action="select-${context === 'post' ? 'comment-' : ''}emoji" data-post-id="${id}" data-chat-id="${id}">${e}</button>`).join('')}</div>`; } 
                else if (type === 'gif') { const contextId = context === 'post' ? `post-${id}` : id; const postIdAttr = context === 'post' ? `data-post-id="${id}"` : ''; const chatIdAttr = context === 'chat' ? `data-chat-id="${id}"` : ''; picker.innerHTML = `<input type="text" class="form-group input gif-search-input" id="gif-search-${contextId}" placeholder="Search GIFs (e.g. happy, cat)..."><div class="gif-grid" id="gif-grid-${contextId}">${demoGifs.map(gif => `<img src="${gif.url}" data-action="${context === 'post' ? 'post-comment-gif' : 'select-gif'}" ${postIdAttr} ${chatIdAttr} data-gif-url="${gif.url}">`).join('')}</div>`; document.getElementById(`gif-search-${contextId}`).addEventListener('input', (e) => handleGifSearch(e, context, id)); }
            }
            picker.classList.add('visible');
        }
    };
    const handleGifSearch = debounce((e, context, id) => {
        const query = e.target.value.toLowerCase().trim(); const contextId = context === 'post' ? `post-${id}` : id; const grid = document.getElementById(`gif-grid-${contextId}`); if (!grid) return;
        const filteredGifs = query ? demoGifs.filter(gif => gif.tags.some(tag => tag.includes(query))) : demoGifs;
        const postIdAttr = context === 'post' ? `data-post-id="${id}"` : ''; const chatIdAttr = context === 'chat' ? `data-chat-id="${id}"` : '';
        if (filteredGifs.length > 0) { grid.innerHTML = filteredGifs.map(gif => `<img src="${gif.url}" data-action="${context === 'post' ? 'post-comment-gif' : 'select-gif'}" ${postIdAttr} ${chatIdAttr} data-gif-url="${gif.url}">`).join(''); } 
        else { grid.innerHTML = `<p style="text-align: center; color: var(--secondary-text-color); grid-column: 1 / -1;">No GIFs found.</p>`; }
    }, 300);
    const handleSendMessage = (chatId, formData) => {
        const text = formData.get('messageText'); if (!text.trim()) return; const chat = state.chats[chatId]; const newMessage = { senderId: state.currentUser.id, text: text.trim(), reactions: {} }; chat.messages.push(newMessage);
        const messagesArea = document.getElementById('chat-messages-area'); if (messagesArea) { const newIndex = chat.messages.length - 1; const newMsgHTML = getSingleMessageHTML(newMessage, chatId, newIndex, state.currentUser, chat); messagesArea.insertAdjacentHTML('beforeend', newMsgHTML); messagesArea.scrollTop = messagesArea.scrollHeight; }
        updateConversationListLastMessage(chatId, newMessage);
    };
    const handleSendGif = (chatId, gifUrl) => {
        if (!chatId || !gifUrl) return; const chat = state.chats[chatId]; const newMessage = { senderId: state.currentUser.id, type: 'gif', url: gifUrl, reactions: {} }; chat.messages.push(newMessage);
        handleTogglePicker(chatId, 'gif', 'chat'); const messagesArea = document.getElementById('chat-messages-area');
        if (messagesArea) { const newIndex = chat.messages.length - 1; const newMsgHTML = getSingleMessageHTML(newMessage, chatId, newIndex, state.currentUser, chat); messagesArea.insertAdjacentHTML('beforeend', newMsgHTML); messagesArea.scrollTop = messagesArea.scrollHeight; }
        updateConversationListLastMessage(chatId, newMessage);
    };
    const handleFileUpload = (e) => {
        const file = e.target.files[0]; const chatId = e.target.dataset.chatId; if (!file || !chatId) return; const chat = state.chats[chatId];
        if (file.type.startsWith('image/')) {
            const objectURL = URL.createObjectURL(file); const newMessage = { senderId: state.currentUser.id, type: 'image', url: objectURL, filename: file.name, reactions: {} }; chat.messages.push(newMessage);
            const messagesArea = document.getElementById('chat-messages-area');
            if (messagesArea) { const newIndex = chat.messages.length - 1; const newMsgHTML = getSingleMessageHTML(newMessage, chatId, newIndex, state.currentUser, chat); messagesArea.insertAdjacentHTML('beforeend', newMsgHTML); messagesArea.scrollTop = messagesArea.scrollHeight; }
            updateConversationListLastMessage(chatId, newMessage);
        } else { showToast("Sorry, only image files can be shared for now.", "error"); } e.target.value = null;
    };
    const handleReaction = (chatId, msgIndex, emoji) => {
        const msg = state.chats[chatId].messages[msgIndex]; if (!msg) return; if (!msg.reactions) msg.reactions = {}; const userId = state.currentUser.id; let userRemoved = false;
        Object.keys(msg.reactions).forEach(existingEmoji => { const userIndex = msg.reactions[existingEmoji].indexOf(userId); if (userIndex > -1) { msg.reactions[existingEmoji].splice(userIndex, 1); if (existingEmoji === emoji) userRemoved = true; } });
        if (!userRemoved) { if (!msg.reactions[emoji]) msg.reactions[emoji] = []; msg.reactions[emoji].push(userId); }
        const msgWrapper = document.querySelector(`.message-wrapper[data-message-index="${msgIndex}"]`);
        if (msgWrapper) { const reactionsContainer = msgWrapper.querySelector('.message-reactions'); if (reactionsContainer) { const reactionsHTML = Object.entries(msg.reactions).filter(([, uIds]) => uIds.length > 0).map(([e, uIds]) => { const userHasReacted = uIds.includes(userId); return `<div class="reaction-tag ${userHasReacted ? 'user-reacted' : ''}" data-action="add-reaction" data-chat-id="${chatId}" data-message-index="${msgIndex}" data-emoji="${e}">${e} ${uIds.length}</div>`; }).join(''); reactionsContainer.innerHTML = reactionsHTML; } }
        const popover = document.querySelector(`.message-wrapper[data-message-index="${msgIndex}"] .reaction-popover.visible`); if (popover) popover.classList.remove('visible');
    };
    const handleSelectEmoji = (chatId, emoji) => { const input = document.querySelector(`.chat-input-form[data-chat-id="${chatId}"] input[name="messageText"]`); if(input) { input.value += emoji; input.focus(); } handleTogglePicker(chatId, 'emoji', 'chat'); };
    const handlePostComment = (postId, formData) => {
        const text = formData.get('commentText').trim(); if (!text) return; const post = getPost(postId); if (!post) return;
        const newComment = { userId: state.currentUser.id, text, reactions: {}, user: getUser(state.currentUser.id) };
        post.comments.push(newComment);
        const postAuthor = getUser(post.userId);
        if (postAuthor && postAuthor.id !== state.currentUser.id) {
            createNotification(postAuthor.id, `<strong>${state.currentUser.username}</strong> commented: "${text.substring(0, 20)}..."`, 'comment', `post-comments:${post.id}`);
        }
        const commentList = document.querySelector('.modal-container .comment-list');
        if (commentList) { const emptyState = commentList.querySelector('.empty-state'); if (emptyState) emptyState.remove(); const newCommentHTML = getSingleCommentHTML(newComment, post, post.comments.length - 1, state.currentUser); commentList.insertAdjacentHTML('beforeend', newCommentHTML); commentList.scrollTop = commentList.scrollHeight; }
        document.querySelectorAll(`.post-card[data-post-id="${postId}"] .comment-preview, .grid-post-overlay[data-post-id="${postId}"] span:last-child`).forEach(el => { el.innerHTML = `<i class="far fa-comment"></i> ${post.comments.length}`; });
    };
    const handlePostCommentGif = (postId, gifUrl) => {
        const post = getPost(postId); if (!post || !gifUrl) return; const newComment = { userId: state.currentUser.id, type: 'gif', url: gifUrl, reactions: {}, user: getUser(state.currentUser.id) }; post.comments.push(newComment); handleTogglePicker(postId, 'gif', 'post');
        const commentList = document.querySelector('.modal-container .comment-list');
        if (commentList) { const emptyState = commentList.querySelector('.empty-state'); if (emptyState) emptyState.remove(); const newCommentHTML = getSingleCommentHTML(newComment, post, post.comments.length - 1, state.currentUser); commentList.insertAdjacentHTML('beforeend', newCommentHTML); commentList.scrollTop = commentList.scrollHeight; }
        document.querySelectorAll(`.post-card[data-post-id="${postId}"] .comment-preview, .grid-post-overlay[data-post-id="${postId}"] span:last-child`).forEach(el => { el.innerHTML = `<i class="far fa-comment"></i> ${post.comments.length}`; });
    };
    const handleCommentFileUpload = (e) => {
        const file = e.target.files[0]; const postId = parseInt(e.target.dataset.postId); const post = getPost(postId); if (!file || !post) return;
        if (file.type.startsWith('image/')) {
            const objectURL = URL.createObjectURL(file); const newComment = { userId: state.currentUser.id, type: 'image', url: objectURL, filename: file.name, reactions: {}, user: getUser(state.currentUser.id) }; post.comments.push(newComment);
            const commentList = document.querySelector('.modal-container .comment-list');
            if (commentList) { const emptyState = commentList.querySelector('.empty-state'); if (emptyState) emptyState.remove(); const newCommentHTML = getSingleCommentHTML(newComment, post, post.comments.length - 1, state.currentUser); commentList.insertAdjacentHTML('beforeend', newCommentHTML); commentList.scrollTop = commentList.scrollHeight; }
            document.querySelectorAll(`.post-card[data-post-id="${postId}"] .comment-preview, .grid-post-overlay[data-post-id="${postId}"] span:last-child`).forEach(el => { el.innerHTML = `<i class="far fa-comment"></i> ${post.comments.length}`; });
        } else { showToast("Only image files can be posted as comments.", "error"); } e.target.value = null;
    };
    const handleCommentReaction = (postId, commentIndex, emoji) => {
        const post = getPost(postId); const comment = post ? post.comments[commentIndex] : null; if (!comment) return; if (!comment.reactions) comment.reactions = {}; const userId = state.currentUser.id; let userRemoved = false;
        Object.keys(comment.reactions).forEach(existingEmoji => { const userIndex = comment.reactions[existingEmoji].indexOf(userId); if (userIndex > -1) { comment.reactions[existingEmoji].splice(userIndex, 1); if (existingEmoji === emoji) userRemoved = true; } });
        if (!userRemoved) { if (!comment.reactions[emoji]) comment.reactions[emoji] = []; comment.reactions[emoji].push(userId); }
        const commentWrapper = document.querySelector(`.comment-wrapper[data-comment-index="${commentIndex}"]`);
        if (commentWrapper) { const reactionsContainer = commentWrapper.querySelector('.comment-reactions'); if (reactionsContainer) { const reactionsHTML = Object.entries(comment.reactions).filter(([, userIds]) => userIds.length > 0).map(([e, userIds]) => { const userHasReacted = userIds.includes(userId); return `<div class="reaction-tag ${userHasReacted ? 'user-reacted' : ''}" data-action="add-comment-reaction" data-post-id="${postId}" data-comment-index="${commentIndex}" data-emoji="${e}">${e} ${userIds.length}</div>`; }).join(''); reactionsContainer.innerHTML = reactionsHTML; } }
        const popover = document.querySelector(`.comment-wrapper[data-comment-index="${commentIndex}"] .reaction-popover.visible`); if (popover) popover.classList.remove('visible');
    };
    const handleSelectCommentEmoji = (postId, emoji) => { const input = document.querySelector(`.comment-input-form[data-post-id="${postId}"] input[name="commentText"]`); if(input) { input.value += emoji; input.focus(); } handleTogglePicker(postId, 'emoji', 'post'); };
    const handleToggleReactionPopover = (button) => {
        const actionsContainer = button.closest('.comment-actions, .message-actions'); if (!actionsContainer) return;
        const popover = actionsContainer.querySelector('.reaction-popover'); if (!popover) return;
        document.querySelectorAll('.reaction-popover.visible').forEach(p => { if (p !== popover) p.classList.remove('visible'); });
        popover.classList.toggle('visible');
    };
    const updateConversationListLastMessage = (chatId, lastMsg) => {
        const convoItem = document.querySelector(`.conversation-item[data-chat-id="${chatId}"]`);
        if (convoItem) {
            const lastMsgEl = convoItem.querySelector('.last-message');
            if (lastMsgEl) { let lastMsgText = ''; switch (lastMsg.type) { case 'gif': lastMsgText = 'Sent a GIF'; break; case 'image': lastMsgText = 'Sent an image'; break; default: lastMsgText = lastMsg.text; } lastMsgEl.textContent = lastMsgText; }
            convoItem.parentElement.prepend(convoItem);
        }
    };
    
    // --- NEW TRENDING SLIDER ---
    const startSliderInterval = () => {
        clearInterval(sliderInterval);
        sliderInterval = setInterval(() => {
            handleSliderNav('next');
        }, 4000);
    };

    const getTrendingPostsSliderHTML = (posts) => {
        if (!posts || posts.length === 0) return '';
        const slidesHTML = posts.map(post => {
            const author = getUser(post.userId);
            return `
                <div class="slider-slide">
                    <img class="slide-bg" src="${post.imgUrl}" alt="Trending Post">
                    <div class="slide-overlay"></div>
                    <div class="slide-content" data-action="view-profile" data-user-id="${author.id}">
                        <img class="slide-author-pic" src="${author.profilePic}" alt="${author.username}">
                        <span class="slide-author-username">${author.username}</span>
                    </div>
                    <div class="slide-stats">
                        <span><i class="fas fa-heart"></i> ${post.likes.length}</span>
                        <span><i class="far fa-comment"></i> ${post.comments.length}</span>
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div class="trending-posts-slider">
                <div class="slider-track" style="transform: translateX(0%);">
                    ${slidesHTML}
                </div>
            </div>
            <div class="slider-nav">
                <button class="slider-btn prev" data-action="slider-nav" data-direction="prev" title="Previous"><i class="fas fa-chevron-left"></i></button>
                <button class="slider-btn next" data-action="slider-nav" data-direction="next" title="Next"><i class="fas fa-chevron-right"></i></button>
            </div>
        `;
    };
    const renderTrendingPostsSlider = () => {
        const container = document.getElementById('trending-posts-slider-container');
        if (!container) return;
        const trendingPosts = [...state.posts].sort((a, b) => b.likes.length - a.likes.length).slice(0, 5);
        if (trendingPosts.length === 0) {
            container.innerHTML = '';
            clearInterval(sliderInterval);
            return;
        }
        container.innerHTML = getTrendingPostsSliderHTML(trendingPosts);
        state.trendingSliderIndex = 0;
        updateSliderTransform();
        if (!container.dataset.listenersAttached) {
            container.addEventListener('mouseenter', () => clearInterval(sliderInterval));
            container.addEventListener('mouseleave', startSliderInterval);
            container.dataset.listenersAttached = 'true';
        }
        startSliderInterval();
    };
    const handleSliderNav = (direction) => {
        const track = document.querySelector('#trending-posts-slider-container .slider-track');
        if (!track) return;
        const numSlides = track.children.length;
        if (direction === 'next') {
            state.trendingSliderIndex = (state.trendingSliderIndex + 1) % numSlides;
        } else {
            state.trendingSliderIndex = (state.trendingSliderIndex - 1 + numSlides) % numSlides;
        }
        updateSliderTransform();
        startSliderInterval();
    };
    const updateSliderTransform = () => {
        const track = document.querySelector('#trending-posts-slider-container .slider-track');
        if (!track) return;
        track.style.transform = `translateX(-${state.trendingSliderIndex * 100}%)`;
    };

    const updateNavLinks = () => {
        if (!state.currentUser) return;
        document.querySelectorAll('.nav-link').forEach(link => {
            const path = link.dataset.path; const action = link.dataset.action; let isActive = false;
            if (action === 'navigate') { const pageFromPath = (path.split('/')[1] || 'home'); isActive = (state.activePage === pageFromPath); } 
            else if (action === 'open-search') { isActive = state.activeSecondaryView === 'search'; } 
            else if (action === 'open-chat') { isActive = state.activeSecondaryView === 'chat'; }
            link.classList.toggle('active', isActive);
        });
    };

    const handleReelLike = (reelId) => {
        const reel = state.reels.find(r => r.id === reelId);
        if (!reel) return;
    
        const idx = reel.likes.indexOf(state.currentUser.id);
        if (idx > -1) {
            reel.likes.splice(idx, 1);
        } else {
            reel.likes.push(state.currentUser.id);
            if (reel.userId !== state.currentUser.id) {
                createNotification(reel.userId, `<strong>${state.currentUser.username}</strong> liked your reel.`, 'like');
            }
        }
        const isLiked = reel.likes.includes(state.currentUser.id);

        // Update like button and count on the main reel page
        const reelItem = document.querySelector(`.reel-item[data-reel-id="${reelId}"]`);
        if (reelItem) {
            const likeBtn = reelItem.querySelector('.like-btn');
            const likesCount = reelItem.querySelector('.reel-likes-count');
            likeBtn.classList.toggle('liked', isLiked);
            if (isLiked) {
                likeBtn.style.animation = 'like-pop 0.3s ease';
                likeBtn.addEventListener('animationend', () => likeBtn.style.animation = '', { once: true });
            }
            likesCount.textContent = reel.likes.length;
        }
        // Update like button and count in the comments modal if it's open
        const modalItem = document.querySelector(`.reel-comments-modal .like-btn[data-reel-id="${reelId}"]`);
        if (modalItem) {
            const modalLikesCount = document.querySelector(`.reel-comments-modal .reel-likes-count`);
            modalItem.classList.toggle('liked', isLiked);
            modalLikesCount.textContent = reel.likes.length;
        }
    };

    const handlePostReelComment = (reelId, formData) => {
        const text = formData.get('commentText').trim();
        if (!text) return;
        const reel = state.reels.find(r => r.id === reelId);
        if (!reel) return;

        const newComment = {
            userId: state.currentUser.id,
            text,
            reactions: {},
            user: getUser(state.currentUser.id)
        };
        reel.comments.push(newComment);

        if (reel.userId !== state.currentUser.id) {
            createNotification(reel.userId, `<strong>${state.currentUser.username}</strong> commented on your reel.`, 'comment');
        }

        const commentList = document.querySelector('.modal-container .comment-list');
        if (commentList) {
            const emptyState = commentList.querySelector('.empty-state');
            if (emptyState) emptyState.remove();
            const newCommentHTML = getSingleReelCommentHTML(newComment, reel, reel.comments.length - 1, state.currentUser);
            commentList.insertAdjacentHTML('beforeend', newCommentHTML);
            commentList.scrollTop = commentList.scrollHeight;
        }
        
        const reelItemInFeed = document.querySelector(`.reel-item[data-reel-id="${reelId}"] .reel-comments-count`);
        if(reelItemInFeed) reelItemInFeed.textContent = reel.comments.length;
        
        const modalCommentsCount = document.querySelector(`.reel-comments-modal .reel-comments-count`);
        if(modalCommentsCount) modalCommentsCount.textContent = reel.comments.length;
    };

    const handleReelCommentReaction = (reelId, commentIndex, emoji) => {
        const reel = state.reels.find(r => r.id === reelId);
        const comment = reel ? reel.comments[commentIndex] : null;
        if (!comment) return;

        if (!comment.reactions) comment.reactions = {};
        const userId = state.currentUser.id;
        let userRemoved = false;

        Object.keys(comment.reactions).forEach(existingEmoji => {
            const userIndex = comment.reactions[existingEmoji].indexOf(userId);
            if (userIndex > -1) {
                comment.reactions[existingEmoji].splice(userIndex, 1);
                if (existingEmoji === emoji) {
                    userRemoved = true;
                }
            }
        });

        if (!userRemoved) {
            if (!comment.reactions[emoji]) {
                comment.reactions[emoji] = [];
            }
            comment.reactions[emoji].push(userId);
        }
        
        const commentWrapper = document.querySelector(`.modal-content.reel-comments-modal .comment-wrapper[data-comment-index="${commentIndex}"]`);
        if (commentWrapper) {
            commentWrapper.outerHTML = getSingleReelCommentHTML({ ...comment, user: getUser(comment.userId) }, reel, commentIndex, state.currentUser);
        }

        const popover = document.querySelector(`.comment-wrapper[data-comment-index="${commentIndex}"] .reaction-popover.visible`);
        if (popover) popover.classList.remove('visible');
    };
    
    const initReelsObserver = () => {
        const options = {
            root: document.getElementById('reels-container'),
            rootMargin: '0px',
            threshold: 0.8
        };
    
        const callback = (entries, observer) => {
            entries.forEach(entry => {
                const video = entry.target.querySelector('.reel-video');
                if (entry.isIntersecting) {
                    video.play().catch(e => {}); // Catch error if user hasn't interacted yet
                } else {
                    video.pause();
                    video.currentTime = 0;
                }
            });
        };
    
        const observer = new IntersectionObserver(callback, options);
        const targets = document.querySelectorAll('.reel-item');
        targets.forEach(target => observer.observe(target));
    };

    // --- APPLICATION START ---
    init();
})