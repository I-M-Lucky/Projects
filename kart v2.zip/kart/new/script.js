

// --- START OF THREE.JS PARTICLE BACKGROUND ---

class Environment {
  constructor(particle){ 
    this.particle = particle;
    this.container = document.querySelector( '#magic' );
    this.scene = new THREE.Scene();
    this.createCamera();
    this.createRenderer();
    this.setup();
    this.bindEvents();
  }

  bindEvents(){
    window.addEventListener( 'resize', this.onWindowResize.bind( this ));
  }

  setup(){ 
    this.createParticles = new CreateParticles( this.scene, this.particle, this.camera, this.renderer );
  }

  render() {
     this.createParticles.render()
     this.renderer.render( this.scene, this.camera )
  }

  createCamera() {
    this.camera = new THREE.PerspectiveCamera( 65, this.container.clientWidth /  this.container.clientHeight, 1, 10000 );
    this.camera.position.set( 0,0, 100 );
  }

  createRenderer() {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize( this.container.clientWidth, this.container.clientHeight );
    this.renderer.setPixelRatio( Math.min( window.devicePixelRatio, 2));
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.container.appendChild( this.renderer.domElement );
    this.renderer.setAnimationLoop(() => { this.render() })
  }

  onWindowResize(){
    this.camera.aspect = this.container.clientWidth / this.container.clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize( this.container.clientWidth, this.container.clientHeight );
  }
}

class CreateParticles {
	constructor( scene, particleImg, camera, renderer ) {
		this.scene = scene;
		this.particleImg = particleImg;
		this.camera = camera;
		this.renderer = renderer;
		this.raycaster = new THREE.Raycaster();
		this.mouse = new THREE.Vector2(-200, 200);
		this.colorChange = new THREE.Color();
		this.buttom = false;
		this.data = {
			amount: 4000,
			particleSize: 1,
			particleColor: 0xffffff,
			area: 400,
			ease: .05,
		}
		this.setup();
		this.bindEvents();
	}

	setup(){
		const geometry = new THREE.PlaneGeometry( this.visibleWidthAtZDepth( 100, this.camera ), this.visibleHeightAtZDepth( 100, this.camera ));
		const material = new THREE.MeshBasicMaterial( { color: 0x00ff00, transparent: true } );
		this.planeArea = new THREE.Mesh( geometry, material );
		this.planeArea.visible = false;
        this.scene.add(this.planeArea);
		this.createPoints();
	}

	bindEvents() {
		document.addEventListener( 'mousedown', this.onMouseDown.bind( this ));
		document.addEventListener( 'mousemove', this.onMouseMove.bind( this ));
		document.addEventListener( 'mouseup', this.onMouseUp.bind( this ));
	}

	onMouseDown(event){
		this.mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
		this.mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
		const vector = new THREE.Vector3( this.mouse.x, this.mouse.y, 0.5);
		vector.unproject( this.camera );
		const dir = vector.sub( this.camera.position ).normalize();
		const distance = - this.camera.position.z / dir.z;
		this.currenPosition = this.camera.position.clone().add( dir.multiplyScalar( distance ) );
		this.buttom = true;
		this.data.ease = .01;
	}

	onMouseUp(){
		this.buttom = false;
		this.data.ease = .05;
	}

	onMouseMove(event) { 
	    this.mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
	    this.mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
	}

	render( level ){ 
		const time = ((.001 * performance.now())%12)/12;
        const slowTime = performance.now() * 0.0001; // Slower time for ambient effects
		const zigzagTime = (1 + (Math.sin( time * 2 * Math.PI )))/6;
		this.raycaster.setFromCamera( this.mouse, this.camera );
		const intersects = this.raycaster.intersectObject( this.planeArea );
		if ( intersects.length > 0 ) {
			const pos = this.particles.geometry.attributes.position;
			const copy = this.geometryCopy.attributes.position;
			const coulors = this.particles.geometry.attributes.customColor;
			const size = this.particles.geometry.attributes.size;
		    const mx = intersects[ 0 ].point.x;
		    const my = intersects[ 0 ].point.y;
		    const mz = intersects[ 0 ].point.z;

		    for ( var i = 0, l = pos.count; i < l; i++) {
		    	const initX = copy.getX(i);
		    	const initY = copy.getY(i);
		    	const initZ = copy.getZ(i);
		    	let px = pos.getX(i);
		    	let py = pos.getY(i);
		    	let pz = pos.getZ(i);

                // Add ambient drift
                const driftX = Math.sin(slowTime + i * 0.5) * 0.1;
                const driftY = Math.cos(slowTime + i * 0.3) * 0.1;

                // Dynamic base color
                const baseHue = (0.75 + Math.sin(slowTime + i / l) * 0.1);
		    	this.colorChange.setHSL( baseHue, 0.76, 0.52 ) 
		    	coulors.setXYZ( i, this.colorChange.r, this.colorChange.g, this.colorChange.b )
		    	coulors.needsUpdate = true;
		    	size.array[ i ]  = this.data.particleSize;
		    	size.needsUpdate = true;

		    	let dx = mx - px;
		    	let dy = my - py;
		    	const dz = mz - pz;
		    	const mouseDistance = this.distance( mx, my, px, py )
		    	let d = ( dx = mx - px ) * dx + ( dy = my - py ) * dy;
		    	const f = - this.data.area/d;

		    	if( this.buttom ){ 
		    		const t = Math.atan2( dy, dx );
		    		px -= f * Math.cos( t );
		    		py -= f * Math.sin( t );
                    // Color on click (lighter purple)
		    		this.colorChange.setHSL( 0.75 + zigzagTime, 1.0, 0.6)
		    		coulors.setXYZ( i, this.colorChange.r, this.colorChange.g, this.colorChange.b )
		    		coulors.needsUpdate = true;
		    		if ((px > (initX + 70)) || ( px < (initX - 70)) || (py > (initY + 70) || ( py < (initY - 70)))){
                        // Color when pushed far
		    			this.colorChange.setHSL( 0.8, 1.0 , .5 )
		    			coulors.setXYZ( i, this.colorChange.r, this.colorChange.g, this.colorChange.b )
		    			coulors.needsUpdate = true;
		    		}
		    	} else {
			    	if( mouseDistance < this.data.area ){
			    		if(i%5==0){
			    			const t = Math.atan2( dy, dx );
			    			px -= .03 * Math.cos( t );
			    			py -= .03 * Math.sin( t );
                            // Accent color on hover (light purple/pink)
			    			this.colorChange.setHSL( 0.85 , 1.0 , .7 )
			    			coulors.setXYZ( i, this.colorChange.r, this.colorChange.g, this.colorChange.b )
			    			coulors.needsUpdate = true;
							size.array[ i ]  =  this.data.particleSize /1.2;
							size.needsUpdate = true;
			    		}else{
					    	const t = Math.atan2( dy, dx );
					    	px += f * Math.cos( t );
					    	py += f * Math.sin( t );
					    	pos.setXYZ( i, px, py, pz );
					    	pos.needsUpdate = true;
					    	size.array[ i ]  = this.data.particleSize * 1.3 ;
					    	size.needsUpdate = true;
				    	}
			    		if ((px > (initX + 10)) || ( px < (initX - 10)) || (py > (initY + 10) || ( py < (initY - 10)))){
                            // Color on hover edge
			    			this.colorChange.setHSL( 0.8, 1.0 , .6 )
			    			coulors.setXYZ( i, this.colorChange.r, this.colorChange.g, this.colorChange.b )
			    			coulors.needsUpdate = true;
			    			size.array[ i ]  = this.data.particleSize /1.8;
			    			size.needsUpdate = true;
			    		}
			    	}
		    	}
		    	px += ( initX + driftX - px ) * this.data.ease;
		    	py += ( initY + driftY - py ) * this.data.ease;
		    	pz += ( initZ  - pz ) * this.data.ease;
		    	pos.setXYZ( i, px, py, pz );
		    	pos.needsUpdate = true;
		    }
		}
	}

	createPoints(){ 
		let thePoints = [];
        let colors = [];
        let sizes = [];

        const width = this.visibleWidthAtZDepth(100, this.camera) * 1.2;
        const height = this.visibleHeightAtZDepth(100, this.camera) * 1.2;

		for ( let i = 0; i < this.data.amount; i ++ ) {
            const x = THREE.MathUtils.randFloatSpread(width);
            const y = THREE.MathUtils.randFloatSpread(height);
            const z = THREE.MathUtils.randFloatSpread(width);
			const a = new THREE.Vector3( x, y, z );
			thePoints.push( a );
			colors.push( this.colorChange.r, this.colorChange.g, this.colorChange.b);
			sizes.push( 1 )
		}

		let geoParticles = new THREE.BufferGeometry().setFromPoints( thePoints );
		geoParticles.setAttribute( 'customColor', new THREE.Float32BufferAttribute( colors, 3 ) );
		geoParticles.setAttribute( 'size', new THREE.Float32BufferAttribute( sizes, 1) );
		const material = new THREE.ShaderMaterial( {
			uniforms: {
				color: { value: new THREE.Color( 0xffffff ) },
				pointTexture: { value: this.particleImg }
			},
			vertexShader: document.getElementById( 'vertexshader' ).textContent,
			fragmentShader: document.getElementById( 'fragmentshader' ).textContent,
			blending: THREE.AdditiveBlending,
			depthTest: false,
			transparent: true,
		} );
		this.particles = new THREE.Points( geoParticles, material );
		this.scene.add( this.particles );
		this.geometryCopy = new THREE.BufferGeometry();
		this.geometryCopy.copy( this.particles.geometry );
	}

	visibleHeightAtZDepth ( depth, camera ) {
	  const cameraOffset = camera.position.z;
	  if ( depth < cameraOffset ) depth -= cameraOffset;
	  else depth += cameraOffset;
	  const vFOV = camera.fov * Math.PI / 180; 
	  return 2 * Math.tan( vFOV / 2 ) * Math.abs( depth );
	}

	visibleWidthAtZDepth( depth, camera ) {
	  const height = this.visibleHeightAtZDepth( depth, camera );
	  return height * camera.aspect;
	}

	distance (x1, y1, x2, y2){
	    return Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
	}
}
// --- END OF THREE.JS PARTICLE BACKGROUND ---


document.addEventListener('DOMContentLoaded', () => {

    // --- DOM Elements ---
    const getEl = (id) => document.getElementById(id);
    const heroSlider = getEl('hero-slider');
    const trendingAnimeGrid = getEl('trending-anime-grid'); // NEW
    const animeGrid = getEl('anime-grid');
    const genreNav = getEl('genre-nav');
    const gridTitle = getEl('grid-title');
    const searchInput = getEl('search-input');
    const fanFavoritesGrid = getEl('fan-favorites-grid');
    const paginationContainer = getEl('pagination-container');
    // Modals & Overlays
    const animeModal = getEl('anime-modal');
    const videoPlayerModal = getEl('video-player-modal');
    const videoIframe = getEl('video-iframe');
    const searchOverlay = getEl('search-overlay');
    const watchlistModal = getEl('watchlist-modal');
    const premiumModal = getEl('premium-modal');
    const accountModal = getEl('account-modal');
    // Buttons & Interactive Elements
    const watchlistBtn = getEl('watchlist-btn');
    const watchlistCount = getEl('watchlist-count');
    const accountBtn = getEl('account-btn');
    const premiumBtn = getEl('premium-btn');

    // --- State ---
    let currentSlide = 0;
    let slideInterval;
    let searchTimeout;
    let watchlist = JSON.parse(localStorage.getItem('watchlist')) || [];
    // New state for pagination and data management
    let currentPage = 1;
    const itemsPerPage = 12;
    let currentFilteredData = [];


    // --- HELPER FUNCTIONS ---

    /**
     * Shows a toast notification at the bottom of the screen.
     * @param {string} message The message to display.
     * @param {string} type The type of notification ('success', 'error', 'info').
     */
    const showNotification = (message, type = 'success') => {
        const container = getEl('notification-container');
        const notification = document.createElement('div');
        notification.className = `toast ${type}`;
        notification.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i> ${message}`;
        container.appendChild(notification);
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (container.contains(notification)) {
                    container.removeChild(notification);
                }
            }, 500);
        }, 3000);
    };
    
    /**
     * Extracts YouTube video ID from various URL formats.
     * @param {string} url The YouTube URL.
     * @returns {string|null} The video ID or null if not found.
     */
    const getYouTubeID = (url) => {
        if (!url) return null;
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=|embed\/|v\/|)([\w-]{11})/;
        const match = url.match(regex);
        return match ? match[1] : null;
    };
    
    /**
     * Debounce function to limit the rate at which a function gets called.
     * @param {Function} func The function to debounce.
     * @param {number} delay The delay in milliseconds.
     */
    const debounce = (func, delay) => {
        return (...args) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                func.apply(this, args);
            }, delay);
        };
    };


    const updateWatchlist = () => {
        localStorage.setItem('watchlist', JSON.stringify(watchlist));
        watchlistCount.textContent = watchlist.length;
    };

    const showModal = (modal) => modal.classList.add('active');
    const hideModal = (modal) => {
        modal.classList.remove('active');
        // Special case for video player to stop video on close
        if (modal === videoPlayerModal) {
            videoIframe.src = '';
        }
    };
    
    const showVideoPlayer = (url) => {
        const videoId = getYouTubeID(url);
        if (videoId) {
            videoIframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&controls=1&showinfo=0`;
            showModal(videoPlayerModal);
        } else {
            showNotification("Could not play video. Invalid URL.", "error");
            console.error("Invalid YouTube URL:", url);
        }
    };


    // --- RENDER FUNCTIONS ---
    const renderSlider = () => {
        const sliderAnimes = animeData.slice(0, 5);
        heroSlider.innerHTML = `
            ${sliderAnimes.map((anime, index) => `
                <div class="slide ${index === 0 ? 'active' : ''}" data-index="${index}">
                    <div class="slide-bg" style="background-image: url('${anime.img}');"></div>
                    <div class="slide-content">
                        <h1 class="slide-title">${anime.title}</h1>
                        <p class="slide-rating">${'★'.repeat(Math.round(anime.rating))}${'☆'.repeat(5 - Math.round(anime.rating))} | ${anime.rating}</p>
                        <p class="slide-desc">${anime.description}</p>
                        <div class="slide-buttons">
                            <button class="btn btn-primary play-now-btn" data-url="${anime.video}"><i class="fas fa-play"></i> Play Now</button>
                            <button class="btn btn-secondary watch-trailer-btn" data-url="${anime.trailer}">Watch Trailer</button>
                        </div>
                    </div>
                </div>
            `).join('')}
            <div class="slider-nav">
                ${sliderAnimes.map((_, index) => `<div class="slider-dot ${index === 0 ? 'active' : ''}" data-index="${index}"></div>`).join('')}
            </div>
            <div class="slider-progress-container"><div class="slider-progress"></div></div>
        `;
        resetSlideInterval();
    };

    // NEW function to render the static "Trending Now" grid
    const renderTrendingGrid = () => {
        // Use the first 6 items as "trending". This could be replaced with a real trending metric.
        const trendingData = animeData.slice(0, 5);
        trendingAnimeGrid.innerHTML = trendingData.map(anime => `
            <div class="anime-tile" data-id="${anime.id}">
                <img src="${anime.img}" alt="${anime.title}">
                <div class="tile-overlay"><h3 class="tile-title">${anime.title}</h3></div>
            </div>
        `).join('');
    };

    // MODIFIED to handle pagination for the main grid
    const renderAnimeGrid = () => {
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageData = currentFilteredData.slice(start, end);

        if (pageData.length === 0 && currentPage > 1) {
             currentPage--;
             renderAnimeGrid();
             return;
        }

        animeGrid.innerHTML = pageData.map(anime => `
            <div class="anime-tile" data-id="${anime.id}">
                <img src="${anime.img}" alt="${anime.title}">
                <div class="tile-overlay"><h3 class="tile-title">${anime.title}</h3></div>
            </div>
        `).join('');
        
        renderPagination();
    };
    
    // NEW Pagination render function
    const renderPagination = () => {
        const totalPages = Math.ceil(currentFilteredData.length / itemsPerPage);
        paginationContainer.innerHTML = ''; // Clear old buttons
        if (totalPages <= 1) return;

        let buttonsHTML = '';

        // Previous button
        buttonsHTML += `<button class="page-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}><i class="fas fa-chevron-left"></i></button>`;

        // Page number buttons
        for (let i = 1; i <= totalPages; i++) {
            buttonsHTML += `<button class="page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
        }
        
        // Next button
        buttonsHTML += `<button class="page-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}><i class="fas fa-chevron-right"></i></button>`;

        paginationContainer.innerHTML = buttonsHTML;
    };

    const renderGenres = () => {
        const genres = ['All', ...new Set(animeData.flatMap(a => a.genres).filter(g => g))].sort();
        genreNav.innerHTML = genres.map(g => `<button class="genre-btn ${g === 'All' ? 'active' : ''}" data-genre="${g}">${g}</button>`).join('');
    };

    const renderAnimeModal = (anime) => {
        const isInWatchlist = watchlist.includes(anime.id);
        animeModal.innerHTML = `
            <div class="modal-content">
                <button class="close-btn">×</button>
                <header class="modal-header">
                    <img src="${anime.img}" class="modal-banner-img">
                    <div class="modal-header-content"><h2 class="modal-title">${anime.title}</h2></div>
                </header>
                <div class="modal-body">
                    <div class="modal-actions">
                        <button class="btn btn-primary play-now-btn" data-url="${anime.video}"><i class="fas fa-play"></i> Watch Now</button>
                        <button class="btn btn-secondary add-to-watchlist ${isInWatchlist ? 'in-watchlist' : ''}" data-id="${anime.id}"><i class="fas ${isInWatchlist ? 'fa-check' : 'fa-plus'}"></i> ${isInWatchlist ? 'In Watchlist' : 'Add to Watchlist'}</button>
                    </div>
                    <p class="modal-rating"><strong>Rating:</strong> ${'★'.repeat(Math.round(anime.rating))} (${anime.rating})</p>
                    <p class="modal-desc">${anime.description}</p>
                    <div class="modal-seasons">
                        <strong>Seasons:</strong>
                        ${anime.seasons.map((s, i) => `<button class="season-btn ${i === 0 ? 'active' : ''}" data-season-index="${i}">${s.season > 0 ? `Season ${s.season}`: 'Specials'}</button>`).join('')}
                    </div>
                    <div id="episodes-grid" class="episodes-grid">
                        ${Array.from({ length: anime.seasons[0].episodeCount }, (_, i) => `<div class="episode-tile" data-video-url="${anime.video}">Episode ${i + 1}</div>`).join('')}
                    </div>
                </div>
            </div>`;
        showModal(animeModal);
    };

    const renderWatchlistModal = () => {
        const container = getEl('watchlist-items');
        if (watchlist.length === 0) {
            container.innerHTML = `<p class="empty-watchlist-message">Your watchlist is empty. Add some anime to get started!</p>`;
            return;
        }
        const watchlistData = animeData.filter(anime => watchlist.includes(anime.id));
        container.innerHTML = watchlistData.map(anime => `
            <div class="watchlist-item" data-id="${anime.id}">
                <img src="${anime.img}" class="watchlist-item-img">
                <div class="watchlist-item-info">
                    <h4>${anime.title}</h4>
                    <p>${anime.genres.join(', ')}</p>
                    <p>${'★'.repeat(Math.round(anime.rating))}${'☆'.repeat(5 - Math.round(anime.rating))}</p>
                </div>
                <div class="watchlist-item-actions">
                    <button class="btn-icon watchlist-play-btn" data-url="${anime.video}" title="Play"><i class="fas fa-play"></i></button>
                    <button class="btn-icon remove-watchlist" title="Remove"><i class="fas fa-trash"></i></button>
                </div>
            </div>`).join('');
    };

    const renderSearchResults = (results, query) => {
        const grid = getEl('search-results-grid');
        getEl('search-query-display').textContent = query;
        if (results.length === 0) {
            grid.innerHTML = `<p class="no-results-message">No results found for "${query}".</p>`;
            return;
        }
        grid.innerHTML = results.map(anime => `
            <div class="search-result-item" data-id="${anime.id}">
                <img src="${anime.img}" alt="${anime.title}">
                <div class="search-result-info">
                    <h4>${anime.title}</h4>
                    <p>${anime.genres.join(', ')}</p>
                </div>
            </div>`).join('');
    };


    // --- EVENT HANDLERS ---
    const handleSliderNav = (e) => {
        if (e.target.matches('.slider-dot')) {
            const index = parseInt(e.target.dataset.index);
            changeSlide(index);
        } else if (e.target.closest('.play-now-btn, .watch-trailer-btn')) {
            showVideoPlayer(e.target.closest('[data-url]').dataset.url);
        }
    };
    
    const changeSlide = (index) => {
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.slider-dot');
        if (index >= slides.length) index = 0;
        
        document.querySelector('.slide.active')?.classList.remove('active');
        document.querySelector('.slider-dot.active')?.classList.remove('active');
        
        slides[index].classList.add('active');
        dots[index].classList.add('active');
        currentSlide = index;
        resetSlideInterval();
    };

    const resetSlideInterval = () => {
        clearInterval(slideInterval);
        const progressBar = document.querySelector('.slider-progress');
        if(!progressBar) return;

        progressBar.style.transition = 'none';
        progressBar.style.width = '0%';
        void progressBar.offsetWidth; // Trigger reflow
        progressBar.style.transition = 'width 8s linear';
        progressBar.style.width = '100%';
        
        slideInterval = setInterval(() => {
            const slides = document.querySelectorAll('.slide');
            const nextIndex = (currentSlide + 1) % slides.length;
            changeSlide(nextIndex);
        }, 8000);
    };

    const handleAnimeModalEvents = (e) => {
        const target = e.target;
        if (target.matches('.close-btn') || e.target === animeModal) {
            hideModal(animeModal);
        } else if (target.matches('.add-to-watchlist')) {
            const animeId = parseInt(target.dataset.id);
            const index = watchlist.indexOf(animeId);
            if (index > -1) {
                watchlist.splice(index, 1);
                target.innerHTML = `<i class="fas fa-plus"></i> Add to Watchlist`;
                target.classList.remove('in-watchlist');
                showNotification("Removed from watchlist", "info");
            } else {
                watchlist.push(animeId);
                target.innerHTML = `<i class="fas fa-check"></i> In Watchlist`;
                target.classList.add('in-watchlist');
                showNotification("Added to watchlist!", "success");
            }
            updateWatchlist();
        } else if (target.matches('.season-btn')) {
            const animeId = parseInt(target.closest('.modal-content').querySelector('.add-to-watchlist').dataset.id);
            const anime = animeData.find(a => a.id === animeId);
            const seasonIndex = parseInt(target.dataset.seasonIndex);
            const season = anime.seasons[seasonIndex];
            
            const activeSeasonBtn = target.parentElement.querySelector('.active');
            if(activeSeasonBtn) activeSeasonBtn.classList.remove('active');
            target.classList.add('active');
            
            getEl('episodes-grid').innerHTML = Array.from({ length: season.episodeCount }, (_, i) => `<div class="episode-tile" data-video-url="${anime.video}">Episode ${i + 1}</div>`).join('');
        } else if (target.closest('.episode-tile, .play-now-btn')) {
            const button = target.closest('[data-video-url], [data-url]');
            if (button) showVideoPlayer(button.dataset.videoUrl || button.dataset.url);
        }
    };
    
    const handleWatchlistEvents = (e) => {
        const target = e.target;
        if (target.matches('.close-btn') || target.matches('#close-watchlist') || e.target === watchlistModal) {
            hideModal(watchlistModal);
            return;
        }
        const item = target.closest('.watchlist-item');
        if (!item) return;

        const animeId = parseInt(item.dataset.id);
        if (target.closest('.remove-watchlist')) {
            watchlist = watchlist.filter(id => id !== animeId);
            updateWatchlist();
            renderWatchlistModal();
            showNotification("Removed from watchlist", "info");
        } else if (target.closest('.watchlist-play-btn')) {
            showVideoPlayer(target.closest('.watchlist-play-btn').dataset.url);
        } else if (item) {
             const anime = animeData.find(a => a.id === animeId);
             if (anime) {
                hideModal(watchlistModal);
                renderAnimeModal(anime);
             }
        }
    };

    const performSearch = (query) => {
        if (query.length > 1) {
            const results = animeData.filter(a => {
                const titleMatch = a.title && a.title.toLowerCase().includes(query);
                const descriptionMatch = a.description && a.description.toLowerCase().includes(query);
                const genreMatch = a.genres && a.genres.some(g => g && g.toLowerCase().includes(query));
                return titleMatch || descriptionMatch || genreMatch;
            });
            renderSearchResults(results, query);
            showModal(searchOverlay);
        } else {
            hideModal(searchOverlay);
        }
    };

    const handleSearchInput = debounce((e) => {
        const query = e.target.value.toLowerCase().trim();
        performSearch(query);
    }, 300);

    const handlePremiumEvents = (e) => {
        const tile = e.target.closest('.premium-tile');
        if (e.target.matches('.select-plan-btn') && tile) {
            if (tile.classList.contains('selected')) return;

            document.querySelectorAll('.premium-tile').forEach(t => {
                t.classList.remove('selected');
                t.querySelector('.select-plan-btn').textContent = "Choose Plan";
            });
            tile.classList.add('selected');
            tile.querySelector('.select-plan-btn').textContent = "Current Plan";
            const planName = tile.dataset.plan;
            showNotification(`Switched to ${planName} Plan!`, 'success');
        }
    };

    const handleAccountEvents = (e) => {
        const target = e.target;
        
        if (target.id === 'show-register' || target.id === 'show-login') {
             e.preventDefault();
             getEl('login-container').style.display = (target.id === 'show-login' ? 'block' : 'none');
             getEl('register-container').style.display = (target.id === 'show-register' ? 'block' : 'none');
        } else if(target.closest('form')) {
            e.preventDefault();
            const form = target.closest('form');
            const inputs = form.querySelectorAll('input');
            let allFilled = true;
            inputs.forEach(input => {
                if(input.value.trim() === '') allFilled = false;
            });

            if (!allFilled) {
                showNotification('Please fill in all fields.', 'error');
                return;
            }

            hideModal(accountModal);
            if (form.id === 'login-form') {
                showNotification('Login successful! (This is a demo)', 'success');
            } else {
                showNotification('Registration complete! (This is a demo)', 'success');
            }
        }
    };
    
    // --- INITIALIZATION ---
    const init = () => {
        // Defensive check for animeData
        if (typeof animeData === 'undefined' || animeData.length === 0) {
            console.error("Anime data is not loaded or is empty!");
            document.body.innerHTML = '<h1 style="color:white; text-align: center; margin-top: 5rem;">Error: Anime data could not be loaded. Please check data.js and refresh.</h1>';
            return; 
        }

        // Initialize Three.js particle background
        if (typeof THREE !== 'undefined') {
            const manager = new THREE.LoadingManager();
            manager.onLoad = function() { 
                new Environment(particle);
            }
            const particle = new THREE.TextureLoader(manager).load('https://res.cloudinary.com/dfvtkoboz/image/upload/v1605013866/particle_a64uzf.png');
        } else {
            console.error("Three.js is not loaded.");
        }


        renderSlider();
        renderTrendingGrid(); // NEW
        renderGenres();
        updateWatchlist();
        
        // Initial data load for the main grid
        currentFilteredData = [...animeData];
        renderAnimeGrid();

        // General Event Listeners
        heroSlider.addEventListener('click', handleSliderNav);
        genreNav.addEventListener('click', (e) => {
            if (e.target.matches('.genre-btn')) {
                const activeBtn = genreNav.querySelector('.active');
                if(activeBtn) activeBtn.classList.remove('active');
                e.target.classList.add('active');
                const genre = e.target.dataset.genre;
                // UPDATED: Title logic
                gridTitle.textContent = genre === 'All' ? 'Browse All' : genre;
                
                // Filter data and reset pagination
                currentFilteredData = genre === 'All' ? animeData : animeData.filter(a => a.genres.includes(genre));
                currentPage = 1;
                renderAnimeGrid();
            }
        });
        
        // Pagination listener
        paginationContainer.addEventListener('click', (e) => {
            const btn = e.target.closest('.page-btn');
            if (btn && !btn.disabled) {
                currentPage = parseInt(btn.dataset.page);
                renderAnimeGrid();
                animeGrid.scrollIntoView({ behavior: 'smooth' });
            }
        });
        
        // NEW: Generic click handler for any anime tile
        const handleTileClick = (e) => {
            const tile = e.target.closest('.anime-tile');
            if (tile) {
                const anime = animeData.find(a => a.id === parseInt(tile.dataset.id));
                if (anime) renderAnimeModal(anime);
            }
        };

        trendingAnimeGrid.addEventListener('click', handleTileClick); // Listener for trending grid
        animeGrid.addEventListener('click', handleTileClick); // Listener for main grid


        fanFavoritesGrid.addEventListener('click', (e) => {
            const card = e.target.closest('.fan-favorite-card');
            if(card && card.dataset.id) {
                 const anime = animeData.find(a => a.id === parseInt(card.dataset.id));
                 if (anime) renderAnimeModal(anime);
            }
        });
        
        // Modals and Overlays
        animeModal.addEventListener('click', handleAnimeModalEvents);
        watchlistBtn.addEventListener('click', () => { renderWatchlistModal(); showModal(watchlistModal); });
        watchlistModal.addEventListener('click', handleWatchlistEvents);
        premiumBtn.addEventListener('click', () => showModal(premiumModal));
        premiumModal.addEventListener('click', (e) => { 
            if(e.target.matches('.close-btn') || e.target === premiumModal) hideModal(premiumModal); 
        });
        premiumModal.querySelector('.premium-tiles').addEventListener('click', handlePremiumEvents);
        
        accountBtn.addEventListener('click', () => showModal(accountModal));
        accountModal.addEventListener('click', (e) => { 
            if(e.target.matches('.close-btn') || e.target.id === 'close-account' || e.target === accountModal) hideModal(accountModal);
        });
        accountModal.addEventListener('click', handleAccountEvents);

        // Search
        searchInput.addEventListener('input', handleSearchInput);
        getEl('close-search').addEventListener('click', () => hideModal(searchOverlay));
        searchOverlay.addEventListener('click', (e) => {
            if (e.target === searchOverlay) {
                hideModal(searchOverlay);
            } else {
                const item = e.target.closest('.search-result-item');
                if (item) {
                    const anime = animeData.find(a => a.id === parseInt(item.dataset.id));
                    if(anime) {
                        hideModal(searchOverlay);
                        renderAnimeModal(anime);
                    }
                }
            }
        });

        // Video Player Close
        getEl('close-video-player').addEventListener('click', () => hideModal(videoPlayerModal));
        videoPlayerModal.addEventListener('click', (e) => {
             if (e.target === videoPlayerModal) hideModal(videoPlayerModal);
        });

        // Footer CTA button
        getEl('footer-signup-btn').addEventListener('click', () => {
            showModal(accountModal);
            getEl('login-container').style.display = 'none';
            getEl('register-container').style.display = 'block';
        });

        // Scroll Animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, {
            threshold: 0.1
        });

        document.querySelectorAll('.scroll-animate').forEach(el => {
            observer.observe(el);
        });
    };

    // --- EXECUTION FLOW ---
    init();

    const triggerEntryAnimation = () => {
        const tiles = document.querySelectorAll('#anime-grid .anime-tile, #trending-anime-grid .anime-tile');
        const baseDelay = 500;
        tiles.forEach((tile, index) => {
            tile.style.transitionDelay = `${baseDelay + (index * 40)}ms`;
        });
        document.body.classList.remove('page-loading');
    };
    
    window.addEventListener('load', triggerEntryAnimation);
});
