
const animeData = [
    { 
        id: 1, 
        title: "Attack on Titan", 
        img: "https://www.hdwallpapers.in/download/attack_on_titan_shingeki_no_kyojin_4k_hd_anime-1600x900.jpg", 
        video: "https://youtu.be/LV-nazLVmgo?t=2", 
        trailer: "https://youtu.be/LV-nazLVmgo?t=2", 
        rating: 4.5, 
        description: " Attack on Titan is a manga and anime series set in a world where humanity lives inside cities surrounded by massive walls to protect themselves from giant, human-like creatures called Titans.", 
        genres: ["Action", "Drama", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2013)
            { season: 2, episodeCount: 12 }, // Season 2 (2017)
            { season: 3, episodeCount: 22 }, // Season 3 (12 + 10, 2018-2019)
            { season: 4, episodeCount: 30 }  // Season 4 (16 + 12 + 2, 2020-2023)
        ]
    },
    { 
        id: 2, 
        title: "Demon Slayer: Kimetsu no Yaiba", 
        img: "https://4kwallpapers.com/images/wallpapers/demon-slayer-1920x1080-20155.jpg", 
        video: "https://youtu.be/wyiZWYMilgk?t=7", 
        trailer: "https://youtu.be/wyiZWYMilgk?t=7", 
        rating: 4.7, 
        description: "follows Tanjiro Kamado as he becomes a demon slayer after his family is murdered, with his sister Nezuko turning into a demon. Tanjiro's journey aims to avenge his family and find a cure for Nezuko. The series has been praised for its animation and action. ", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 26 }, // Season 1 (2019)
            { season: 2, episodeCount: 18 }, // Mugen Train Arc (7) + Entertainment District Arc (11, 2021-2022)
            { season: 3, episodeCount: 11 }, // Swordsmith Village Arc (2023)
            { season: 4, episodeCount: 8 }   // Hashira Training Arc (2024)
        ]
    },
    { 
        id: 3, 
        title: "My Hero Academia", 
        img: "https://cdn.oneesports.gg/cdn-data/2024/04/My_Hero_Academia_movie_list.jpg", 
        video: "https://youtu.be/Ak-bGeOG1Co?t=1", 
        trailer: "https://youtu.be/Ak-bGeOG1Co?t=1", 
        rating: 4.3, 
        description: "A quirkless boy inherits the powers of the world's greatest hero.", 
        genres: ["Action", "Superhero"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2016)
            { season: 2, episodeCount: 25 }, // Season 2 (2017)
            { season: 3, episodeCount: 25 }, // Season 3 (2018)
            { season: 4, episodeCount: 25 }, // Season 4 (2019-2020)
            { season: 5, episodeCount: 25 }, // Season 5 (2021)
            { season: 6, episodeCount: 25 }, // Season 6 (2022-2023)
            { season: 7, episodeCount: 21 }, // Season 7 (2024)
            { season: 8, episodeCount: 12 }  // Season 8 (2025, estimated)
        ]
    },
    { 
        id: 4, 
        title: "Naruto", 
        img: "https://fwmedia.fandomwire.com/wp-content/uploads/2025/05/23121659/naruto-villages.jpg", 
        video: "https://youtu.be/_ZFlCq13uo8?t=3", 
        trailer: "https://youtu.be/_ZFlCq13uo8?t=3", 
        rating: 4.6, 
        description: "A young ninja dreams of becoming the strongest leader of his village.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 220 } // Naruto (2002-2007)
        ]
    },
    { 
        id: 5, 
        title: "One Piece", 
        img: "https://sm.ign.com/ign_in/screenshot/default/one-piece_2sa6.jpg", 
        video: "https://youtu.be/fA7k-RgS1Vo?t=3", 
        trailer: "https://youtu.be/fA7k-RgS1Vo?t=3", 
        rating: 4.8, 
        description: "A pirate crew searches for the legendary One Piece treasure.", 
        genres: ["Adventure", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 1130 } // Ongoing as of Jan 2025
        ]
    },
    { 
        id: 6, 
        title: "Jujutsu Kaisen", 
        img: "https://i.pinimg.com/736x/ac/43/52/ac4352f877cd4265d69538bd7532b7b3.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        rating: 4.9, 
        description: "A teen battles cursed spirits with newfound sorcery powers.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2020-2021)
            { season: 2, episodeCount: 23 }  // Season 2 (2023)
        ]
    },
    { 
        id: 7, 
        title: "Hunter x Hunter", 
        img: "https://c4.wallpaperflare.com/wallpaper/410/178/349/anime-hunter-x-hunter-gon-css-killua-zoldyck-hd-wallpaper-preview.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        rating: 4.4, 
        description: "A young boy embarks on a journey to become a licensed Hunter.", 
        genres: ["Adventure", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 148 } // 2011 series (2011-2014)
        ]
    },
    { 
        id: 8, 
        title: "Fullmetal Alchemist: Brotherhood", 
        img: "https://images.saymedia-content.com/.image/ar_1:1%2Cc_fill%2Ccs_srgb%2Cq_auto:eco%2Cw_1200/MTc0Mzk0MDQzNjcxNzgyNzYw/full-series-review-fullmetal-alchemist-brotherhood.png", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        rating: 4.7, 
        description: "Two brothers seek the Philosopher's Stone to restore their bodies.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 64 } // Single series (2009-2010)
        ]
    },
    { 
        id: 9, 
        title: "Death Note", 
        img: "https://cdn.myanimelist.net/images/anime/9/9453.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A teen uses a supernatural notebook to eliminate criminals.", 
        genres: ["Thriller", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 37 } // Single series (2006-2007)
        ]
    },
    { 
        id: 10, 
        title: "Tokyo Revengers", 
        img: "https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p20081301_b_v8_aa.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "A man time-travels to save his loved ones from a tragic fate.", 
        genres: ["Action", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2021)
            { season: 2, episodeCount: 13 }, // Christmas Showdown Arc (2023)
            { season: 3, episodeCount: 13 }  // Tenjiku Arc (2023)
        ]
    },
    { 
        id: 11, 
        title: "Naruto: Shippuden", 
        img: "https://cdn.myanimelist.net/images/anime/13/17405.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Naruto returns to face new threats and fulfill his destiny.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 500 } // Single series (2007-2017)
        ]
    },
    { 
        id: 12, 
        title: "Bleach", 
        img: "https://cdn.myanimelist.net/images/anime/3/40451.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A teen gains Soul Reaper powers to battle evil spirits.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 366 }, // Original series (2004-2012)
            { season: 2, episodeCount: 26 }   // Thousand-Year Blood War (2022-2024)
        ]
    },
    { 
        id: 13, 
        title: "Dragon Ball Z", 
        img: "https://cdn.myanimelist.net/images/anime/6/76211.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Goku defends Earth against powerful foes.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 291 } // Single series (1989-1996)
        ]
    },
    { 
        id: 14, 
        title: "Spy x Family", 
        img: "https://cdn.myanimelist.net/images/anime/1441/122795.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A spy, assassin, and telepath form a fake family.", 
        genres: ["Comedy", "Action"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2022)
            { season: 2, episodeCount: 12 }  // Season 2 (2023)
        ]
    },
    { 
        id: 15, 
        title: "Steins;Gate", 
        img: "https://wallpapercat.com/w/full/6/9/d/1629717-1280x1920-phone-hd-steinsgate-background.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "A scientist accidentally invents time travel.", 
        genres: ["Sci-Fi", "Thriller"], 
        seasons: [
            { season: 1, episodeCount: 24 } // Single series (2011)
        ]
    },
    { 
        id: 16, 
        title: "Code Geass: Lelouch of the Rebellion", 
        img: "https://cdn.myanimelist.net/images/anime/5/50331.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A prince uses a mysterious power to lead a rebellion.", 
        genres: ["Mecha", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2006-2007)
            { season: 2, episodeCount: 25 }  // Season 2 (R2, 2008)
        ]
    },
    { 
        id: 17, 
        title: "Haikyuu!!", 
        img: "https://cdn.myanimelist.net/images/anime/7/76014.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A short teen joins a volleyball team to reach the top.", 
        genres: ["Sports", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2014)
            { season: 2, episodeCount: 25 }, // Season 2 (2015-2016)
            { season: 3, episodeCount: 10 }, // Season 3 (2016)
            { season: 4, episodeCount: 25 }  // Season 4 (2020)
        ]
    },
    { 
        id: 18, 
        title: "Neon Genesis Evangelion", 
        img: "https://cdn.myanimelist.net/images/anime/1314/108941.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Teens pilot mechs to fight mysterious beings.", 
        genres: ["Mecha", "Psychological"], 
        seasons: [
            { season: 1, episodeCount: 26 } // Single series (1995-1996)
        ]
    },
    { 
        id: 19, 
        title: "Vinland Saga", 
        img: "https://wallpapers.com/images/featured/vinland-saga-pictures-dikxzidsazb3dqzm.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A Viking seeks revenge in a brutal world.", 
        genres: ["Action", "Historical"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2019)
            { season: 2, episodeCount: 24 }  // Season 2 (2023)
        ]
    },
    { 
        id: 20, 
        title: "Cowboy Bebop", 
        img: "https://cdn.myanimelist.net/images/anime/4/19644.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "Bounty hunters chase criminals across the galaxy.", 
        genres: ["Action", "Sci-Fi"], 
        seasons: [
            { season: 1, episodeCount: 26 } // Single series (1998-1999)
        ]
    },
    { 
        id: 21, 
        title: "Fairy Tail", 
        img: "https://cdn.myanimelist.net/images/anime/5/18179.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "A young mage joins a rowdy wizard guild.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 175 }, // Original series (2009-2013)
            { season: 2, episodeCount: 90 },  // Fairy Tail (2014-2016)
            { season: 3, episodeCount: 51 }   // Final Series (2018-2019)
        ]
    },
    { 
        id: 22, 
        title: "Black Clover", 
        img: "https://cdn.myanimelist.net/images/anime/2/88336.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A magic-less boy aims to become the Wizard King.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 170 } // Single series (2017-2021)
        ]
    },
    { 
        id: 23, 
        title: "Sword Art Online", 
        img: "https://cdn.myanimelist.net/images/anime/11/39717.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.4, 
        description: "Players are trapped in a virtual reality MMORPG.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2012)
            { season: 2, episodeCount: 24 }, // Season 2 (2014)
            { season: 3, episodeCount: 47 }, // Alicization (2018-2020)
            { season: 4, episodeCount: 23 }  // Gun Gale Online (2022)
        ]
    },
    { 
        id: 24, 
        title: "Re:Zero - Starting Life in Another World", 
        img: "https://cdn.myanimelist.net/images/anime/11/79410.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A teen restarts life in a fantasy world after death.", 
        genres: ["Fantasy", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2016)
            { season: 2, episodeCount: 25 }  // Season 2 (2020-2021)
        ]
    },
    { 
        id: 25, 
        title: "One Punch Man", 
        img: "https://cdn.myanimelist.net/images/anime/12/76049.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A hero defeats enemies with one punch.", 
        genres: ["Action", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 12 }, // Season 1 (2015)
            { season: 2, episodeCount: 12 }  // Season 2 (2019)
        ]
    },
    { 
        id: 26, 
        title: "Yuri!!! on Ice", 
        img: "https://cdn.myanimelist.net/images/anime/6/81992.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A figure skater finds inspiration and love.", 
        genres: ["Sports", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Single series (2016)
        ]
    },
    { 
        id: 27, 
        title: "Kubo Won't Let Me Be Invisible", 
        img: "https://cdn.myanimelist.net/images/anime/1079/119349.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 7.2, 
        description: "A high school boy is often unnoticed by others, but a girl always notices him.", 
        genres: ["Comedy", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Season 1 (2023)
        ]
    },
    { 
        id: 28, 
        title: "Blue Lock", 
        img: "https://cdn.myanimelist.net/images/anime/1123/128058.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Teens compete to become Japan’s top soccer striker.", 
        genres: ["Sports", "Thriller"], 
        seasons: [
            { season: 1, episodeCount: 24 } // Season 1 (2022)
        ]
    },
    { 
        id: 29, 
        title: "Mob Psycho 100", 
        img: "https://cdn.myanimelist.net/images/anime/8/80356.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1alance", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "A psychic teen tries to live a normal life.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 12 }, // Season 1 (2016)
            { season: 2, episodeCount: 13 }, // Season 2 (2019)
            { season: 3, episodeCount: 12 }  // Season 3 (2022)
        ]
    },
    { 
        id: 30, 
        title: "Your Name", 
        img: "https://cdn.myanimelist.net/images/anime/5/87048.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "Two teens swap bodies and uncover a cosmic mystery.", 
        genres: ["Romance", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2016, treated as one episode)
        ]
    },
    { 
        id: 31, 
        title: "Erased", 
        img: "https://cdn.myanimelist.net/images/anime/12/76039.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A man goes back in time to prevent a tragedy.", 
        genres: ["Mystery", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Single series (2016)
        ]
    },
    { 
        id: 32, 
        title: "JoJo's Bizarre Adventure", 
        img: "https://cdn.myanimelist.net/images/anime/3/40409.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A family battles supernatural foes across generations.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 26 }, // Season 1 (2012-2013)
            { season: 2, episodeCount: 48 }, // Stardust Crusaders (2014-2015)
            { season: 3, episodeCount: 39 }, // Diamond is Unbreakable (2016)
            { season: 4, episodeCount: 39 }, // Golden Wind (2018-2019)
            { season: 5, episodeCount: 38 }  // Stone Ocean (2021-2022)
        ]
    },
    { 
        id: 33, 
        title: "Gintama", 
        img: "https://cdn.myanimelist.net/images/anime/10/73274.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A samurai takes odd jobs in an alien-occupied Japan.", 
        genres: ["Comedy", "Action"], 
        seasons: [
            { season: 1, episodeCount: 201 }, // Original series (2006-2010)
            { season: 2, episodeCount: 51 },  // Gintama' (2011-2012)
            { season: 3, episodeCount: 13 },  // Enchousen (2012-2013)
            { season: 4, episodeCount: 51 },  // Gintama° (2015-2016)
            { season: 5, episodeCount: 37 }   // Final arcs (2017-2021)
        ]
    },
    { 
        id: 34, 
        title: "Made in Abyss", 
        img: "https://cdn.myanimelist.net/images/anime/6/86733.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A girl explores a dangerous abyss with a robot.", 
        genres: ["Adventure", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2017)
            { season: 2, episodeCount: 12 }  // Season 2 (2022)
        ]
    },
    { 
        id: 35, 
        title: "The Promised Neverland", 
        img: "https://cdn.myanimelist.net/images/anime/1120/96566.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Orphans uncover a dark secret about their home.", 
        genres: ["Mystery", "Horror"], 
        seasons: [
            { season: 1, episodeCount: 12 }, // Season 1 (2019)
            { season: 2, episodeCount: 11 }  // Season 2 (2021)
        ]
    },
    { 
        id: 36, 
        title: "K-On!", 
        img: "https://cdn.myanimelist.net/images/anime/10/76120.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "High school girls form a music club.", 
        genres: ["Comedy", "Music"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2009)
            { season: 2, episodeCount: 26 }  // Season 2 (2010)
        ]
    },
    { 
        id: 37, 
        title: "Violet Evergarden", 
        img: "https://cdn.myanimelist.net/images/anime/1795/95088.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A former soldier writes letters to find her purpose.", 
        genres: ["Drama", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 13 } // Single series (2018)
        ]
    },
    { 
        id: 38, 
        title: "Dr. Stone", 
        img: "https://cdn.myanimelist.net/images/anime/1613/102576.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A teen uses science to rebuild civilization.", 
        genres: ["Science Fiction", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2019)
            { season: 2, episodeCount: 11 }, // Season 2 (2021)
            { season: 3, episodeCount: 22 }  // Season 3 (2023)
        ]
    },
    { 
        id: 39, 
        title: "Konosuba: God's Blessing on This Wonderful World!", 
        img: "https://cdn.myanimelist.net/images/anime/8/77831.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A gamer is reborn in a fantasy world with a useless goddess.", 
        genres: ["Comedy", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 10 }, // Season 1 (2016)
            { season: 2, episodeCount: 10 }, // Season 2 (2017)
            { season: 3, episodeCount: 11 }  // Season 3 (2024)
        ]
    },
    { 
        id: 40, 
        title: "Hunter x Hunter (1999)", 
        img: "https://cdn.myanimelist.net/images/anime/8/2290.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "An older adaptation of a young boy’s journey to become a Hunter.", 
        genres: ["Adventure", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 62 } // Single series (1999-2001)
        ]
    },
    { 
        id: 41, 
        title: "Assassination Classroom", 
        img: "https://cdn.myanimelist.net/images/anime/5/75639.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Students must kill their alien teacher to save Earth.", 
        genres: ["Action", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 22 }, // Season 1 (2015)
            { season: 2, episodeCount: 25 }  // Season 2 (2016)
        ]
    },
    { 
        id: 42, 
        title: "Overlord", 
        img: "https://cdn.myanimelist.net/images/anime/7/88019.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A gamer becomes a powerful overlord in a game world.", 
        genres: ["Fantasy", "Action"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2015)
            { season: 2, episodeCount: 13 }, // Season 2 (2018)
            { season: 3, episodeCount: 13 }, // Season 3 (2018)
            { season: 4, episodeCount: 13 }  // Season 4 (2022)
        ]
    },
    { 
        id: 43, 
        title: "Noragami", 
        img: "https://cdn.myanimelist.net/images/anime/9/77809.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "A minor god teams up with a human girl.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 12 }, // Season 1 (2014)
            { season: 2, episodeCount: 13 }  // Aragoto (2015)
        ]
    },
    { 
        id: 44, 
        title: "No Game No Life", 
        img: "https://cdn.myanimelist.net/images/anime/5/65187.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Siblings conquer a world where games decide everything.", 
        genres: ["Fantasy", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Single series (2014)
        ]
    },
    { 
        id: 45, 
        title: "The Seven Deadly Sins", 
        img: "https://cdn.myanimelist.net/images/anime/8/65409.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "Knights seek to overthrow a corrupt kingdom.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2014-2015)
            { season: 2, episodeCount: 24 }, // Season 2 (2018)
            { season: 3, episodeCount: 24 }, // Season 3 (2019-2020)
            { season: 4, episodeCount: 24 }  // Season 4 (2021)
        ]
    },
    { 
        id: 46, 
        title: "Fruits Basket (2019)", 
        img: "https://cdn.myanimelist.net/images/anime/1494/98251.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A girl befriends a family cursed by the zodiac.", 
        genres: ["Romance", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2019)
            { season: 2, episodeCount: 25 }, // Season 2 (2020)
            { season: 3, episodeCount: 13 }  // Season 3 (2021)
        ]
    },
    { 
        id: 47, 
        title: "Toradora!", 
        img: "https://cdn.myanimelist.net/images/anime/13/22128.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Two teens help each other with their crushes.", 
        genres: ["Romance", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 25 } // Single series (2008-2009)
        ]
    },
    { 
        id: 48, 
        title: "A Silent Voice", 
        img: "https://cdn.myanimelist.net/images/anime/1122/96435.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "A bully seeks redemption with a deaf girl.", 
        genres: ["Drama", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2016, treated as one episode)
        ]
    },
    { 
        id: 49, 
        title: "Clannad: After Story", 
        img: "https://cdn.myanimelist.net/images/anime/13/24647.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "A couple faces life’s challenges after high school.", 
        genres: ["Drama", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 24 } // Single series (2008-2009)
        ]
    },
    { 
        id: 50, 
        title: "Death Parade", 
        img: "https://cdn.myanimelist.net/images/anime/5/71553.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Souls are judged in afterlife games.", 
        genres: ["Drama", "Psychological"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Single series (2015)
        ]
    },
    { 
        id: 51, 
        title: "Trigun", 
        img: "https://cdn.myanimelist.net/images/anime/7/20310.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A gunslinger with a bounty navigates a desert planet.", 
        genres: ["Action", "Sci-Fi"], 
        seasons: [
            { season: 1, episodeCount: 26 } // Single series (1998)
        ]
    },
    { 
        id: 52, 
        title: "Yu Yu Hakusho", 
        img: "https://cdn.myanimelist.net/images/anime/1228/111372.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A teen detective battles demons.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 112 } // Single series (1992-1995)
        ]
    },
    { 
        id: 53, 
        title: "Slam Dunk", 
        img: "https://cdn.myanimelist.net/images/anime/11/19874.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A delinquent joins a basketball team.", 
        genres: ["Sports", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 101 } // Single series (1993-1996)
        ]
    },
    { 
        id: 54, 
        title: "Hunter x Hunter: Greed Island", 
        img: "https://cdn.myanimelist.net/images/hunterxseries/greed_island_poster.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Gon and Killua tackle a dangerous game.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 17 } // OVA series (2002-2004)
        ]
    },
    { 
        id: 55, 
        title: "Bakemonogatari", 
        img: "https://cdn.myanimelist.net/images/anime/5081/93333.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A student encounters supernatural mysteries.", 
        genres: ["Supernatural", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 15 } // Single series (2009-2010)
        ]
    },
    { 
        id: 56, 
        title: "Psycho-Pass", 
        img: "https://cdn.myanimelist.net/images/anime/5/43399.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A cop enforces law in a dystopian future.", 
        genres: ["Sci-Fi", "Thriller"], 
        seasons: [
            { season: 1, episodeCount: 22 }, // Season 1 (2012-2013)
            { season: 2, episodeCount: 11 }, // Season 2 (2014)
            { season: 3, episodeCount: 8 }   // Season 3 (2019)
        ]
    },
    { 
        id: 57, 
        title: "Monogatari Series: Second Season", 
        img: "https://cdn.myanimelist.net/images/anime/3/52133.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "More supernatural tales unfold around Koyomi.", 
        genres: ["Supernatural", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 26 } // Single series (2013)
        ]
    },
    { 
        id: 58, 
        title: "Shirobako", 
        img: "https://cdn.myanimelist.net/images/anime/6/123461.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Young women navigate the anime industry.", 
        genres: ["Comedy", "Drama"], 
        seasons: [
            { season: 1, episodeCount: 24 } // Single series (2014-2015)
        ]
    },
    { 
        id: 59, 
        title: "My Neighbor Totoro", 
        img: "https://upload.wikimedia.org/wikipedia/en/0/My_Neighbor_Totoro_-_Tonari_no_Totoro_%28Movie_Poster%29.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "Sisters meet magical creatures in rural Japan.", 
        genres: ["Fantasy", "Family"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (1988, treated as one episode)
        ]
    },
    { 
        id: 60, 
        title: "Spirited Away", 
        img: "https://upload.wikimedia.org/wikipedia/en/3/30/Spirited_Away_poster.JPG", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.9, 
        description: "A girl navigates a magical spirit world.", 
        genres: ["Fantasy", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2001, treated as one episode)
        ]
    },
    { 
        id: 61, 
        title: "Princess Mononoke", 
        img: "https://upload.wikimedia.org/wikipedia/en/8/8c/Princess_Mononoke_Japanese_poster.png", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A prince battles humans and forest gods.", 
        genres: ["Fantasy", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (1997, treated as one episode)
        ]
    },
    { 
        id: 62, 
        title: "Howl's Moving Castle", 
        img: "https://upload.wikimedia.org/wikipedia/en/a/a0/Howls-moving-castleposter.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A girl joins a wizard in a magical castle.", 
        genres: ["Fantasy", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2004, treated as one episode)
        ]
    },
    { 
        id: 63, 
        title: "Fullmetal Alchemist (2003)", 
        img: "https://cdn.myanimelist.net/images/anime/10/75815.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4",
 
        rating: 4.6, 
        genres: ["Action" , "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 51 } // Single series (2003-2004)
        ]
    },
    { 
        id: 64, 
        title: "Berserk (1997)", 
        img: "https://cdn.myanimelist.net/images/anime/12/1850.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 

        rating: 4.6, 
        description: "A mercenary joins a dark fantasy epic.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 25 } // Single series (1997-1998)
        ]
    },
    { 
        id: 65, 
        title: "Akira", 
        img: "https://upload.wikimedia.org/wikipedia/en/5/5d/Akira_%281988%29_film_poster.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A biker uncovers a psychic conspiracy in Neo-Tokyo.", 
        genres: ["Sci-Fi", "Action"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (1988, treated as one episode)
        ]
    },
    { 
        id: 66, 
        title: "Grave of the Fireflies", 
        img: "https://upload.wikimedia.org/wikipedia/en/a/a5/Grave_of_the_Fireflies_Japanese_poster.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 
4.9, 
        description: "Siblings struggle to survive in Japan.", 
        genres: ["Drama", "War"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (1988, treated as one episode)
        ]
    },
    { 
        id: 67, 
        title: "Ghost in the Shell (1995)", 
        img: "https://upload.wikimedia.org/wikipedia/en/7/7f/Ghost_in_the_Shell_%281995%29_Japanese_poster.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.8, 
        description: "A cyborg cop faces existential threats.", 
        genres: ["Sci-Fi", "Action"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (1995, treated as one episode)
        ]
    },
    { 
        id: 68, 
        title: "Hunter x Hunter: Phantom Rouge", 
        img: "https://cdn.myanimelist.net/images/hunter-x-hunter/phantom_rouge.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "Kurapika faces a new enemy in a movie adventure.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2013, treated as one episode)
        ]
    },
    { 
        id: 69, 
        title: "Hellsing Ultimate", 
        img: "https://cdn.myanimelist.net/images/anime/6/7333.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A vampire hunts supernatural threats.", 
        genres: ["Action", "Horror"], 
        seasons: [
            { season: 1, episodeCount: 10 } // Single series (OVA, 2006-2012)
        ]
    },
    { 
        id: 70, 
        title: "Attack on Titan: Junior High", 
        img: "https://cdn.myanimelist.net/images/anime/3/73585.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.4, 
        description: "A comedic spin-off of Attack on Titan in a school setting.", 
        genres: ["Comedy", "Parody"], 
        seasons: [
            { season: 1, episodeCount: 12 } // Single series (2015)
        ]
    },
    { 
        id: 71, 
        title: "Durarara!!", 
        img: "https://cdn.myanimelist.net/images/anime/10/23195.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Urban legends and gangs intertwine in Ikebukuro.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 24 }, // Season 1 (2010)
            { season: 2, episodeCount: 36 }  // Season 2 (2015-2016)
        ]
    },
    { 
        id: 72, 
        title: "Space Dandy", 
        img: "https://cdn.myanimelist.net/images/anime/4/56611.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.5, 
        description: "A dandy hunts aliens in a psychedelic universe.", 
        genres: ["Comedy", "Sci-Fi"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2014)
            { season: 2, episodeCount: 13 }  // Season 2 (2014)
        ]
    },
    { 
        id: 73, 
        title: "Hunter x Hunter: The Last Mission", 
        img: "https://cdn.myanimelist.net/images/hunter_x_hunter_last_mission.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.4, 
        description: "Hunters face a dark conspiracy.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 1 } // Movie (2013, treated as one episode)
        ]
    },
    { 
        id: 74, 
        title: "Fate/Zero", 
        img: "https://cdn.myanimelist.net/images/anime/2/30749.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "Mages battle for the Holy Grail.", 
        genres: ["Action","Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 13 }, // Season 1 (2011)
            { season: 2, episodeCount: 12 }  // Season 2 (2012)
        ]
    },
    { 
        id: 75, 
        title: "Fate/stay night: Unlimited Blade Works", 
        img: "https://cdn.myanimelist.net/images/anime/12/67333.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 
4.7, 
        description: "A teen fights in a deadly Holy Grail War.", 
        genres: 
["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 12 }, // Season 1 (2014)
            { season: 2, episodeCount: 13 }  // Season 2 (2015)
        ]
    },
    { 
        id: 76, 
        title: "Magi: The Labyrinth of Magic", 
        img: "https://cdn.myanimelist.net/images/Magi/11/42773.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A boy explores magical dungeons.", 
        genres: ["Action", "Fantasy"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2012)
            { season: 2, episodeCount: 25 }  // Season 2 (2013)
        ]
    },
    { 
        id: 77, 
        title: "Kill la Kill", 
        img: "https://cdn.myanimelist.net/images/anime/8/1032/1234/56491.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A girl seeks answers with a living uniform.", 
        genres: ["Action", "Comedy"], 
        seasons: [
            { season: 1, episodeCount: 24 } // Single series (2013-2014)
        ]
    },
    { 
        id: 78, 
        title: "Blue Exorcist", 
        img: "https://cdn.myanimelist.net/images/anime/10/28306.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A teen trains to fight demons as Satan’s son.", 
        genres: ["Action", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 25 }, // Season 1 (2011)
            { season: 2, episodeCount: 12 }, // Season 2 (2017)
            { season: 3, episodeCount: 12 }  // Season 3 (2024)
        ]
    },
    { 
        id: 79, 
        title: "Inuyasha", 
        img: "https://cdn.myanimelist.net/images/anime/1581/95329.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "A girl travels to feudal Japan with a half-demon.", 
        genres: ["Adventure", "Romance"], 
        seasons: [
            { season: 1, episodeCount: 167 }, // Original series (2000-2004)
            { season: 2, episodeCount: 26 }   // The Final Act (2009-2010)
        ]
    },
    { 
        id: 80, 
        title: "Hunter x Hunter: Yorknew City", 
        img: "https://cdn.myanimelist.net/images/hunter_x_hunter_yorknew.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Gon and friends face the Phantom Troupe.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 21 } // OVA series (2002)
        ]
    },
    { 
        id: 81, 
        title: "Angel Beats!", 
        img: "https://cdn.myanimelist.net/images/anime/10/22061.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "Teens fight against fate in the afterlife.", 
        genres: ["Drama", "Supernatural"], 
        seasons: [
            { season: 1, episodeCount: 13 } // Single series (2010)
        ]
    },
    { 
        id: 82, 
        title: "Hunter x Hunter: Greed Island Final", 
        img: "https://static.wikia.nocookie.net/hunterxhunter/images/d/d0/GI_poster_2011.png", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.6, 
        description: "The final battles in the Greed Island game.", 
        genres: ["Action", "Adventure"], 
        seasons: [
            { season: 1, episodeCount: 14 } // OVA series (2004)
        ]
    },
    { 
        id: 83, 
        title: "Samurai Champloo", 
        img: "https://static.wikia.nocookie.net/voiceacting/images/5/54/Samurai_Champloo_DVD_Cover.jpg", 
        video: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", 
        trailer: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_1mb.mp4", 
        rating: 4.7, 
        description: "A girl and two samurai journey through Edo Japan.", 
        genres: ["Adventure", "Action"], 
        seasons: [
            { season: 1, episodeCount: 26 } // Single series (2004-2005)
        ]
    },
];
