// --- STATE ---
let products = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
let recentlyViewed = JSON.parse(localStorage.getItem('recentlyViewed')) || [];
let compareItems = JSON.parse(localStorage.getItem('compareItems')) || [];
let currentUser = null;
let authToken = null;
let currentPage = 1;
const productsPerPage = 8;
let currentProductId = null;
let currentFilteredProducts = [];
let slideInterval = null;
let currentSlide = 0;
let debounceTimer = null;
let currentPageModal = null;

// --- DOM ELEMENTS ---
const pageModal = document.getElementById('pageModal');
const pageModalTitle = document.getElementById('pageModalTitle');
const pageModalContentContainer = document.getElementById('pageModalContentContainer');
const loadingSpinner = document.getElementById('loading');

// --- UTILITY ---
function showToast(message) { const toast = document.getElementById('toast'); toast.textContent = message; toast.style.display = 'block'; setTimeout(() => { toast.style.display = 'none'; }, 3000); }
function updateCounts() { document.getElementById('cartCount').textContent = cart.reduce((s, i) => s + i.quantity, 0); document.getElementById('wishlistCount').textContent = wishlist.length; document.getElementById('compareCount').textContent = compareItems.length; }
function animateItemsIn(container) { if(!container) return; const items = container.children; Array.from(items).forEach((item, index) => { setTimeout(() => { item.classList.add('item-visible'); }, index * 60); }); }
function refreshAnimations(container) { if (!container) return; Array.from(container.children).forEach(child => { child.classList.remove('item-visible'); }); setTimeout(() => { animateItemsIn(container); }, 100); }
function refreshHomePageAnimations() { ['#productGrid', '#featuredBrands', '#recentlyViewed'].forEach(selector => { const container = document.querySelector(selector); refreshAnimations(container); }); const dealCard = document.getElementById('dealOfTheDay'); if (dealCard) { dealCard.classList.remove('item-visible'); setTimeout(() => dealCard.classList.add('item-visible'), 100); } }

// --- INITIALIZATION & NAVIGATION ---
document.addEventListener('DOMContentLoaded', async () => {
    updateCounts();
    checkLoggedInUser();
    try {
        loadingSpinner.style.display = 'block';
        const response = await fetch('/api/products');
        if (!response.ok) throw new Error('Network error');
        products = await response.json();
        currentFilteredProducts = [...products];
        renderSlider();
        await renderDealOfTheDay();
        await renderFeaturedBrands();
        filterProducts();
        renderRecentlyViewed();
        startAutoSlide();
        handleNavigation();
        initializeSectionVideos(); 
        initializeDragonCursor(); 
    } catch (error) { showToast('Failed to load products'); console.error(error); }
    finally { loadingSpinner.style.display = 'none'; }
    window.addEventListener('popstate', handlePopState);
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('signupForm').addEventListener('submit', handleSignup);
});

// --- AUTHENTICATION FUNCTIONS ---
function checkLoggedInUser() {
    const token = localStorage.getItem('shopsphere_token');
    const user = localStorage.getItem('shopsphere_user');
    if (token && user) {
        authToken = token;
        currentUser = JSON.parse(user);
        updateUIAfterLogin();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Login failed');
        localStorage.setItem('shopsphere_token', data.token);
        localStorage.setItem('shopsphere_user', JSON.stringify(data.user));
        authToken = data.token;
        currentUser = data.user;
        showToast(data.message);
        closeLoginModal();
        updateUIAfterLogin();
    } catch (error) {
        showToast(error.message);
        console.error('Login error:', error);
    }
}

async function handleSignup(e) {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Signup failed');
        showToast(data.message);
        closeSignupModal();
        showLoginModal();
    } catch (error) {
        showToast(error.message);
        console.error('Signup error:', error);
    }
}

function handleLogout() {
    localStorage.removeItem('shopsphere_token');
    localStorage.removeItem('shopsphere_user');
    authToken = null;
    currentUser = null;
    updateUIAfterLogout();
    showToast('You have been logged out.');
}

function updateUIAfterLogin() {
    const userIconContainer = document.getElementById('user-icon-container');
    if (userIconContainer) {
        userIconContainer.innerHTML = `<a href="#" onclick="handleLogout()" aria-label="Logout" title="Logout ${currentUser.name}"><i class="fas fa-sign-out-alt"></i></a>`;
    }
}

function updateUIAfterLogout() {
    const userIconContainer = document.getElementById('user-icon-container');
    if (userIconContainer) {
        userIconContainer.innerHTML = `<a href="#" onclick="showLoginModal()" aria-label="Login" title="Login"><i class="fas fa-user"></i></a>`;
    }
}

// --- NEW: Reusable Confirmation Modal Function ---
function showConfirmModal(title, text, onConfirm) {
    const confirmModal = document.getElementById('confirmModal');
    const confirmTitle = document.getElementById('confirmModalTitle');
    const confirmText = document.getElementById('confirmModalText');
    const btnYes = document.getElementById('confirmBtnYes');
    const btnNo = document.getElementById('confirmBtnNo');

    confirmTitle.textContent = title;
    confirmText.textContent = text;
    
    confirmModal.classList.add('active');

    const handleConfirm = () => {
        confirmModal.classList.remove('active');
        onConfirm();
    };

    const handleCancel = () => {
        confirmModal.classList.remove('active');
    };

    const newBtnYes = btnYes.cloneNode(true);
    btnYes.parentNode.replaceChild(newBtnYes, btnYes);
    newBtnYes.addEventListener('click', handleConfirm);

    const newBtnNo = btnNo.cloneNode(true);
    btnNo.parentNode.replaceChild(newBtnNo, btnNo);
    newBtnNo.addEventListener('click', handleCancel);

    confirmModal.onclick = (e) => {
        if(e.target === confirmModal) {
            handleCancel();
        }
    };
}


// --- CURSOR & ANIMATIONS ---
function initializeDragonCursor() {
    const svgContainer = document.getElementById('svg-cursor-container');
    if (!svgContainer) return;
    const dragonScale = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--dragon-cursor-scale').trim());
    const xmlns = "http://www.w3.org/2000/svg";
    const xlinkns = "http://www.w3.org/1999/xlink";
    let width, height;
    const resize = () => { width = window.innerWidth; height = window.innerHeight; };
    window.addEventListener("resize", resize, false);
    resize();
    const N = 40;
    const elems = [];
    for (let i = 0; i < N; i++) elems[i] = { use: null, x: width / 2, y: height / 2 };
    const pointer = { x: width / 2, y: height / 2 };
    window.addEventListener('pointermove', (e) => {
        pointer.x = e.clientX;
        pointer.y = e.clientY;
    }, false);
    const prepend = (use, i) => {
        const elem = document.createElementNS(xmlns, "use");
        elems[i].use = elem;
        elem.setAttributeNS(xlinkns, "xlink:href", "#" + use);
        svgContainer.prepend(elem);
    };
    for (let i = 1; i < N; i++) {
        if (i === 1) prepend("Cabeza", i);
        else if (i === 8 || i === 14) prepend("Aletas", i);
        else prepend("Espina", i);
    }
    const run = () => {
        let head = elems[0];
        head.x += (pointer.x - head.x) / 10;
        head.y += (pointer.y - head.y) / 10;
        for (let i = 1; i < N; i++) {
            let current = elems[i];
            let prev = elems[i - 1];
            const angle = Math.atan2(current.y - prev.y, current.x - prev.x);
            current.x += (prev.x - current.x + (Math.cos(angle) * (100 - i)) / 5) / 4;
            current.y += (prev.y - current.y + (Math.sin(angle) * (100 - i)) / 5) / 4;
            const baseSegmentScale = (162 + 4 * (1 - i)) / 50;
            const finalScale = baseSegmentScale * dragonScale;
            current.use.setAttributeNS(
                null,
                "transform",
                `translate(${(prev.x + current.x) / 2},${(prev.y + current.y) / 2}) rotate(${ (180 / Math.PI) * angle }) scale(${finalScale},${finalScale})`
            );
        }
        requestAnimationFrame(run);
    };
    run();
}

function initializeSectionVideos() {
    const videoSources = [
        'https://storage.googleapis.com/pinhole-about-assets-prod-asia/RNDR_TunnelVidoes_stretched_005_1920x1296.mp4',
        'https://storage.googleapis.com/pinhole-about-assets-prod-asia/video-section/video.mp4'
    ];
    const sections = document.querySelectorAll('.home-section');
    sections.forEach((section, index) => {
        const videoElement = document.createElement('video');
        videoElement.src = videoSources[index % videoSources.length];
        videoElement.autoplay = true; videoElement.loop = true; videoElement.muted = true; videoElement.playsInline = true;
        videoElement.classList.add('section-background-media');
        const overlayElement = document.createElement('div');
        overlayElement.classList.add('section-background-overlay');
        section.prepend(videoElement); section.prepend(overlayElement);
    });
}

// --- NAVIGATION & MODAL MANAGEMENT ---
function handleNavigation() { const hash = window.location.hash.replace(/^#/, ''); closeAllModals(); const targetModal = hash || 'home'; if (targetModal !== 'home' && targetModal !== '') { const functionName = `show${targetModal.charAt(0).toUpperCase() + targetModal.slice(1)}Modal`; if (typeof window[functionName] === 'function') { window[functionName](); } } else { navigateToHome(); } }
function handlePopState(e) { if (!e.state || !e.state.modal || e.state.modal === 'home') { closePageModal(false); } else { handleNavigation(); } }
function updateNavbarActiveState() { document.querySelectorAll('.navbar-custom a[data-target-section]').forEach(link => { const target = link.dataset.targetSection; const isActive = (target === 'home' && !currentPageModal) || (target === currentPageModal); link.classList.toggle('navbar-item-active', isActive); link.classList.toggle('navbar-item-inactive', !isActive); }); }
function navigateToHome() { if (currentPageModal) { closePageModal(); } document.getElementById('mainContent').scrollIntoView({ behavior: 'smooth' }); }
async function showPageModal(title, getContentFunction, sectionName) { pageModalTitle.textContent = title; pageModalContentContainer.innerHTML = '<div class="modal-loader">Loading...</div>'; pageModal.classList.add('active'); document.body.style.overflow = 'hidden'; if (history.state?.modal !== sectionName) { history.pushState({ modal: sectionName }, title, `#${sectionName}`); } currentPageModal = sectionName; updateNavbarActiveState(); setTimeout(async () => { const contentHTML = await getContentFunction(); pageModalContentContainer.innerHTML = contentHTML; const grid = pageModalContentContainer.querySelector('.product-grid, .category-grid, #cartItems, #orderList, #compareTable'); if (grid) { animateItemsIn(grid); } const singleItem = pageModalContentContainer.querySelector('.item-visible'); if(singleItem && !grid) { animateItemsIn(pageModalContentContainer); } const checkoutForm = document.getElementById('checkoutForm'); if (checkoutForm) { checkoutForm.addEventListener('submit', handleCheckoutSubmit); } }, 100); }
function closePageModal(pushHistory = true) { pageModal.classList.remove('active'); document.body.style.overflow = 'auto'; if(pushHistory) history.pushState({ modal: 'home' }, 'Home', location.pathname); currentPageModal = null; updateNavbarActiveState(); refreshHomePageAnimations(); }
function showCategoriesModal() { showPageModal('Browse by Category', getCategoriesContent, 'categories'); }
function showCartModal() { showPageModal('Your Cart', getCartContent, 'cart'); }
function showCheckoutModal() { showPageModal('Checkout', getCheckoutContent, 'checkout'); }
function showOrdersModal() { showPageModal('My Orders', getOrdersContent, 'orders'); }
function showWishlistModal() { showPageModal('Your Wishlist', getWishlistContent, 'wishlist'); }
function showCompareModal() { showPageModal('Compare Products', getCompareContent, 'compare'); }
async function showCategoryProductsModal(categoryName) { const title = categoryName.charAt(0).toUpperCase() + categoryName.slice(1); const getContent = async () => { const res = await fetch(`/api/products?category=${categoryName}`); const categoryProducts = await res.json(); const html = categoryProducts.length > 0 ? categoryProducts.map(p => renderProductCard(p)).join('') : '<p class="item-visible" style="text-align: center;">No products found in this category.</p>'; return `<div class="product-grid">${html}</div>`; }; showPageModal(title, getContent, `category-${categoryName}`); }
async function showBrandProductsModal(brandName) { const title = `Brand: ${brandName}`; const getContent = async () => { const brandProducts = products.filter(p => p.brand === brandName); const html = brandProducts.length > 0 ? brandProducts.map(p => renderProductCard(p)).join('') : '<p class="item-visible" style="text-align: center;">No products found for this brand.</p>'; return `<div class="product-grid">${html}</div>`; }; showPageModal(title, getContent, `brand-${brandName}`); }
function closeAllModals() { document.querySelectorAll('.modal').forEach(m => m.classList.remove('active')); document.body.style.overflow = 'auto'; currentPageModal = null; }
async function showFullDetailsModal(productId) {
    const modal = document.getElementById('fullDetailsModal');
    const contentEl = document.getElementById('fullDetailsModalContent');
    contentEl.innerHTML = '<div class="modal-loader">Loading Details...</div>';
    modal.classList.add('active'); document.body.style.overflow = 'hidden';
    try {
        const res = await fetch(`/api/products/${productId}`);
        if (!res.ok) throw new Error('Product not found');
        const p = await res.json();
        const actualReviews = p.reviews || [];
        currentProductId = productId;
        if (!recentlyViewed.some(rv => rv.id === productId)) { recentlyViewed.unshift({ id: p.id }); if(recentlyViewed.length > 10) recentlyViewed.pop(); localStorage.setItem('recentlyViewed', JSON.stringify(recentlyViewed)); renderRecentlyViewed(); }
        const avgRating = actualReviews.length > 0 ? (actualReviews.reduce((s, r) => s + r.rating, 0) / actualReviews.length) : p.rating;
        const relatedProducts = products.filter(relP => relP.category === p.category && relP.id !== p.id).slice(0, 4);
        const relatedProductsHTML = relatedProducts.length > 0 ? ` <div class="details-modal-section"> <h3>Related Products</h3> <div class="details-modal-grid">${relatedProducts.map(renderMiniProductCard).join('')}</div> </div>` : '';
        const alsoLikeProducts = products.filter(likeP => likeP.category !== p.category).sort(() => 0.5 - Math.random()).slice(0, 4);
        const alsoLikeProductsHTML = alsoLikeProducts.length > 0 ? ` <div class="details-modal-section"> <h3>You Might Also Like</h3> <div class="details-modal-grid">${alsoLikeProducts.map(renderMiniProductCard).join('')}</div> </div>` : '';
        contentEl.innerHTML = ` <div class="details-modal-layout item-visible"> <div class="details-modal-image"><img src="${p.image}" alt="${p.name}" loading="lazy"></div> <div class="details-modal-info"> <h2>${p.name}</h2><p class="price">$${p.price.toFixed(2)}</p> <div class="rating">${'★'.repeat(Math.round(p.rating))}${'☆'.repeat(5 - Math.round(p.rating))}</div> <p>${p.description}</p><p><strong>Category:</strong> ${p.category}</p><p><strong>Brand:</strong> ${p.brand}</p> <div class="details-modal-actions"><button class="button-fill-effect" onclick="addToCart(event, ${p.id})"><span>Add to Cart</span></button><button class="button-fill-effect" onclick="addToWishlist(event, ${p.id})"><span>Add to Wishlist</span></button></div> </div> </div> <div class="details-modal-section"> <h3>Specifications</h3> <ul><li><strong>Rating:</strong> ${p.rating}/5.0</li><li><strong>In Stock:</strong> Yes</li><li><strong>SKU:</strong> ${'SKU' + p.id.toString().padStart(6,'0')}</li></ul> </div> <div class="details-modal-section"> <h3 id="reviewTitle">Customer Reviews (${actualReviews.length})</h3> ${actualReviews.length > 0 ? `<p><strong>Average:</strong> ${'★'.repeat(Math.round(avgRating))}${'☆'.repeat(5-Math.round(avgRating))} (${avgRating.toFixed(1)})</p>`:''} <div class="reviews-list"> ${actualReviews.length > 0 ? actualReviews.map(r => `<div class="review"><p><strong>Rating:</strong> ${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</p><p>${r.text}</p></div>`).join(''):'<p>Be the first to leave a review!</p>'} </div> <form class="review-form"> <h4 style="color:#fff; margin-top:1.5rem;">Leave a Review</h4> <div class="form-group"><textarea id="reviewText" required placeholder=" "></textarea><label for="reviewText">Your Review</label></div> <select id="reviewRating" aria-label="Select rating"> <option value="5">5 Stars</option><option value="4">4 Stars</option><option value="3">3 Stars</option><option value="2">2 Stars</option><option value="1">1 Star</option> </select> <button type="button" onclick="submitReview()" class="button-fill-effect"><span>Submit Review</span></button> </form> </div> ${relatedProductsHTML} ${alsoLikeProductsHTML}`;
        animateItemsIn(contentEl);
    } catch (e) {
        contentEl.innerHTML = '<p>Sorry, product not found.</p>';
        console.error(e);
    }
}
function closeFullDetailsModal() { document.getElementById('fullDetailsModal').classList.remove('active'); document.body.style.overflow = 'auto'; currentProductId = null; refreshHomePageAnimations(); }
async function submitReview() {
    if (!currentProductId) return;
    if (!currentUser || !authToken) {
        showToast('Please log in to leave a review.');
        showLoginModal();
        return;
    }
    const txtEl = document.getElementById('reviewText');
    const text = txtEl.value.trim();
    const rating = parseInt(document.getElementById('reviewRating').value);
    if (!text) {
        showToast('Please enter a review');
        return;
    }
    try {
        const res = await fetch('/api/reviews', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
            body: JSON.stringify({ productId: currentProductId, rating, text })
        });
        if (!res.ok) throw new Error('Failed to submit');
        showToast('Review submitted!');
        showFullDetailsModal(currentProductId);
    } catch (e) {
        showToast('Error submitting review');
        console.error(e);
    }
}
function toggleMenu() { document.getElementById('mobile-menu').classList.toggle('active'); }
function showLoginModal() { document.getElementById('loginModal').classList.add('active'); }
function closeLoginModal() { document.getElementById('loginModal').classList.remove('active'); refreshHomePageAnimations(); }
function showSignupModal() { closeLoginModal(); document.getElementById('signupModal').classList.add('active'); }
function closeSignupModal() { document.getElementById('signupModal').classList.remove('active'); refreshHomePageAnimations(); }
function showQuickView(event, productId) { event.stopPropagation(); const modal = document.getElementById('quickViewModal'); const p = products.find(pr => pr.id === productId); if (!p) return; document.getElementById('quickViewContent').innerHTML = `<img src="${p.image}" alt="${p.name}" style="width:200px;height:200px;object-fit:cover;border-radius:1rem;margin-right:1.5rem;"><div style="display:flex;flex-direction:column;justify-content:center;"><h3>${p.name}</h3><p style="color:#fff">$${p.price.toFixed(2)}</p><p>${p.description.substring(0,100)}...</p><br><button class="button-fill-effect" onclick="closeQuickViewModal();showFullDetailsModal(${p.id})"><span>View Full Details</span></button></div>`; modal.classList.add('active'); }
function closeQuickViewModal() { document.getElementById('quickViewModal').classList.remove('active'); refreshHomePageAnimations(); }

async function showOrderDetails(orderId) {
    if (!currentUser || !authToken) {
        showToast('Please log in to view order details.');
        return;
    }
    const modal = document.getElementById('orderDetailsModal');
    const contentEl = document.getElementById('orderDetailsContent');
    const trackingEl = document.getElementById('orderTracking');
    contentEl.innerHTML = '<div class="modal-loader">Loading Details...</div>';
    trackingEl.innerHTML = '';
    modal.classList.add('active');
    try {
        const res = await fetch(`/api/orders/${orderId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        if (!res.ok) {
            const errData = await res.json();
            throw new Error(errData.message || 'Could not fetch order details.');
        }
        const order = await res.json();
        const itemsHTML = order.items.map(item => 
            `<p>${item.name} x ${item.quantity} (@ $${item.price_at_purchase.toFixed(2)} each)</p>`
        ).join('');
        contentEl.innerHTML = `
            <h3>Items for Order #${order.id.toString().padStart(5, '0')}</h3>
            ${itemsHTML}
            <p><strong>Total: $${order.total_price.toFixed(2)}</strong></p>
            <p><strong>Status:</strong> ${order.status}</p>
            <p><strong>Order Date:</strong> ${new Date(order.order_date).toLocaleDateString()}</p>
        `;
        const isProcessing = order.status === 'Delivered' || order.status === 'Processing';
        const isDelivered = order.status === 'Delivered';
        trackingEl.innerHTML = `
            <div class="tracking-timeline">
                <div class="tracking-step completed"><span class="dot"></span><p>Placed</p></div>
                <div class="tracking-step ${isProcessing ? 'completed' : ''}"><span class="dot"></span><p>Processing</p></div>
                <div class="tracking-step ${isDelivered ? 'completed' : ''}"><span class="dot"></span><p>Delivered</p></div>
            </div>`;
    } catch (error) {
        showToast(error.message);
        contentEl.innerHTML = `<p>${error.message}</p>`;
        console.error('showOrderDetails error:', error);
    }
}
function closeOrderDetailsModal() { document.getElementById('orderDetailsModal').classList.remove('active'); refreshHomePageAnimations(); }

// --- RENDER FUNCTIONS ---
function renderProductCard(product) { const isInCompare = compareItems.includes(product.id); return ` <div class="product-card card-layered"> <img src="${product.image}" alt="${product.name}" onclick="showFullDetailsModal(${product.id})" loading="lazy"> <h3>${product.name}</h3> <p>$${product.price.toFixed(2)}</p> <div class="rating">${'★'.repeat(Math.round(product.rating))}${'☆'.repeat(5 - Math.round(product.rating))}</div> <div class="actions"> <button class="button-fill-effect" onclick="addToCart(event, ${product.id})"><span>Add to Cart</span></button> <button class="button-fill-effect" onclick="addToWishlist(event, ${product.id})" title="Add to Wishlist"><span><i class="fas fa-heart"></i></span></button> <button class="button-fill-effect" onclick="toggleCompareItem(event, ${product.id})" data-product-id="${product.id}" title="Compare"><span>${isInCompare ? '<i class="fas fa-minus"></i>' : '<i class="fas fa-exchange-alt"></i>'}</span></button> <button class="button-fill-effect" onclick="showQuickView(event, ${product.id})" title="Quick View"><span><i class="fas fa-eye"></i></span></button> </div> </div>`; }
function renderMiniProductCard(product) { if (!product) return ''; return ` <div class="mini-product-card" onclick="closeFullDetailsModal(); setTimeout(() => showFullDetailsModal(${product.id}), 50);"> <img src="${product.image}" alt="${product.name}" loading="lazy"> <h5>${product.name}</h5> <p>$${product.price.toFixed(2)}</p> </div> `; }
function renderProducts(page = currentPage) { const grid = document.getElementById('productGrid'); const start = (page - 1) * productsPerPage; const end = start + productsPerPage; const paginated = currentFilteredProducts.slice(start, end); grid.innerHTML = paginated.length ? paginated.map(p => renderProductCard(p)).join('') : '<p style="text-align:center;grid-column:1/-1;">No products found.</p>'; renderPagination(currentFilteredProducts.length); animateItemsIn(grid); }
function renderPagination(totalItems) { const pag = document.getElementById('pagination'); const pageCount = Math.ceil(totalItems / productsPerPage); pag.innerHTML = ''; if (pageCount <= 1) return; for (let i = 1; i <= pageCount; i++) { const btn = document.createElement('button'); btn.innerHTML = `<span>${i}</span>`; btn.className = `button-fill-effect ${i === currentPage ? 'active' : ''}`; btn.onclick = () => { currentPage = i; renderProducts(); document.getElementById('productGrid').scrollIntoView({ behavior: 'smooth' }); }; pag.appendChild(btn); } }
async function renderDealOfTheDay() { const deal = document.getElementById('dealOfTheDay'); try { const res = await fetch('/api/products/deal'); const p = await res.json(); if (!p || !deal) return; deal.innerHTML = `<img src="${p.image}" alt="${p.name}" onclick="showFullDetailsModal(${p.id})"><div class="deal-info"><h3>${p.name}</h3><p class="deal-price">$${p.price.toFixed(2)}</p><div class="rating">${'★'.repeat(Math.round(p.rating))}${'☆'.repeat(5 - Math.round(p.rating))}</div><p class="deal-description">${p.description}</p><button class="button-fill-effect" onclick="showFullDetailsModal(${p.id})"><span>View Deal</span></button></div>`; deal.classList.add('item-visible'); } catch(e) { console.error("Could not fetch deal of the day", e); if(deal) deal.innerHTML = "<p>Could not load deal.</p>"; }}
async function renderFeaturedBrands() { const el = document.getElementById('featuredBrands'); if (!el) return; try { const res = await fetch('/api/brands'); const brandsData = await res.json(); const brandIcons = { 'Prestige': 'fa-gem', 'Royal': 'fa-crown', 'Momentum': 'fa-rocket', 'Stellar': 'fa-star', 'StyleUp':'fa-paint-brush', 'TechCore': 'fa-microchip'}; el.innerHTML = brandsData.map(b => `<div class="brand-card card-layered" onclick="showBrandProductsModal('${b.brand}')"><i class="fas ${brandIcons[b.brand] || 'fa-tag'}"></i><h3>${b.brand}</h3></div>`).join(''); animateItemsIn(el); } catch(e) { console.error("Could not fetch brands", e); if(el) el.innerHTML = "<p>Could not load brands.</p>"; }}
function renderRecentlyViewed() { const el = document.getElementById('recentlyViewed'); if (!el) return; const recentProducts = recentlyViewed.map(rv => products.find(p => p.id === rv.id)).filter(Boolean); el.innerHTML = recentProducts.length ? recentProducts.slice(0, 4).map(p => renderProductCard(p)).join('') : '<p style="text-align:center;grid-column:1/-1;">No recently viewed products.</p>'; animateItemsIn(el); }
function renderSlider() { const c=document.querySelector('.slider-container'),d=document.querySelector('.slider-dots');if(!c||!d)return;const f=products.slice(0,5);c.innerHTML=f.map(p=>`<div class="slider-item"><img src="${p.image}" alt="${p.name}" onclick="showFullDetailsModal(${p.id})"><h3>${p.name}</h3></div>`).join('');d.innerHTML=f.map((_,i)=>`<span class="slider-dot ${i===0?'active':''}" onclick="goToSlide(${i})"></span>`).join(''); }
function updateSlider() { const c=document.querySelector('.slider-container');if(c){c.style.transform=`translateX(-${currentSlide*100}%)`;document.querySelectorAll('.slider-dot').forEach((d,i)=>d.classList.toggle('active',i===currentSlide));}}
function startAutoSlide() { stopAutoSlide(); slideInterval=setInterval(nextSlide,5000); }
function stopAutoSlide() { clearInterval(slideInterval); }
function nextSlide() { const t=document.querySelectorAll('.slider-item').length;if(t>0)currentSlide=(currentSlide+1)%t;updateSlider(); }
function prevSlide() { const t=document.querySelectorAll('.slider-item').length;if(t>0)currentSlide=(currentSlide-1+t)%t;updateSlider(); }
function goToSlide(i) { currentSlide=i;updateSlider();startAutoSlide(); }

// --- MODAL CONTENT ---
async function getCategoriesContent() { try { const res = await fetch('/api/categories'); const categories = await res.json(); const categoryIcons = { 'electronics': 'fa-bolt', 'clothing': 'fa-tshirt', 'books': 'fa-book-open', 'home': 'fa-home', 'sports': 'fa-futbol', 'accessories': 'fa-glasses', 'games': 'fa-gamepad', 'default': 'fa-tag' }; return `<div class="category-grid" id="categoryGrid">` + categories.map(cat => `<div class="category-card card-layered" onclick="showCategoryProductsModal('${cat}')"> <i class="fas ${categoryIcons[cat] || categoryIcons['default']}"></i> <h3>${cat.charAt(0).toUpperCase() + cat.slice(1)}</h3> </div>`).join('') + `</div>`; } catch(e) { return "<p>Error loading categories.</p>"}}
function getCartContent() { if (cart.length === 0) return '<p class="item-visible" style="text-align: center;">Your cart is empty.</p>'; const itemsHTML = cart.map(i => `<div class="item-list-item card-layered"> <p>${i.name} - $${i.price.toFixed(2)}</p> <div> <button class="button-fill-effect" onclick="updateQuantity(event, ${i.id},${i.quantity-1})"><span>-</span></button> <span style="margin: 0 1rem; color: #fff;">${i.quantity}</span> <button class="button-fill-effect" onclick="updateQuantity(event, ${i.id},${i.quantity+1})"><span>+</span></button> <button class="button-fill-effect" onclick="removeFromCart(event, ${i.id})"><span>Remove</span></button> </div> </div>`).join(''); const total = cart.reduce((s, i) => s + i.price * i.quantity, 0).toFixed(2); return ` <div id="cartItems">${itemsHTML}</div> <div class="cart-total item-visible"> <h3>Total: $${total}</h3> <button onclick="showCheckoutModal()" class="button-fill-effect"><span>Proceed to Checkout</span></button> </div>`; }
function getCheckoutContent() { return ` <div class="item-visible"> <button class="back-button button-fill-effect" onclick="showCartModal()"><span><i class="fas fa-arrow-left"></i> Back to Cart</span></button> <form id="checkoutForm" class="checkout-form card-layered" style="color:var(--text-color);"> <div class="form-group"><input type="text" id="fullName" placeholder=" " required><label for="fullName">Full Name</label></div> <div class="form-group"><input type="text" id="address" placeholder=" " required><label for="address">Address</label></div> <div class="form-group"><input type="text" id="cardNumber" placeholder=" " required><label for="cardNumber">Card Number</label></div> <div class="promo-code-group"> <div class="form-group"><input type="text" id="promoCode" placeholder=" "><label for="promoCode">Promo Code</label></div> <button type="button" onclick="applyPromoCode()" class="button-fill-effect"><span>Apply</span></button> </div> <button type="submit" class="button-fill-effect"><span>Place Order</span></button> </form> </div>`; }
async function getOrdersContent() {
    if (!currentUser || !authToken) {
        return '<p class="item-visible" style="text-align: center;">Please log in to see your order history.</p>';
    }
    try {
        const res = await fetch('/api/orders', {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        if (!res.ok) throw new Error('Could not fetch orders.');
        const orders = await res.json();
        if (orders.length === 0) return '<p class="item-visible" style="text-align: center;">You have no orders yet.</p>';
        const ordersHTML = orders.map(o => `
            <div class="order-list-item card-layered">
                <p><strong>Order #${o.id.toString().padStart(5, '0')}</strong></p>
                <p>${new Date(o.order_date).toLocaleDateString()}</p>
                <p>$${o.total_price.toFixed(2)}</p>
                <p><span class="order-status ${o.status}">${o.status}</span></p>
                <div>
                    <button class="button-fill-effect" onclick="showOrderDetails('${o.id}')"><span>Details</span></button>
                    ${o.status === 'Pending' ? `<button class="button-fill-effect button-cancel" onclick="cancelOrder(event, '${o.id}')"><span>Cancel</span></button>` : ''}
                </div>
            </div>`).join('');
        return `<div id="orderList">${ordersHTML}</div>`;
    } catch (error) {
        console.error(error);
        showToast(error.message);
        return `<p class="item-visible" style="text-align: center;">Error loading orders.</p>`;
    }
}
function getWishlistContent() { if (wishlist.length === 0) return '<p class="item-visible" style="text-align: center;">Your wishlist is empty.</p>'; const wishlistProducts = wishlist.map(item => products.find(p => p.id === item.id)).filter(Boolean); return ` <div class="item-visible" style="margin-bottom: 2rem;"> <button class="button-fill-effect" onclick="shareWishlist()"><span>Share Wishlist</span></button> </div> <div id="wishlistItems" class="product-grid">${wishlistProducts.map(p => renderProductCard(p)).join('')}</div>`; }
function getCompareContent() { let content; if (compareItems.length < 1) { content = '<p class="item-visible" style="text-align: center;">Add items to compare them side-by-side.</p>'; } else { const itemsToCompare = products.filter(p => compareItems.includes(p.id)); content = itemsToCompare.map(p => renderProductCard(p)).join(''); } return ` <div id="compareTable" class="product-grid">${content}</div> ${compareItems.length > 0 ? `<div class="item-visible" style="text-align:center; margin-top:2rem;"> <button onclick="clearCompare()" class="button-fill-effect"><span>Clear Comparison</span></button> </div>` : ''}`; }

// --- ACTIONS & HANDLERS ---
function addToCart(event, productId) { event.stopPropagation(); const p = products.find(pr => pr.id === productId); if (!p) return; const i = cart.find(it => it.id === productId); if (i) i.quantity++; else cart.push({ ...p, quantity: 1 }); localStorage.setItem('cart', JSON.stringify(cart)); updateCounts(); showToast(`${p.name} added to cart!`); }
function updateQuantity(event, productId, n) { event.stopPropagation(); const i = cart.find(it => it.id === productId); if(i){ if(n>0) i.quantity=n; else cart=cart.filter(it=>it.id!==productId); localStorage.setItem('cart',JSON.stringify(cart));updateCounts();showCartModal();}}
function removeFromCart(event, productId) { event.stopPropagation(); cart=cart.filter(i=>i.id!==productId); localStorage.setItem('cart',JSON.stringify(cart));updateCounts();showCartModal(); }
function addToWishlist(event, productId) { event.stopPropagation(); const p = products.find(pr => pr.id === productId); if (!p || wishlist.some(i => i.id === p.id)) {showToast(`${p.name} is already in wishlist.`); return;} wishlist.push({id: p.id}); localStorage.setItem('wishlist', JSON.stringify(wishlist)); updateCounts(); showToast(`${p.name} added to wishlist!`); if(currentPageModal === 'wishlist') showWishlistModal(); }
function shareWishlist() { navigator.clipboard.writeText(`${window.location.origin}#wishlist`).then(() => showToast('Wishlist URL copied!')); }
function toggleCompareItem(event, productId) { event.stopPropagation(); const btn = document.querySelector(`.actions button[data-product-id="${productId}"]`); if(compareItems.includes(productId)){compareItems=compareItems.filter(id=>id!==productId); if(btn)btn.innerHTML='<span><i class="fas fa-exchange-alt"></i></span>';} else { if(compareItems.length>=4)return showToast('Max 4 items to compare.'); compareItems.push(productId); if(btn)btn.innerHTML='<span><i class="fas fa-minus"></i></span>'; } localStorage.setItem('compareItems',JSON.stringify(compareItems)); updateCounts(); if(currentPageModal==='compare') showCompareModal(); }
function clearCompare() { compareItems=[]; localStorage.setItem('compareItems','[]'); updateCounts(); showCompareModal(); }
async function handleCheckoutSubmit(e) {
    e.preventDefault();
    if (cart.length === 0) {
        showToast('Your cart is empty.');
        return;
    }
    if (!currentUser || !authToken) {
        showToast('Please log in to place an order.');
        showLoginModal();
        return;
    }
    const orderItems = cart.map(item => ({ id: item.id, quantity: item.quantity }));
    try {
        const res = await fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ items: orderItems })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to place order.');
        showToast(data.message);
        cart = [];
        localStorage.setItem('cart', '[]');
        updateCounts();
        showOrdersModal();
    } catch (error) {
        showToast(error.message);
        console.error('Checkout error:', error);
    }
}
async function cancelOrder(event, orderId) {
    event.stopPropagation();
    if (!currentUser || !authToken) {
        showToast('Please log in to cancel orders.');
        return;
    }
    showConfirmModal('Cancel Order?', 'Are you sure you want to cancel this order? This action cannot be undone.', async () => {
        try {
            const res = await fetch(`/api/orders/${orderId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });
            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.message || 'Failed to cancel order.');
            }
            showToast(data.message);
            showOrdersModal(); 
        } catch (error) {
            showToast(error.message);
            console.error('cancelOrder error:', error);
        }
    });
}
function applyPromoCode() { const c=document.getElementById('promoCode').value; if(c.toUpperCase()==='SAVE10')showToast('10% discount applied!'); else showToast('Invalid promo code.'); }

// --- FILTERS & SEARCH ---
async function filterProducts() { 
    const cat=document.getElementById('categoryFilter').value;
    const price=document.getElementById('priceFilter').value;
    const rating=document.getElementById('ratingFilter').value;
    const sort=document.getElementById('sortFilter').value;
    const q=document.getElementById('searchInput').value.trim().toLowerCase();
    const queryParams = new URLSearchParams();
    if (cat && cat !== 'all') queryParams.append('category', cat);
    if (price) queryParams.append('price', price);
    if (rating && rating !== '0') queryParams.append('rating', rating);
    if (sort && sort !== 'default') queryParams.append('sort', sort);
    if (q) queryParams.append('q', q);
    try {
        const res = await fetch(`/api/products?${queryParams.toString()}`);
        currentFilteredProducts = await res.json();
        currentPage = 1;
        renderProducts();
    } catch(e) {
        console.error("Error filtering products", e);
        showToast("Could not apply filters.");
    }
}
function debounceSearch() { clearTimeout(debounceTimer); debounceTimer = setTimeout(() => { showSuggestions(); filterProducts(); }, 300); }
function showSuggestions() { const q=document.getElementById('searchInput').value.trim().toLowerCase(), div=document.getElementById('suggestions'); if(!q){div.innerHTML='';return;} const f=products.filter(p=>p.name.toLowerCase().includes(q)).slice(0,5); div.innerHTML=f.map(p=>`<div class="suggestion-item" onclick="document.getElementById('searchInput').value='${p.name}';filterProducts();document.getElementById('suggestions').innerHTML='';"><img src="${p.image}"><span>${p.name}</span></div>`).join(''); }
function clearFilters() { ['categoryFilter','priceFilter','ratingFilter','sortFilter','searchInput'].forEach(id=>{const el=document.getElementById(id);if(el.tagName==='SELECT')el.value=id==='categoryFilter'?'all':'default';else if(el.type==='number' || el.type==='text')el.value='';if(id==='ratingFilter')el.value='0';}); filterProducts(); }