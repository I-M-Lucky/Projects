const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
require('dotenv').config();

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'); // CORRECTED THIS LINE

// Import the auth middleware
const authMiddleware = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  decimalNumbers: true
});

// --- AUTHENTICATION ROUTES ---

// POST /api/auth/register
app.post('/api/auth/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: 'Please provide name, email, and password.' });
    }
    try {
        const [userExists] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
        if (userExists.length > 0) {
            return res.status(409).json({ message: 'User with this email already exists.' });
        }
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(password, salt);
        const [result] = await pool.execute(
            'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
            [name, email, password_hash]
        );
        if (result.affectedRows === 1) {
            res.status(201).json({ message: 'User registered successfully!' });
        } else {
            throw new Error('User registration failed.');
        }
    } catch (error) {
        console.error("Registration Error:", error);
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

// POST /api/auth/login
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: 'Please provide email and password.' });
    }
    try {
        const [users] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) {
            return res.status(401).json({ message: 'Invalid credentials.' });
        }
        const user = users[0];
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials.' });
        }
        const payload = {
            user: { id: user.id, name: user.name, email: user.email }
        };
        jwt.sign(
            payload,
            process.env.JWT_SECRET,
            { expiresIn: '1h' },
            (err, token) => {
                if (err) throw err;
                res.json({
                    message: 'Login successful!',
                    token: token,
                    user: payload.user
                });
            }
        );
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ message: 'Server error during login.' });
    }
});


// --- ORDER ROUTES ---

// POST /api/orders - Create a new order (Protected Route)
app.post('/api/orders', authMiddleware, async (req, res) => {
    const { items } = req.body;
    const userId = req.user.id;
    if (!items || items.length === 0) {
        return res.status(400).json({ message: 'Cart is empty' });
    }
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        let totalPrice = 0;
        const productIds = items.map(item => item.id);
        const [products] = await connection.query(`SELECT id, price FROM products WHERE id IN (?)`, [productIds]);
        const priceMap = new Map(products.map(p => [p.id, p.price]));
        for (const item of items) {
            const price = priceMap.get(item.id);
            if (!price) throw new Error(`Product with ID ${item.id} not found.`);
            totalPrice += price * item.quantity;
        }
        const [orderResult] = await connection.execute(
            'INSERT INTO orders (user_id, total_price, status) VALUES (?, ?, ?)',
            [userId, totalPrice, 'Pending']
        );
        const orderId = orderResult.insertId;
        const orderItemsQuery = 'INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES ?';
        const orderItemsValues = items.map(item => [orderId, item.id, item.quantity, priceMap.get(item.id)]);
        await connection.query(orderItemsQuery, [orderItemsValues]);
        await connection.commit();
        res.status(201).json({ message: 'Order placed successfully!', orderId: orderId });
    } catch (error) {
        await connection.rollback();
        console.error('Order creation error:', error);
        res.status(500).json({ message: 'Failed to place order.' });
    } finally {
        connection.release();
    }
});

// GET /api/orders - Fetch all orders for the logged-in user (Protected Route)
app.get('/api/orders', authMiddleware, async (req, res) => {
    const userId = req.user.id;
    try {
        const [orders] = await pool.execute(
            'SELECT id, order_date, total_price, status FROM orders WHERE user_id = ? ORDER BY order_date DESC',
            [userId]
        );
        res.json(orders);
    } catch (error) {
        console.error('Fetch orders error:', error);
        res.status(500).json({ message: 'Failed to fetch orders.' });
    }
});

// GET /api/orders/:id - Fetch details for a single order (Protected Route)
app.get('/api/orders/:id', authMiddleware, async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;
    try {
        const [order] = await pool.execute(
            'SELECT * FROM orders WHERE id = ? AND user_id = ?',
            [id, userId]
        );
        if (order.length === 0) {
            return res.status(404).json({ message: 'Order not found or you do not have permission to view it.' });
        }
        const [items] = await pool.execute(
            `SELECT p.name, oi.quantity, oi.price_at_purchase
             FROM order_items oi
             JOIN products p ON oi.product_id = p.id
             WHERE oi.order_id = ?`,
            [id]
        );
        const orderDetails = order[0];
        orderDetails.items = items;
        res.json(orderDetails);
    } catch (error) {
        console.error('Fetch order details error:', error);
        res.status(500).json({ message: 'Failed to fetch order details.' });
    }
});

// DELETE /api/orders/:id - Cancel an order (Protected Route)
app.delete('/api/orders/:id', authMiddleware, async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;
    try {
        const [result] = await pool.execute(
            "UPDATE orders SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND status = 'Pending'",
            [id, userId]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Order not found, already processed, or you do not have permission.' });
        }
        res.json({ message: 'Order has been cancelled successfully.' });
    } catch (error) {
        console.error('Cancel order error:', error);
        res.status(500).json({ message: 'Failed to cancel order.' });
    }
});


// --- PRODUCT & OTHER API ROUTES ---

// GET All Products
app.get('/api/products', async (req, res) => {
  try {
    let query = 'SELECT * FROM products WHERE 1=1';
    const params = [];
    if (req.query.category && req.query.category !== 'all') {
      query += ' AND category = ?';
      params.push(req.query.category);
    }
    if (req.query.price) {
      query += ' AND price <= ?';
      params.push(parseFloat(req.query.price));
    }
    if (req.query.rating) {
      query += ' AND rating >= ?';
      params.push(parseInt(req.query.rating));
    }
    if (req.query.q) {
        query += ' AND name LIKE ?';
        params.push(`%${req.query.q}%`);
    }
    if (req.query.sort) {
      switch (req.query.sort) {
        case 'priceLow': query += ' ORDER BY price ASC'; break;
        case 'priceHigh': query += ' ORDER BY price DESC'; break;
        case 'rating': query += ' ORDER BY rating DESC'; break;
      }
    }
    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// GET Deal of the Day
app.get('/api/products/deal', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM products ORDER BY RAND() LIMIT 1');
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch deal' });
    }
});

// GET Single Product by ID
app.get('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [productRows] = await pool.execute('SELECT * FROM products WHERE id = ?', [id]);
    if (productRows.length === 0) return res.status(404).json({ error: 'Product not found' });
    const [reviewRows] = await pool.execute('SELECT * FROM reviews WHERE product_id = ? ORDER BY created_at DESC', [id]);
    const product = productRows[0];
    product.reviews = reviewRows;
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product details' });
  }
});

// GET all unique categories
app.get('/api/categories', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT DISTINCT category FROM products ORDER BY category');
        res.json(rows.map(row => row.category));
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch categories'});
    }
});

// GET all unique brands
app.get('/api/brands', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT DISTINCT brand FROM products ORDER BY brand');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch brands'});
    }
});

// POST a new review (Protected Route)
app.post('/api/reviews', authMiddleware, async (req, res) => {
  const { productId, rating, text } = req.body;
  const userId = req.user.id;
  if (!productId || !rating || !text) {
    return res.status(400).json({ error: 'Missing required review fields' });
  }
  try {
    const query = 'INSERT INTO reviews (product_id, user_id, rating, text) VALUES (?, ?, ?, ?)';
    await pool.execute(query, [productId, userId, rating, text]);
    res.status(201).json({ message: 'Review submitted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to submit review' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});