const mysql = require('mysql2/promise');
const fs = require('fs/promises');
const path = require('path');
require('dotenv').config();

// Your original JSON data (for populating the database)
const productsData = [
    {"id":11,"name":"Bluetooth Speaker","price":59.99,"category":"electronics","brand":"TechCore","rating":4.3,"image":"https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb","description":"Portable speaker with 12-hour battery life."},
    {"id":12,"name":"Denim Jeans","price":49.99,"category":"clothing","brand":"StyleUp","rating":4.2,"image":"https://images.unsplash.com/photo-1473966968600-fa801b869a1a","description":"Classic blue jeans with comfortable fit."},
    {"id":13,"name":"Yoga Mat","price":29.99,"category":"sports","brand":"Momentum","rating":4.4,"image":"https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b","description":"Non-slip yoga mat for all skill levels."},
    {"id":14,"name":"Desk Lamp","price":39.99,"category":"home","brand":"Royal","rating":4.1,"image":"https://images.unsplash.com/photo-1580477667995-2b94f01c9516","description":"Adjustable LED desk lamp with multiple brightness settings."},
    {"id":15,"name":"Backpack","price":45.99,"category":"accessories","brand":"Stellar","rating":4.5,"image":"https://images.unsplash.com/photo-1553062407-98eeb64c6a62","description":"Durable backpack with laptop compartment."},
    {"id":16,"name":"Digital Camera","price":449.99,"category":"electronics","brand":"Prestige","rating":4.6,"image":"https://images.unsplash.com/photo-1516035069371-29a1b244cc32","description":"24MP mirrorless camera with 4K video."},
    {"id":17,"name":"Sunglasses","price":89.99,"category":"accessories","brand":"StyleUp","rating":4.3,"image":"https://images.unsplash.com/photo-1511499767150-a48a237f0083","description":"UV protection sunglasses with polarized lenses."},
    {"id":18,"name":"Air Fryer","price":79.99,"category":"home","brand":"Royal","rating":4.4,"image":"https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7","description":"Healthy cooking with little to no oil."},
    {"id":19,"name":"Wireless Earbuds","price":129.99,"category":"electronics","brand":"TechCore","rating":4.5,"image":"https://images.unsplash.com/photo-1590658268037-6bf12165a8df","description":"True wireless earbuds with charging case."},
    {"id":20,"name":"Leather Wallet","price":34.99,"category":"accessories","brand":"Prestige","rating":4.2,"image":"https://images.unsplash.com/photo-1549923746-c502d488b3ea","description":"Genuine leather wallet with multiple card slots."},
    {"id":21,"name":"Fitness Tracker","price":79.99,"category":"electronics","brand":"Momentum","rating":4.3,"image":"https://images.unsplash.com/photo-1576243345690-4e4b79b63288","description":"Track steps, calories, and sleep patterns."},
    {"id":22,"name":"Dress Shirt","price":39.99,"category":"clothing","brand":"Prestige","rating":4.1,"image":"https://images.unsplash.com/photo-1598033129183-c4f50c736f10","description":"Formal dress shirt in various colors."},
    {"id":23,"name":"External SSD","price":119.99,"category":"electronics","brand":"TechCore","rating":4.7,"image":"https://images.unsplash.com/photo-1591488320449-011701bb6704","description":"1TB portable SSD with fast transfer speeds."},
    {"id":24,"name":"Water Bottle","price":24.99,"category":"accessories","brand":"Stellar","rating":4.4,"image":"https://images.unsplash.com/photo-1602143407151-7111542de6e8","description":"Insulated stainless steel water bottle."},
    {"id":25,"name":"Graphic Novel","price":22.99,"category":"books","brand":"Stellar","rating":4.2,"image":"https://images.unsplash.com/photo-1734346920698-3a3fd38cf38a?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Award-winning graphic novel with stunning artwork."},
    {"id":26,"name":"Standing Desk","price":249.99,"category":"home","brand":"Prestige","rating":4.6,"image":"https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd","description":"Height-adjustable electric standing desk."},
    {"id":27,"name":"Smart Bulb","price":19.99,"category":"electronics","brand":"TechCore","rating":4.0,"image":"https://plus.unsplash.com/premium_photo-1672759360872-791a5ba6e2cc?q=80&w=1496&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Color-changing LED bulb with app control."},
    {"id":28,"name":"Winter Jacket","price":129.99,"category":"clothing","brand":"Momentum","rating":4.5,"image":"https://images.unsplash.com/photo-1525130413817-d45c1d127c42","description":"Waterproof winter jacket with insulation."},
    {"id":29,"name":"Board Game","price":34.99,"category":"games","brand":"Stellar","rating":4.3,"image":"https://images.unsplash.com/photo-1547638375-ebf04735d792?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Popular strategy board game for 2-4 players."},
    {"id":30,"name":"Chef's Knife","price":89.99,"category":"home","brand":"Prestige","rating":4.7,"image":"https://images.unsplash.com/photo-1596663651065-2610b2bee786?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Professional-grade 8-inch chef's knife."},
    {"id":31,"name":"Gaming Mouse","price":59.99,"category":"electronics","brand":"TechCore","rating":4.4,"image":"https://images.unsplash.com/photo-1527814050087-3793815479db","description":"High-precision mouse with customizable buttons."},
    {"id":32,"name":"Hoodie","price":44.99,"category":"clothing","brand":"StyleUp","rating":4.2,"image":"https://images.unsplash.com/photo-1620799140408-edc6dcb6d633","description":"Comfortable cotton hoodie with front pocket."},
    {"id":33,"name":"Resistance Bands","price":29.99,"category":"sports","brand":"Momentum","rating":4.1,"image":"https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b","description":"Set of 5 resistance bands for home workouts."},
    {"id":34,"name":"Blender","price":49.99,"category":"home","brand":"Royal","rating":4.3,"image":"https://images.unsplash.com/photo-1560343090-f0409e92791a","description":"High-speed blender for smoothies and sauces."},
    {"id":35,"name":"Dumbbell Set","price":89.99,"category":"sports","brand":"Momentum","rating":4.5,"image":"https://images.unsplash.com/photo-1576678927484-cc907957088c","description":"Adjustable dumbbell set from 5-25 lbs."},
    {"id":36,"name":"Wrist Watch","price":149.99,"category":"accessories","brand":"Prestige","rating":4.6,"image":"https://images.unsplash.com/photo-1523170335258-f5ed11844a49","description":"Classic analog watch with leather strap."},
    {"id":37,"name":"E-Reader","price":129.99,"category":"electronics","brand":"TechCore","rating":4.4,"image":"https://images.unsplash.com/photo-1544947950-fa07a98d237f","description":"Paper-like display with weeks of battery life."},
    {"id":38,"name":"Throw Pillow","price":19.99,"category":"home","brand":"Royal","rating":4.0,"image":"https://images.unsplash.com/photo-1579656592043-a20e25a4aa4b","description":"Decorative pillow with removable cover."},
    {"id":39,"name":"Running Shorts","price":29.99,"category":"clothing","brand":"Momentum","rating":4.2,"image":"https://images.unsplash.com/photo-1591047139829-d91aecb6caea","description":"Lightweight running shorts with moisture-wicking."},
    {"id":40,"name":"Wireless Keyboard","price":69.99,"category":"electronics","brand":"TechCore","rating":4.3,"image":"https://images.unsplash.com/photo-1587829741301-dc798b83add3","description":"Slim wireless keyboard with quiet keys."},
    {"id":41,"name":"Sneakers","price":79.99,"category":"clothing","brand":"StyleUp","rating":4.5,"image":"https://images.unsplash.com/photo-1600269452121-4f2416e55c28","description":"Casual sneakers with comfortable cushioning."},
    {"id":42,"name":"French Press","price":24.99,"category":"home","brand":"Royal","rating":4.2,"image":"https://images.unsplash.com/photo-1459755486867-b55449bb39ff","description":"1L french press for rich coffee flavor."},
    {"id":43,"name":"Puzzle","price":14.99,"category":"games","brand":"Stellar","rating":4.1,"image":"https://images.unsplash.com/photo-1635070041078-e363dbe005cb","description":"1000-piece jigsaw puzzle of famous artwork."},
    {"id":44,"name":"Sleep Mask","price":12.99,"category":"accessories","brand":"StyleUp","rating":4.0,"image":"https://images.unsplash.com/photo-1591035897819-f4bdf739f446","description":"Silk sleep mask for better rest."},
    {"id":45,"name":"Plant Pot","price":22.99,"category":"home","brand":"Royal","rating":4.3,"image":"https://images.unsplash.com/photo-1564352969906-8b7f46ba4b8b","description":"Ceramic plant pot with drainage hole."},
    {"id":46,"name":"Travel Mug","price":19.99,"category":"accessories","brand":"Stellar","rating":4.2,"image":"https://images.unsplash.com/photo-1602143407151-7111542de6e8","description":"Leak-proof travel mug with temperature control."},
    {"id":47,"name":"Yoga Block","price":14.99,"category":"sports","brand":"Momentum","rating":4.1,"image":"https://images.unsplash.com/photo-1545389336-cf090694435e","description":"High-density foam yoga block for support."},
    {"id":48,"name":"Desk Organizer","price":29.99,"category":"home","brand":"Prestige","rating":4.0,"image":"https://images.unsplash.com/photo-1605540436563-5bca919ae766","description":"Wooden desk organizer for stationery."},
    {"id":49,"name":"Ankle Socks","price":9.99,"category":"clothing","brand":"StyleUp","rating":4.2,"image":"https://images.unsplash.com/photo-1641482850218-7a2fed872551?q=80&w=1480&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Pack of 5 breathable ankle socks."},
    {"id":50,"name":"Phone Stand","price":12.99,"category":"accessories","brand":"Stellar","rating":4.1,"image":"https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb","description":"Adjustable stand for phones and tablets."},
    {"id":51,"name":"Massage Gun","price":149.99,"category":"sports","brand":"Momentum","rating":4.6,"image":"https://images.unsplash.com/photo-1600334129128-685c5582fd35","description":"Deep tissue percussion massager."},
    {"id":52,"name":"Cookbook","price":24.99,"category":"books","brand":"Royal","rating":4.3,"image":"https://images.unsplash.com/photo-1544947950-fa07a98d237f","description":"Collection of 100 easy home recipes."},
    {"id":53,"name":"Hand Mixer","price":39.99,"category":"home","brand":"Royal","rating":4.2,"image":"https://c.ndtvimg.com/2019-05/qnatbrqo_mixer_625x300_24_May_19.jpg","description":"Electric hand mixer with 5 speeds."},
    {"id":54,"name":"Swim Goggles","price":19.99,"category":"sports","brand":"Momentum","rating":4.1,"image":"https://plus.unsplash.com/premium_photo-1719501574382-9b38669079d2?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Anti-fog swim goggles with UV protection."},
    {"id":55,"name":"Wall Clock","price":34.99,"category":"home","brand":"Prestige","rating":4.0,"image":"https://images.unsplash.com/photo-1707348102631-5a4c0a6eed6f?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Minimalist wall clock with silent movement."},
    {"id":56,"name":"Keychain","price":7.99,"category":"accessories","brand":"Stellar","rating":4.1,"image":"https://images.unsplash.com/photo-1600269452121-4f2416e55c28","description":"Durable metal keychain with bottle opener."},
    {"id":57,"name":"Puzzle Mat","price":19.99,"category":"games","brand":"Stellar","rating":4.0,"image":"https://images.unsplash.com/photo-1635070041078-e363dbe005cb","description":"Roll-up mat for puzzle storage."},
    {"id":58,"name":"Cutting Board","price":29.99,"category":"home","brand":"Prestige","rating":4.3,"image":"https://images.unsplash.com/photo-1666013942797-9daa4b8b3b4f?q=80&w=1367&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Bamboo cutting board with juice groove."},
    {"id":59,"name":"Baseball Cap","price":24.99,"category":"accessories","brand":"StyleUp","rating":4.2,"image":"https://plus.unsplash.com/premium_photo-1680859126205-1c593bb4f9e8?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Adjustable cotton baseball cap."},
    {"id":60,"name":"Jump Rope","price":14.99,"category":"sports","brand":"Momentum","rating":4.1,"image":"https://images.unsplash.com/photo-1589953856582-c9b3cb2f14b3?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D","description":"Weighted jump rope for cardio workouts."}
];

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  decimalNumbers: true // <-- THIS FIXES THE .toFixed() ERROR
});

async function setupDatabase() {
  let connection;
  try {
    connection = await pool.getConnection();
    console.log("Connected to MySQL!");

    const tables = [
      `DROP TABLE IF EXISTS reviews, order_items, orders, wishlists, users, products;`,
      `CREATE TABLE products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        category VARCHAR(100),
        brand VARCHAR(100),
        rating DECIMAL(3, 1),
        image VARCHAR(512),
        description TEXT
      );`,
      `CREATE TABLE users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL UNIQUE,
          password_hash VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );`,
      `CREATE TABLE orders (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          total_price DECIMAL(10, 2) NOT NULL,
          status VARCHAR(50) DEFAULT 'Pending',
          FOREIGN KEY (user_id) REFERENCES users(id)
      );`,
      `CREATE TABLE order_items (
          id INT AUTO_INCREMENT PRIMARY KEY,
          order_id INT NOT NULL,
          product_id INT NOT NULL,
          quantity INT NOT NULL,
          price_at_purchase DECIMAL(10, 2) NOT NULL,
          FOREIGN KEY (order_id) REFERENCES orders(id),
          FOREIGN KEY (product_id) REFERENCES products(id)
      );`,
       `CREATE TABLE reviews (
          id INT AUTO_INCREMENT PRIMARY KEY,
          product_id INT NOT NULL,
          user_id INT,
          rating INT NOT NULL,
          text TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (product_id) REFERENCES products(id)
      );`
    ];
    
    for (const query of tables) {
        await connection.query(query);
    }
    console.log("Tables created successfully.");

    // Populate products table
    const productInsertQuery = `
      INSERT INTO products (id, name, price, category, brand, rating, image, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `;
    for (const product of productsData) {
      await connection.execute(productInsertQuery, [
        product.id,
        product.name,
        product.price,
        product.category,
        product.brand,
        product.rating,
        product.image,
        product.description
      ]);
    }
    console.log(`${productsData.length} products inserted successfully.`);

    // Add a dummy user for testing
    await connection.query(`
      INSERT INTO users (id, name, email, password_hash) 
      VALUES (1, 'Test User', 'test@example.com', 'dummy_hash');
    `);
    console.log("Dummy user created.");


  } catch (error) {
    console.error("Error setting up database:", error);
  } finally {
    if (connection) connection.release();
    pool.end();
  }
}

setupDatabase();