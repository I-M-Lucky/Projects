// data.js
export const profilesData = [
    { name: "John Doe", profession: "Web Developer", location: "San Francisco", image: "https://randomuser.me/api/portraits/men/1.jpg", about: "Experienced web developer with a passion for creating innovative and user-friendly websites." },
    { name: "Jane Smith", profession: "Software Engineer", location: "New York", image: "https://randomuser.me/api/portraits/women/2.jpg", about: "Software engineer specializing in backend development and cloud computing." },
    { name: "David Lee", profession: "Data Scientist", location: "Seattle", image: "https://randomuser.me/api/portraits/men/3.jpg", about: "Data scientist with expertise in machine learning and statistical analysis." },
    { name: "Emily Chen", profession: "UX Designer", location: "Los Angeles", image: "https://randomuser.me/api/portraits/women/4.jpg", about: "UX designer dedicated to creating intuitive and engaging user experiences." },
    { name: "Michael Brown", profession: "Frontend Developer", location: "Austin", image: "https://randomuser.me/api/portraits/men/5.jpg", about: "Frontend developer with a strong focus on responsive design and accessibility." },
    { name: "Sarah Williams", profession: "Web Developer", location: "London", image: "https://randomuser.me/api/portraits/women/6.jpg", about: "Creative web developer with expertise in UI/UX design." },
    { name: "Robert Jones", profession: "Data Analyst", location: "Chicago", image: "https://randomuser.me/api/portraits/men/7.jpg", about: "Data analyst with strong analytical skills and experience in data visualization." },
    { name: "Linda Davis", profession: "Project Manager", location: "Dallas", image: "https://randomuser.me/api/portraits/women/8.jpg", about: "Experienced project manager with a track record of successfully delivering projects on time and within budget." },
    { name: "Christopher Garcia", profession: "Software Architect", location: "Miami", image: "https://randomuser.me/api/portraits/men/9.jpg", about: "Software architect with expertise in designing scalable and robust software systems." },
    { name: "Ashley Rodriguez", profession: "Mobile App Developer", location: "Denver", image: "https://randomuser.me/api/portraits/women/10.jpg", about: "Mobile app developer with experience in developing native iOS and Android applications." },
    { name: "Kevin Martinez", profession: "Cybersecurity Analyst", location: "Atlanta", image: "https://randomuser.me/api/portraits/men/11.jpg", about: "Dedicated cybersecurity analyst protecting networks and data from threats." },
    { name: "Brittany Thomas", profession: "Database Administrator", location: "Houston", image: "https://randomuser.me/api/portraits/women/12.jpg", about: "Efficient database administrator managing and optimizing database systems." },
    { name: "Brandon White", profession: "Network Engineer", location: "Phoenix", image: "https://randomuser.me/api/portraits/men/13.jpg", about: "Skilled network engineer designing and maintaining reliable network infrastructure." },
    { name: "Megan Hall", profession: "IT Support Specialist", location: "Minneapolis", image: "https://randomuser.me/api/portraits/women/14.jpg", about: "Helpful IT support specialist providing technical assistance and resolving IT issues." },
    { name: "Ryan Adams", profession: "Cloud Solutions Architect", location: "Charlotte", image: "https://randomuser.me/api/portraits/men/15.jpg", about: "Innovative cloud solutions architect designing and implementing cloud-based solutions." },
    { name: "Tiffany Baker", profession: "Business Intelligence Analyst", location: "Orlando", image: "https://randomuser.me/api/portraits/women/16.jpg", about: "Insightful business intelligence analyst analyzing data to support business decisions." },
    { name: "Jeremy Green", profession: "Systems Administrator", location: "San Diego", image: "https://randomuser.me/api/portraits/men/17.jpg", about: "Reliable systems administrator ensuring smooth operation of computer systems." },
    { name: "Nicole King", profession: "Technical Writer", location: "Portland", image: "https://randomuser.me/api/portraits/women/18.jpg", about: "Detail-oriented technical writer creating clear and concise technical documentation." },
    { name: "Justin Scott", profession: "Computer Systems Analyst", location: "Tampa", image: "https://randomuser.me/api/portraits/men/19.jpg", about: "Analytical computer systems analyst improving computer systems and processes." },
    { name: "Amanda Wright", profession: "Web Designer", location: "St. Louis", image: "https://randomuser.me/api/portraits/women/20.jpg", about: "Creative web designer crafting visually appealing and user-friendly websites." },
    { name: "Justin Nguyen", profession: "AI Engineer", location: "Boston", image: "https://randomuser.me/api/portraits/men/21.jpg", about: "Passionate AI engineer developing cutting-edge artificial intelligence solutions." },
    { name: "Isabella Perez", profession: "Machine Learning Engineer", location: "San Jose", image: "https://randomuser.me/api/portraits/women/22.jpg", about: "Skilled machine learning engineer building and deploying machine learning models." },
    { name: "Jordan Long", profession: "Robotics Engineer", location: "Pittsburgh", image: "https://randomuser.me/api/portraits/men/23.jpg", about: "Dedicated robotics engineer designing and testing robotic systems." },
    { name: "Madison Foster", profession: "Bioinformatician", location: "Baltimore", image: "https://randomuser.me/api/portraits/women/24.jpg", about: "Expert bioinformatician analyzing biological data to advance scientific research." },
    { name: "Cameron Reed", profession: "Game Developer", location: "Los Angeles", image: "https://randomuser.me/api/portraits/men/25.jpg", about: "Enthusiastic game developer creating immersive and engaging gaming experiences." },
    { name: "Avery Simmons", profession: "Virtual Reality Developer", location: "San Francisco", image: "https://randomuser.me/api/portraits/women/26.jpg", about: "Imaginative virtual reality developer building immersive VR environments." },
    { name: "Morgan Cooper", profession: "Augmented Reality Developer", location: "New York", image: "https://randomuser.me/api/portraits/men/27.jpg", about: "Innovative augmented reality developer creating engaging AR applications." },
    { name: "Blake Peterson", profession: "Blockchain Developer", location: "Seattle", image: "https://randomuser.me/api/portraits/women/28.jpg", about: "Forward-thinking blockchain developer building secure and decentralized applications." },
    { name: "Riley Hayes", profession: "Cryptocurrency Trader", location: "Austin", image: "https://randomuser.me/api/portraits/men/29.jpg", about: "Astute cryptocurrency trader analyzing market trends and executing profitable trades." },
    { name: "Jamie Morgan", profession: "Quantum Computing Researcher", location: "Chicago", image: "https://randomuser.me/api/portraits/women/30.jpg", about: "Visionary quantum computing researcher exploring the potential of quantum technology." },
    // Add more profiles here
];

export const postsData = [
    {
        user: {
            name: "John Doe",
            avatar: "https://randomuser.me/api/portraits/men/1.jpg"
        },
        timestamp: "2 hours ago",
        content: "Just finished a new project! Check it out: ",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBDhC9p7GTQpD26xjJhNWtVgP4DTSjgEcJxg&s",
        likes: 120,
        comments: [
            { user: "Jane Smith", text: "Great work!" },
            { user: "David Lee", text: "Impressive!" }
        ]
    },
    {
        user: {
            name: "Jane Smith",
            avatar: "https://randomuser.me/api/portraits/women/2.jpg"
        },
        timestamp: "1 day ago",
        content: "Excited to share my latest software engineering innovation!",
        link: "#",
        image: "https://e1.pxfuel.com/desktop-wallpaper/119/574/desktop-wallpaper-warframe-widescreen-high-definition-fullscreen-cover-fire-offline-shooting-games.jpg",
        likes: 85,
        comments: [
            { user: "John Doe", text: "Fantastic!" },
            { user: "Emily Chen", text: "Well done!" }
        ]
    },
    {
        user: {
            name: "David Lee",
            avatar: "https://randomuser.me/api/portraits/men/3.jpg"
        },
        timestamp: "3 days ago",
        content: "Analyzing new datasets for machine learning insights.",
        link: "#",
        image: "https://hd.wallpaperswide.com/thumbs/games_6-t2.jpg",
        likes: 150,
        comments: [
            { user: "Jane Smith", text: "Interesting!" },
            { user: "Michael Brown", text: "Keep up the great work!" }
        ]
    },
    {
        user: {
            name: "Emily Chen",
            avatar: "https://randomuser.me/api/portraits/women/4.jpg"
        },
        timestamp: "1 week ago",
        content: "Designing a user interface for a new mobile app.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzmgX-Cyx390d8EwN3BOIW6qbulqrsKHGFiw&s",
        likes: 90,
        comments: [
            { user: "David Lee", text: "Looks amazing!" },
            { user: "Sarah Williams", text: "Great design!" }
        ]
    },
    {
        user: {
            name: "Michael Brown",
            avatar: "https://randomuser.me/api/portraits/men/5.jpg"
        },
        timestamp: "2 weeks ago",
        content: "Working on a responsive design for a website.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi2kcupXYPIPHfhAAI4gOBgtGDoC_t7EGTV7uVjPqpej0G04s57k9_eng4NEZ7OOwAbC0&usqp=CAU",
        likes: 110,
        comments: [
            { user: "Emily Chen", text: "Nicely done!" },
            { user: "Robert Jones", text: "Good job!" }
        ]
    },
    {
        user: {
            name: "Sarah Williams",
            avatar: "https://randomuser.me/api/portraits/women/6.jpg"
        },
        timestamp: "3 weeks ago",
        content: "Exploring new UI/UX design trends.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBDhC9p7GTQpD26xjJhNWtVgP4DTSjgEcJxg&s",
        likes: 75,
        comments: [
            { user: "Michael Brown", text: "Very informative!" },
            { user: "Linda Davis", text: "Thanks for sharing!" }
        ]
    },
   {
        user: {
            name: "Robert Jones",
            avatar: "https://randomuser.me/api/portraits/men/7.jpg"
        },
        timestamp: "4 weeks ago",
        content: "Data visualization project completed!",
        link: "#",
        image: "https://e1.pxfuel.com/desktop-wallpaper/119/574/desktop-wallpaper-warframe-widescreen-high-definition-fullscreen-cover-fire-offline-shooting-games.jpg",
        likes: 130,
        comments: [
            { user: "Sarah Williams", text: "Awesome work!" },
            { user: "Christopher Garcia", text: "Impressive data!" }
        ]
    },
    {
        user: {
            name: "Linda Davis",
            avatar: "https://randomuser.me/api/portraits/women/8.jpg"
        },
        timestamp: "1 month ago",
        content: "Successfully delivered a project on time and within budget.",
        link: "#",
        image: "https://hd.wallpaperswide.com/thumbs/games_6-t2.jpg",
        likes: 100,
        comments: [
            { user: "Robert Jones", text: "Congratulations!" },
            { user: "Ashley Rodriguez", text: "Great job, Linda!" }
        ]
    },
    {
        user: {
            name: "Christopher Garcia",
            avatar: "https://randomuser.me/api/portraits/men/9.jpg"
        },
        timestamp: "5 weeks ago",
        content: "Designing scalable software systems.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzmgX-Cyx390d8EwN3BOIW6qbulqrsKHGFiw&s",
        likes: 125,
        comments: [
            { user: "Linda Davis", text: "Fantastic design!" },
            { user: "Kevin Martinez", text: "Well done, Chris!" }
        ]
    },
    {
        user: {
            name: "Ashley Rodriguez",
            avatar: "https://randomuser.me/api/portraits/women/10.jpg"
        },
        timestamp: "6 weeks ago",
        content: "Developing native iOS and Android applications.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi2kcupXYPIPHfhAAI4gOBgtGDoC_t7EGTV7uVjPqpej0G04s57k9_eng4NEZ7OOwAbC0&usqp=CAU",
        likes: 80,
        comments: [
            { user: "Christopher Garcia", text: "Keep it up, Ashley!" },
            { user: "Brittany Thomas", text: "Good work, Ashley!" }
        ]
    },
   {
        user: {
            name: "Kevin Martinez",
            avatar: "https://randomuser.me/api/portraits/men/11.jpg"
        },
        timestamp: "7 weeks ago",
        content: "Cybersecurity is my main goal.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBDhC9p7GTQpD26xjJhNWtVgP4DTSjgEcJxg&s",
        likes: 100,
        comments: [
            { user: "Brittany Thomas", text: "Looking great!" },
            { user: "Brandon White", text: "Good work!!" }
        ]
    },
   {
        user: {
            name: "Brittany Thomas",
            avatar: "https://randomuser.me/api/portraits/women/12.jpg"
        },
        timestamp: "8 weeks ago",
        content: "Database Administration is my life.",
        link: "#",
        image: "https://e1.pxfuel.com/desktop-wallpaper/119/574/desktop-wallpaper-warframe-widescreen-high-definition-fullscreen-cover-fire-offline-shooting-games.jpg",
        likes: 120,
        comments: [
            { user: "Kevin Martinez", text: "Amazing" },
            { user: "Brandon White", text: "Fantastic" }
        ]
    },
   {
        user: {
            name: "Brandon White",
            avatar: "https://randomuser.me/api/portraits/men/13.jpg"
        },
        timestamp: "9 weeks ago",
        content: "Network Enginner.",
        link: "#",
        image: "https://hd.wallpaperswide.com/thumbs/games_6-t2.jpg",
        likes: 150,
        comments: [
            { user: "Brittany Thomas", text: "Nice" },
            { user: "Megan Hall", text: "Cool" }
        ]
    },
       {
        user: {
            name: "Megan Hall",
            avatar: "https://randomuser.me/api/portraits/women/14.jpg"
        },
        timestamp: "10 weeks ago",
        content: "I love It Specialist.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzmgX-Cyx390d8EwN3BOIW6qbulqrsKHGFiw&s",
        likes: 200,
        comments: [
            { user: "Brandon White", text: "Fantastic Megan" },
            { user: "Ryan Adams", text: "Super!!" }
        ]
    },

        {
        user: {
            name: "Ryan Adams",
            avatar: "https://randomuser.me/api/portraits/men/15.jpg"
        },
        timestamp: "11 weeks ago",
        content: "I Cloud Solutions Architect",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi2kcupXYPIPHfhAAI4gOBgtGDoC_t7EGTV7uVjPqpej0G04s57k9_eng4NEZ7OOwAbC0&usqp=CAU",
        likes: 10,
        comments: [
            { user: "Megan Hall", text: "Wow" },
            { user: "Tiffany Baker", text: "Amazing" }
        ]
    },
    {
        user: {
            name: "Skylar Bennett",
            avatar: "https://randomuser.me/api/portraits/men/31.jpg"
        },
        timestamp: "12 weeks ago",
        content: "Excited to be working on space data analysis.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBDhC9p7GTQpD26xjJhNWtVgP4DTSjgEcJxg&s",
        likes: 65,
        comments: [
            { user: "Ryan Adams", text: "So cool!" },
            { user: "Tiffany Baker", text: "Keep up the great work!" }
        ]
    },
    {
        user: {
            name: "Peyton Rivera",
            avatar: "https://randomuser.me/api/portraits/women/32.jpg"
        },
        timestamp: "13 weeks ago",
        content: "Making progress on my nanotechnology project!",
        link: "#",
        image: "https://e1.pxfuel.com/desktop-wallpaper/119/574/desktop-wallpaper-warframe-widescreen-high-definition-fullscreen-cover-fire-offline-shooting-games.jpg",
        likes: 78,
        comments: [
            { user: "Skylar Bennett", text: "Impressive stuff!" },
            { user: "Parker Bell", text: "Looking good!" }
        ]
    },
    {
        user: {
            name: "Parker Bell",
            avatar: "https://randomuser.me/api/portraits/men/33.jpg"
        },
        timestamp: "14 weeks ago",
        content: "Promoting sustainable energy solutions is my passion.",
        link: "#",
        image: "https://hd.wallpaperswide.com/thumbs/games_6-t2.jpg",
        likes: 92,
        comments: [
            { user: "Peyton Rivera", text: "Awesome!" },
            { user: "Remi Ward", text: "Great message!" }
        ]
    },
    {
        user: {
            name: "Remi Ward",
            avatar: "https://randomuser.me/api/portraits/women/34.jpg"
        },
        timestamp: "15 weeks ago",
        content: "Sustainable agriculture is the future!",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzmgX-Cyx390d8EwN3BOIW6qbulqrsKHGFiw&s",
        likes: 112,
        comments: [
            { user: "Parker Bell", text: "Couldn't agree more!" },
            { user: "Kai Flores", text: "Very true!" }
        ]
    },
    {
        user: {
            name: "Kai Flores",
            avatar: "https://randomuser.me/api/portraits/men/35.jpg"
        },
        timestamp: "16 weeks ago",
        content: "Building livable and sustainable cities.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi2kcupXYPIPHfhAAI4gOBgtGDoC_t7EGTV7uVjPqpej0G04s57k9_eng4NEZ7OOwAbC0&usqp=CAU",
        likes: 105,
        comments: [
            { user: "Remi Ward", text: "Fantastic work!" },
            { user: "Dallas Gray", text: "Very important!" }
        ]
    },
    {
        user: {
            name: "Dallas Gray",
            avatar: "https://randomuser.me/api/portraits/women/36.jpg"
        },
        timestamp: "17 weeks ago",
        content: "Studying marine ecosystems and conservation efforts.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBDhC9p7GTQpD26xjJhNWtVgP4DTSjgEcJxg&s",
        likes: 88,
        comments: [
            { user: "Kai Flores", text: "Interesting research!" },
            { user: "Phoenix Price", text: "Keep up the great work!" }
        ]
    },
    {
        user: {
            name: "Phoenix Price",
            avatar: "https://randomuser.me/api/portraits/men/37.jpg"
        },
        timestamp: "18 weeks ago",
        content: "Protecting the environment is everyone's responsibility!",
        link: "#",
        image: "https://e1.pxfuel.com/desktop-wallpaper/119/574/desktop-wallpaper-warframe-widescreen-high-definition-fullscreen-cover-fire-offline-shooting-games.jpg",
        likes: 128,
        comments: [
            { user: "Dallas Gray", text: "I agree!" },
            { user: "Dakota Perry", text: "So true!" }
        ]
    },
    {
        user: {
            name: "Dakota Perry",
            avatar: "https://randomuser.me/api/portraits/women/38.jpg"
        },
        timestamp: "19 weeks ago",
        content: "Assessing the impacts of climate change and proposing solutions.",
        link: "#",
        image: "https://hd.wallpaperswide.com/thumbs/games_6-t2.jpg",
        likes: 95,
        comments: [
            { user: "Phoenix Price", text: "Essential work!" },
            { user: "Hayden Cook", text: "Keep it up!" }
        ]
    },
    {
        user: {
            name: "Hayden Cook",
            avatar: "https://randomuser.me/api/portraits/men/39.jpg"
        },
        timestamp: "20 weeks ago",
        content: "Using GIS technology to analyze spatial data.",
        link: "#",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzmgX-Cyx390d8EwN3BOIW6qbulqrsKHGFiw&s",
        likes: 118,
        comments: [
            { user: "Dakota Perry", text: "Amazing insights!" },
            { user: "Rowan Collins", text: "Great work!" }
        ]
    },

    // Add more posts here
];

export const messagesData = [
    {
        threadId: "jane-doe",
        user: {
            name: "Jane Doe",
            avatar: "https://randomuser.me/api/portraits/women/2.jpg"
        },
        messages: [
            { sender: "Jane Doe", text: "Hi John!" },
            { sender: "John Doe", text: "Hello Jane!" }
        ]
    },
    {
        threadId: "john-smith",
        user: {
            name: "John Smith",
            avatar: "https://randomuser.me/api/portraits/men/4.jpg"
        },
        messages: [
            { sender: "John Smith", text: "Hey, how's it going?" },
            { sender: "You", text: "Good, thanks!" }
        ]
    }
    // More message threads
];