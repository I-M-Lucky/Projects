// script.js
import { profilesData, postsData, messagesData } from './data.js';

let userComments = JSON.parse(localStorage.getItem('userComments') || '[]');
let currentUser = {
    name: "John Doe",
    profession: "Web Developer",
    location: "San Francisco",
    image: "https://randomuser.me/api/portraits/men/1.jpg"
};

// Authentication Functions
function registerUser(username, password, confirmPassword) {
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    // Basic username/password validation (improve this!)
    if (username.length < 3 || password.length < 6) {
        alert("Username must be at least 3 characters and password at least 6 characters.");
        return false;
    }

    // Check if username already exists
    const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
    if (existingUsers.find(user => user.username === username)) {
        alert("Username already exists.");
        return false;
    }

    const newUser = { username: username, password: password };
    existingUsers.push(newUser);
    localStorage.setItem('users', JSON.stringify(existingUsers));
    alert("Registration successful!");
    showLoginForm();
    return true;
}

function loginUser(username, password) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        localStorage.setItem('loggedInUser', username);
        updateUI();
        return true;
    } else {
        alert("Invalid username or password.");
        return false;
    }
}

function logoutUser() {
    localStorage.removeItem('loggedInUser');
    hideProfileBox();
    showLoginForm(); // Redirect to login form
}

function isLoggedIn() {
    return localStorage.getItem('loggedInUser') !== null;
}

// UI Update Functions
function showLoginForm() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('messages').style.display = 'none';
    document.getElementById('settings').style.display = 'none';
    hideProfileBox();
    hideCreatePostOverlay();
}

function showRegisterForm() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('messages').style.display = 'none';
    document.getElementById('settings').style.display = 'none';
    hideProfileBox();
    hideCreatePostOverlay();
}

function showApp() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('feed').style.display = 'block';
    document.getElementById('messages').style.display = 'none';
    document.getElementById('settings').style.display = 'none';
    showProfileBox();
}

function updateUI() {
    if (isLoggedIn()) {
        showApp();
        const username = localStorage.getItem('loggedInUser');
        const loggedInUserElement = document.getElementById('logged-in-user'); // Get the element
        if (loggedInUserElement) { // Check if the element exists
            loggedInUserElement.textContent = username;
        }

        renderFeed(postsData);
         renderMessages();

    } else {
        showLoginForm();
    }
}

// Function to display profile box
function showProfileBox() {
    const profileBox = document.getElementById('user-profile-box');
    const loggedInUser = localStorage.getItem('loggedInUser');
    const profileImage = document.getElementById('profile-box-image');
    const profileName = document.getElementById('profile-box-name');
    const profileProfession = document.getElementById('profile-box-profession');

   if (loggedInUser) {
        const userProfile = profilesData.find(profile => profile.name === loggedInUser);
        if (userProfile) {
            profileImage.src = userProfile.image;
            profileName.textContent = userProfile.name;
            profileProfession.textContent = userProfile.profession;
        }
        else{
             profileImage.src = currentUser.image;
             profileName.textContent = currentUser.name;
             profileProfession.textContent = currentUser.profession;
        }
    } else{
        profileImage.src = currentUser.image;
        profileName.textContent = currentUser.name;
        profileProfession.textContent = currentUser.profession;
    }

    profileBox.style.display = 'flex';
}

// Function to hide profile box
function hideProfileBox() {
    const profileBox = document.getElementById('user-profile-box');
    profileBox.style.display = 'none';
}

// Function to show create post overlay
function showCreatePostOverlay() {
    document.getElementById('create-post-overlay').style.display = 'flex';
}

// Function to hide create post overlay
function hideCreatePostOverlay() {
    document.getElementById('create-post-overlay').style.display = 'none';
}

function viewProfile(profileElement) {
    const profileName = profileElement.dataset.profileName;
    const profile = profilesData.find(p => p.name === profileName);
    const loggedInUser = localStorage.getItem('loggedInUser');
        let messageHistory = JSON.parse(localStorage.getItem(`messageHistory_${loggedInUser}_${profileName}`) || '[]');
        renderMessageHistory(messageHistory);

    if (profile) {
        const profileContent = document.getElementById('profile-content');
        // Clear existing content
        profileContent.innerHTML = `
            <div class="profile-details">
                <img src="${profile.image}" alt="Profile Picture">
                <h2>${profile.name}</h2>
                <p>${profile.profession}</p>
                <p>${profile.location}</p>
                <div class="about-section">
                    <h3>About</h3>
                    <p>${profile.about}</p>
                </div>
                <div class="user-posts-section">
                    <h3>Posts by ${profile.name}</h3>
                    <div id="user-posts-list">
                        <!-- User's posts will be loaded here -->
                    </div>
                </div>
            </div>
        `;

        const userPostsList = document.getElementById('user-posts-list');
        const userPosts = postsData.filter(post => post.user.name === profile.name);

        userPosts.forEach(post => {
            const postDiv = document.createElement('div');
            postDiv.classList.add('user-post'); // Add a class for styling if needed
            postDiv.innerHTML = `
                <p>${post.content}</p>
                <img src="${post.image}" alt="Post Image" style="max-width: 100px;">
            `;
            userPostsList.appendChild(postDiv);
        });
        document.getElementById('profile-overlay').style.display = 'flex'; // Show the overlay
        document.getElementById('conversation-area').style.display = 'none';
        document.getElementById('profile-content').style.display = 'block';
    } else {
        console.error('Profile not found:', profileName);
        alert('Profile not found.');
    }
}

function closeProfileView() {
    document.getElementById('profile-overlay').style.display = 'none'; // Hide the overlay
    // Hide the conversation area
    document.getElementById('conversation-area').style.display = 'none';
     document.getElementById('profile-content').style.display = 'block';
      document.getElementById('emoji-picker').style.display = 'none';
}

function likePost(button, postId) {
    let likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
    const likeCountElement = button.querySelector('.like-count');
    let likeCount = parseInt(likeCountElement.textContent, 10);

    if (likedPosts.includes(postId)) {
        likedPosts = likedPosts.filter(id => id !== postId);
        likeCount--;
        button.classList.remove('liked');
    } else {
        likedPosts.push(postId);
        likeCount++;
        button.classList.add('liked');
    }

    localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
    likeCountElement.textContent = likeCount;

    displayLikedPosts();

    // In a real app, you'd send a request to the server to update the like count
}

function addComment(button, postId) {
    if (!isLoggedIn()) {
        alert("You must be logged in to add a comment.");
        return;
    }

    const post = button.closest('.post');
    const commentTextarea = post.querySelector('.comment-textarea');
    const commentText = commentTextarea.value;

    if (commentText.trim() !== "") {
        const newComment = {
            postId: postId,
            text: commentText
        };

        userComments.push(newComment);
        localStorage.setItem('userComments', JSON.stringify(userComments));

        // Clear the textarea *before* rendering
        commentTextarea.value = '';

        renderFeed(postsData); // Re-render the feed to update comments
        displayUserComments(); // Update displayed comments in settings

    } else {
        alert("Please enter a comment.");
    }
}
function openConversation(username) {
    alert(`Opening conversation with ${username}`);
    // In a real app, you'd fetch conversation data and display it
    // You'd also show/hide the relevant sections
}

function showSection(sectionId) {
    // Explicitly hide all sections
    document.getElementById('feed').style.display = 'none';
    document.getElementById('messages').style.display = 'none';
    document.getElementById('settings').style.display = 'none';

    // Show the selected section
    const sectionToShow = document.getElementById(sectionId);
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
        if (sectionId === 'feed') {
            renderFeed(postsData);
        }
        if (sectionId === 'messages') {
            renderMessages();
        }
        if (sectionId === 'settings') {
            renderSettings();
        }
    }
}

function searchProfiles() {
    const searchInput = document.getElementById('search-input').value.toLowerCase();
    const profileList = document.getElementById('profile-list');
    profileList.innerHTML = ''; // Clear previous results

    const filteredProfiles = profilesData.filter(profile => {
        return profile.name.toLowerCase().includes(searchInput) ||
            profile.profession.toLowerCase().includes(searchInput) ||
            profile.location.toLowerCase().includes(searchInput);
    });

    // Append profiles to the profile-list using a DocumentFragment
    const fragment = document.createDocumentFragment();
    filteredProfiles.forEach(profile => {
        const profileElement = createProfileElement(profile); // Get a DOM element
        fragment.appendChild(profileElement); // Append element to fragment
    });
    profileList.appendChild(fragment); // Append fragment to profile-list
}

function createProfileElement(profile) {
    const template = document.getElementById('profile-template');
    const profileElement = template.content.cloneNode(true);

    // Set profile data
    const img = profileElement.querySelector('[data-field="image"]');
    img.src = profile.image;

    const nameElement = profileElement.querySelector('[data-field="name"]');
    nameElement.textContent = profile.name;

    const profession = profileElement.querySelector('[data-field="profession"]');
    profession.textContent = profile.profession;

    const location = profileElement.querySelector('[data-field="location"]');
    location.textContent = profile.location;

    // Extract the profile div
    const profileDiv = profileElement.querySelector('.profile');
    profileDiv.dataset.profileName = profile.name; // Store profile name

    // Set click handler for the view profile button
    const viewProfileButton = profileElement.querySelector('button');
    viewProfileButton.addEventListener('click', function () {
        viewProfile(profileDiv); // Pass the profileDiv
    });

    return profileDiv;
}

function likeProfile() {
    alert('Profile Liked!');
    // In a real app, you'd send a request to the server to update the like count
}

function commentProfile() {
    alert('Commenting on Profile');
    // In a real app, you'd open a comment input and handle the comment submission
}

// Demo comments
const demoComments = [
    { user: "John Doe", text: "Great post!" ,avatar: "https://randomuser.me/api/portraits/men/1.jpg"},
    { user: "Jane Smith", text: "Interesting thoughts.", avatar: "https://randomuser.me/api/portraits/women/4.jpg" },
    { user: "David Lee", text: "Thanks for sharing!", avatar: "https://randomuser.me/api/portraits/men/3.jpg"},
];

function renderFeed(posts) {
    const feedElement = document.getElementById('feed');
    feedElement.innerHTML = '<h2>Feed</h2>'; // Clear existing content

    posts.forEach((post, index) => {
        const postDiv = document.createElement('div');
        postDiv.classList.add('post');
        postDiv.dataset.postId = index;
        let likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
        const isLiked = likedPosts.includes(index.toString());

        postDiv.innerHTML = `
            <div class="post-header">
                <div class="profile post-profile" data-profile-name="${post.user.name}">
                    <img src="${post.user.avatar}" alt="User Avatar">
                    <span>${post.user.name}</span>
                </div>
                <span class="timestamp">${post.timestamp}</span>
            </div>
            <p>${post.content} <a href="${post.link}">${post.link}</a></p>
            <img src="${post.image}" alt="Project Image">
            <div class="post-actions">
                <button class="like-button ${isLiked ? 'liked' : ''}">
                    Like <span class="like-count">${post.likes}</span>
                </button>
                <button class="share-button">Share</button>
            </div>
            <div class="comment-section" style="display: block;">
                <div class="comments">
                    <!-- Comments will appear here -->
                </div>
                <textarea class="comment-textarea" placeholder="Add a comment..."></textarea>
                <button class="add-comment-button">Add Comment</button>
            </div>
        `;
        feedElement.appendChild(postDiv);

        const commentsContainer = postDiv.querySelector('.comments');
        // Filter comments for this post
        const postComments = userComments.filter(comment => comment.postId === index.toString());

        postComments.forEach(comment => {
            const commentDiv = document.createElement('div');
            commentDiv.classList.add('comment');
            commentDiv.textContent = comment.text;
            commentsContainer.appendChild(commentDiv);
        });

         // Set comment section height dynamically
        const postHeight = postDiv.offsetHeight;
        const commentSection = postDiv.querySelector('.comment-section');
        commentSection.style.height = `${postHeight - 23}px`;

    });

    // Add event listeners to the profile links within posts.
    const postProfiles = document.querySelectorAll('.post-profile');
    postProfiles.forEach(profile => {
        profile.addEventListener('click', function() {
            viewProfile(this); // 'this' refers to the clicked .post-profile element
        });
    });
}
function renderMessageHistory(messageHistory) {
    const messagesDisplay = document.getElementById('messages-display');
    messagesDisplay.innerHTML = ''; // Clear existing messages

    messageHistory.forEach(message => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add(message.sender === 'You' ? 'message-sent' : 'message-received');
        messageDiv.textContent = `${message.sender}: ${message.text}`;
        messagesDisplay.appendChild(messageDiv);
    });
     messagesDisplay.scrollTop = messagesDisplay.scrollHeight; // Scroll to the bottom
}

function renderMessages() {
    const messagesList = document.getElementById('messages-list');
    messagesList.innerHTML = ''; // Clear any existing content

    const loggedInUser = localStorage.getItem('loggedInUser');

    // Get all keys in localStorage
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);

        // Check if the key is a message history key
        if (key.startsWith('messageHistory_')) {
            // Extract the user names from the key
            const parts = key.replace('messageHistory_', '').split('_');
            const user1 = parts[0];
            const user2 = parts[1];

            // Determine the other user in the conversation
            const otherUser = (user1 === loggedInUser) ? user2 : user1;

            // Check if there is already a message thread between these users
            const existingThread = Array.from(messagesList.children).find(thread => thread.dataset.otherUser === otherUser);

            if (!existingThread && otherUser !== loggedInUser) {
                // Create a display element for the message history
                const messageThread = document.createElement('div');
                messageThread.classList.add('message-thread'); // Add a class for styling
                messageThread.dataset.otherUser = otherUser;

                // Display who the conversation is with
                messageThread.textContent = `Conversation with: ${otherUser}`;

                // Attach a click event to view the conversation
                messageThread.addEventListener('click', function () {
                    // Set the current profile name to the other user
                    const profileDiv = document.querySelector(`.profile[data-profile-name="${otherUser}"]`);
                    if (profileDiv) {
                        viewProfile(profileDiv);
                         showSection('feed');
                    } else {
                        console.log("Profile not found");
                    }
                });
                 messagesList.appendChild(messageThread);
            }
        }
    }
}
function renderSettings() {
    const settingsContent = document.getElementById('settings-content');
    settingsContent.innerHTML = `
        <button id="edit-profile-button">Edit Profile</button>
        <button id="change-password-button">Change Password</button>

        <div id="edit-profile-section" style="display:none;">
            <h3>Edit Profile</h3>
            <label for="edit-name">Name:</label>
            <input type="text" id="edit-name" value="${currentUser.name}"><br><br>
            <label for="edit-profession">Profession:</label>
            <input type="text" id="edit-profession" value="${currentUser.profession}"><br><br>
            <label for="edit-location">Location:</label>
            <input type="text" id="edit-location" value="${currentUser.location}"><br><br>
            <button id="save-profile-button">Save Changes</button>
        </div>

        <div id="change-password-section" style="display:none;">
            <h3>Change Password</h3>
            <label for="current-password">Current Password:</label>
            <input type="password" id="current-password"><br><br>
            <label for="new-password">New Password:</label>
            <input type="password" id="new-password"><br><br>
            <label for="confirm-password">Confirm New Password:</label>
            <input type="password" id="confirm-password"><br><br>
            <button id="update-password-button">Update Password</button>
        </div>

        <section id="liked-posts">
            <h3>Liked Posts</h3>
            <div id="liked-posts-list">
                <!-- Liked posts will be displayed here -->
            </div>
        </section>

        <section id="user-comments">
            <h3>My Comments</h3>
            <div id="user-comments-list">
                <!-- User comments will be displayed here -->
            </div>
        </section>
    `;

    displayLikedPosts();
    displayUserComments();
    attachSettingsEventListeners();
}

function attachSettingsEventListeners() {
    document.getElementById('edit-profile-button').addEventListener('click', function() {
        document.getElementById('edit-profile-section').style.display = 'block';
        document.getElementById('change-password-section').style.display = 'none';
    });

    document.getElementById('change-password-button').addEventListener('click', function() {
        document.getElementById('change-password-section').style.display = 'block';
        document.getElementById('edit-profile-section').style.display = 'none';
    });

    document.getElementById('save-profile-button').addEventListener('click', function() {
        currentUser.name = document.getElementById('edit-name').value;
        currentUser.profession = document.getElementById('edit-profession').value;
        currentUser.location = document.getElementById('edit-location').value;
        showProfileBox()
        alert('Profile updated!');
        renderSettings();
    });

    document.getElementById('update-password-button').addEventListener('click', function() {
        alert('Password updated!');
    });
}
function displayLikedPosts() {
    const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
    const likedPostsList = document.getElementById('liked-posts-list');
    likedPostsList.innerHTML = '';

    likedPosts.forEach(postId => {
        const post = postsData[postId];
        if (post) {
            const postDiv = document.createElement('div');
            postDiv.classList.add('liked-post');
            postDiv.dataset.postId = postId; // Store post ID for unlike
            postDiv.innerHTML = `
                <a href="#post-${postId}">
                    <p>${post.content}</p>
                    <img src="${post.image}" alt="Post Image" style="max-width: 100px;">
                </a>
                <button class="unlike-button">Unlike</button>
            `;
            likedPostsList.appendChild(postDiv);
        }
    });
}
function displayUserComments() {
    const userCommentsList = document.getElementById('user-comments-list');
    userCommentsList.innerHTML = ''; // Clear existing content

    userComments = JSON.parse(localStorage.getItem('userComments') || '[]');

    userComments.forEach(comment => {
        const post = postsData[comment.postId];
        if (post) {
            const commentDiv = document.createElement('div');
            commentDiv.classList.add('user-comment');
            commentDiv.innerHTML = `
                <p><strong>Post:</strong> ${post.content.substring(0, 50)}...</p>
                <p><strong>Comment:</strong> ${comment.text}</p>
                <button class="delete-comment-button" data-post-id="${comment.postId}">Delete</button>
            `;
            userCommentsList.appendChild(commentDiv);
        }
    });
}
function unlikePost(postId) {
    let likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
    likedPosts = likedPosts.filter(id => id !== postId);
    localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
    displayLikedPosts(); // Refresh liked posts
    const postDiv = document.querySelector(`.post[data-postid="${postId}"]`);
        if (postDiv) {
            const likeButton = postDiv.querySelector('.like-button');
            if (likeButton) {
                likeButton.classList.remove('liked');
                let likeCountElement = likeButton.querySelector('.like-count');
                let currentLikes = parseInt(likeCountElement.textContent);
                 likeCountElement.textContent = currentLikes -1;
            }
        }
}

// Event delegation for feed buttons
document.getElementById('feed').addEventListener('click', function(event) {
    if (event.target.classList.contains('like-button')) {
        const postDiv = event.target.closest('.post');
        const postId = postDiv.dataset.postId;
        likePost(event.target, postId);
    } else if (event.target.classList.contains('share-button')) {
        const postDiv = event.target.closest('.post'); // Find the parent post element
        const postLink = window.location.href; // Get the current page URL
         // Copy the post link to clipboard
        navigator.clipboard.writeText(postLink)
            .then(() => {
                alert('Post link copied to clipboard!');
            })
            .catch(err => {
                console.error('Failed to copy link: ', err);
                alert('Failed to copy link to clipboard.');
            });

    } else if (event.target.classList.contains('add-comment-button')) {
        const postDiv = event.target.closest('.post');
        const postId = postDiv.dataset.postId;
        addComment(event.target, postId);
    }
});

// Event listener for unlike button (using event delegation)
document.getElementById('settings').addEventListener('click', function(event) {
    if (event.target.classList.contains('unlike-button')) {
        const postDiv = event.target.closest('.liked-post');
        const postId = postDiv.dataset.postId;
        unlikePost(postId);
    } else if (event.target.classList.contains('delete-comment-button')) {
        const commentDiv = event.target.closest('.user-comment');
        const postId = event.target.dataset.postId;
        deleteComment(postId);
    }
});
// Programmatically attach event listeners to header links
document.querySelector('nav a[href="#feed"]').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent default anchor behavior
    showSection('feed');
});

document.querySelector('nav a[href="#messages"]').addEventListener('click', function(event) {
    event.preventDefault();
    showSection('messages');
});

document.querySelector('nav a[href="#settings"]').addEventListener('click', function(event) {
    event.preventDefault();
    showSection('settings');
});

//Attach event listener to close profile view button
document.getElementById('profile-overlay').addEventListener('click', function(event) {
    if (event.target.id === 'profile-overlay') {
        closeProfileView();
    }
});

// Attach event listeners to profile view buttons, add post button, and create post overlay
document.addEventListener('click', function(event) {
    // Search
    if(event.target.closest('.search-bar button')) {
        searchProfiles();
    }
    // Attach a click listener to the setting button
     if (event.target.id === 'settings-button' || event.target.closest('#settings-button')) {
        showSection('settings');
    }

   // Attach a click listener to the setting button
      if (event.target.id === 'logout-button' || event.target.closest('#logout-button')) {
        logoutUser();
    }

    if (event.target.id === 'close-profile-button' || event.target.closest('#close-profile-button')) {
        closeProfileView();
    }
     if (event.target.id === 'message-profile-button' || event.target.closest('#message-profile-button')) {
         // Show the conversation area
        document.getElementById('conversation-area').style.display = 'block';
        //Hide other elements
        document.getElementById('profile-content').style.display = 'none';
           // Get profile name of other user
         const profileName = document.querySelector('#profile-content h2').innerText;
         //Load message history
        const loggedInUser = localStorage.getItem('loggedInUser');
        let messageHistory = JSON.parse(localStorage.getItem(`messageHistory_${loggedInUser}_${profileName}`) || '[]');
        renderMessageHistory(messageHistory);
    }
     if (event.target.id === 'add-post-button' || event.target.closest('#add-post-button')) {
        showCreatePostOverlay();
    }
     if (event.target.id === 'cancel-post-button' || event.target.closest('#cancel-post-button')) {
        hideCreatePostOverlay();
    }
     if (event.target.id === 'submit-post-button' || event.target.closest('#submit-post-button')) {
         const newPostContent = document.getElementById('new-post-content').value;
        const postImageUpload = document.getElementById('post-image-upload');
        const loggedInUser = localStorage.getItem('loggedInUser');
        let userAvatar = "https://randomuser.me/api/portraits/men/1.jpg"; // Default avatar
        let postImageURL = "https://via.placeholder.com/300"; // Default image URL

         // Check if an image was uploaded
        if (postImageUpload.files.length > 0) {
            const file = postImageUpload.files[0];
             //Basic file type validation
            if (!file.type.startsWith('image/')){
                alert("Please upload an image file");
                return;
            }
            //Use FileReader to read the contents of the uploaded image
            const reader = new FileReader();
            reader.onload = function (e) {
                postImageURL = e.target.result; // Set postImageURL to the data URL
                createNewPost(loggedInUser, userAvatar, newPostContent, postImageURL);
            }
             reader.readAsDataURL(file)

        } else {
           createNewPost(loggedInUser, userAvatar, newPostContent, postImageURL);
        }
        hideCreatePostOverlay();
    }
         if (event.target.classList.contains('emoji-button')) {
             const messageInput = document.getElementById('message-input');
            messageInput.value += event.target.textContent;
            messageInput.focus();
             document.getElementById('emoji-picker').style.display = 'none';
       }
});
function createNewPost(loggedInUser, userAvatar, newPostContent, postImageURL){
     if (newPostContent.trim() !== "") {
         //Find user profile and set avatar if user exists
         const userProfile = profilesData.find(profile => profile.name === loggedInUser);
        if(userProfile){
            userAvatar = userProfile.image;
        }

        const newPost = {
            user: {
                name: loggedInUser || currentUser.name,
                avatar: userAvatar
            },
            timestamp: "Just now",
            content: newPostContent,
            link: "#",
            image:  postImageURL,
            likes: 0,
            comments: []
        };

        postsData.unshift(newPost); // Add to the beginning of the array
        document.getElementById('new-post-content').value = ""; // Clear textarea
        document.getElementById('post-image-upload').value = ""; //Clear file input
        renderFeed(postsData); // Re-render the feed
    } else {
        alert("Please enter some content for your post.");
    }
}

// Remove demo messages from messagesData
messagesData.length = 0;

// Event listener for the send message button (basic)
document.getElementById('profile-overlay').addEventListener('click', function(event) {
     const fileNameDisplay = document.getElementById('file-name-display');

    if (event.target.id === 'send-message-button') {
        const messageInput = document.getElementById('message-input');
        const messageText = messageInput.value;
         const loggedInUser = localStorage.getItem('loggedInUser');
         // Get profile name of other user
         const profileName = document.querySelector('#profile-content h2').innerText;
        if (messageText.trim() !== "") {
             //Save messages in local storage
            let messageHistory = JSON.parse(localStorage.getItem(`messageHistory_${loggedInUser}_${profileName}`) || '[]');
             messageHistory.push({ sender: "You", text: messageText });
           localStorage.setItem(`messageHistory_${loggedInUser}_${profileName}`, JSON.stringify(messageHistory));
            //Also store in the reverse order
           let reverseMessageHistory = JSON.parse(localStorage.getItem(`messageHistory_${profileName}_${loggedInUser}`) || '[]');
            reverseMessageHistory.push({sender: "Them", text: messageText})
             localStorage.setItem(`messageHistory_${profileName}_${loggedInUser}`, JSON.stringify(reverseMessageHistory));

          // Render the new message
            renderMessageHistory(messageHistory);
             messageInput.value = ""; // Clear the input

            // Simple auto-scroll
            const messagesDisplay = document.getElementById('messages-display');
            messagesDisplay.scrollTop = messagesDisplay.scrollHeight;
               renderMessages()
        }
    }
          if (event.target.id === 'attach-file-button') {
               const fileInput = document.createElement('input');
            fileInput.type = 'file';
             fileInput.addEventListener('change', function() {
                 if (fileInput.files.length > 0) {
                      fileNameDisplay.textContent = `Selected File: ${fileInput.files[0].name}`;
                       // You could add file content processing code here if you
                      // were implementing actual file uploading
                      const file = fileInput.files[0];
                      const reader = new FileReader();
                      reader.onload = function(e) {
                         // Here you can access the file content via e.target.result
                         // e.g., for sending it to the server
                         console.log("File content:", e.target.result);
                         // In a real application, you'd send this data to your server
                     }
                       reader.readAsDataURL(file); // Read the file as a data URL
                 } else{
                     fileNameDisplay.textContent ="";
                 }
             });
             fileInput.click();

    }

    if (event.target.id === 'add-emoji-button') {
           const emojiPicker = document.getElementById('emoji-picker');
         emojiPicker.style.display = emojiPicker.style.display === 'none' ? 'block' : 'none';
    }

});
// Add event listeners to emoji buttons
document.addEventListener('click', function(event) {

       if (event.target.classList.contains('emoji-button')) {
           const messageInput = document.getElementById('message-input');
             messageInput.value += event.target.textContent;
            messageInput.focus();
                        document.getElementById('emoji-picker').style.display = 'none';
       }

            // Login Button
    if (event.target.id === 'login-button' || event.target.closest('#login-button')) {
         const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        loginUser(username, password);
    }
           //Register Button
    if (event.target.id === 'register-button' || event.target.closest('#register-button')) {
         const username = document.getElementById('register-username').value;
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('register-confirm-password').value;
        registerUser(username, password, confirmPassword);
    }
  if (event.target.id === 'show-register-link' || event.target.closest('#show-register-link')) {
         showRegisterForm();
    }
      if (event.target.id === 'show-login-link' || event.target.closest('#show-login-link')) {
         showLoginForm();
    }
});
// Initial profile load
document.addEventListener('DOMContentLoaded', function () {
    updateUI(); // Check login status on page load
    searchProfiles(); // Load all profiles initially
    renderSettings();
         renderMessages();

    //Make profile-list profile tappable
    const profileList = document.getElementById('profile-list');
    profileList.addEventListener('click', function(event){
        if(event.target.classList.contains('profile')){
            viewProfile(event.target);
        }
    });
});

function deleteComment(postId) {
    userComments = userComments.filter(comment => comment.postId !== postId);
    localStorage.setItem('userComments', JSON.stringify(userComments));
    displayUserComments();
    renderFeed(postsData); // Re-render the feed to update comments
}