
document.addEventListener('DOMContentLoaded', () => {

    // ======== STATE MANAGEMENT ========
    let state = {
        currentServer: null,
        currentChannel: null,
        currentTheme: 'dark',
        isAuthenticated: false,
        currentUser: null,
        isMemberListVisible: true,
        isPinsVisible: false,
        activeDropdown: { id: null, target: null, context: null },
        activeModals: [], // FIX: Changed from activeModal: null to an array for stacking
        activeDmView: 'friends',
        activeFriendsTab: 'online',
        currentOpenDm: null,
        editingMessageId: null,
        replyingToMessageId: null,
        isMuted: false,
        isDeafened: false,
    };

    // ======== CONSTANTS & MOCK DATA ========
    let appData = JSON.parse(localStorage.getItem('accordData')) || mockData;
    
    // FIX: Expanded the GIF and Emoji lists significantly
    const GIF_URLS = [
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExejc1cXBqZGV3c2VwZ2J3aG5mNGVjM2ZpZmhvY2FpN3Z5c3h2bWlxZyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/h7dhR80A1tJ8k/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExd2RtaXJ2aXo4d3Y0NjhpdXk5bzI3bnIzbXl2cHF3NmgwaWd4eXA1aSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o72FfM5HJydzafgUE/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM2F3ZXdzamQxdWxoZmNtdGJ0eTFudjQxb2p0bnhwc2NjbDRxcmk4aCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l3q2K5jinAlChoCLS/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNndrMTY4ejJqaHJjYmU2dm9xN2U0ZmNucW1sbDQzeGFta200anFwaSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/gVoBC0SuaHStq/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExY3g1eDI3aTdnaXA4c3h1eDF2Z3N2c3d0b2Y1enJtN214b2w0Z2w1aSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o7btNa0aYhrG3lg2I/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExaDZob3BtdG5qZ3B5d2Y5bWJqN2w1c2M5b3N6b3Y2c3d5eDF4c3A0YSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l0HlUxc10TfHjAG2I/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExaDNpcHhqeTYweWJtaXk4a242c2Q5a2c4eHRnNGg2aDVoa2U1Z3M0aCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3oKIPuM1xe7L3n8o4U/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbGM1cWJqanBtdnZpY2w0Z3A0emY0N3A1aHN0eHRvMnI2cjZ0cWJ2ZyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l0ExdXwfgdNAmK9RC/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExdnNnbnZ0bTZpY3M0eWdwNng2cmZ0bXN0MnB0ejZ6a3V2b3h6dGhuZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/xT0xezQW9g7aOaW43S/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbTZrZzU2dDN2cDM3aTN0bmFqMnE2bXJ3emw0a3JtNHM3bzI3a2dycyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o7aDczpC2i2aXoOli/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZWFheGVxYTMwbjRucXBjNWhybmQ0enExeDVqYXd5N253aHkxbDY2eCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/McsgoP7m2f212/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbW01Z3Nia3JmMHdzM2s5M2Z2OHJ1ZmU1dWFtbTczZzA0dGZqemc4YyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/tqj4m9BR20s2sLpD4m/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcDBxOXVzd2kwaGhoZ2E5bXp1b250ajJtbnZnZ3NlbnRzdmFvZDZ4eSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/5s1IgI6bBde0/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYnplM2pkaHBta2JieG90YmQ0cDU3cXBzY2s1aXN6cTN3dGVoZmJnayZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/u2dI2h52gAzNS/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcHY4NWV2cG1ua216bm9yZHVzZTU3bnFndjU0cmFkdHJpNXE4ZzZhaCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/xT1XGzAb3soFdt2i5i/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMzV0cGQ3b2ZxdWl4YmhpZWQ0ZnJtdmhnb3d2d2d0bXdzZGRqZ3ZzNiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/r2erMqJkXk52M/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNGIyMmxucjlzMGRxN2Fsc2Y2dmtpcGZ0cnFkdzBmb3Y0NmZ6M2VscCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3ornjS3x2P9T2sIeHe/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3B4ZzhkY3I1bHlsZWc3cjh2NW9pZGV2czM3Z252bzdqY3M0cTBrNiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/d4blalI6x2TdVhIs/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExczB1bjNqZXFxdzh0N3N1cDR1eTBudmYxa3l6c3J0Z3N5eDRvdXFyaSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Y2adR9rr312a4/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNWY0Z29kNGk2NHc3aHg0aXhjaXN5bGUycXp0bXN4dWZmbmV6enB1MSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/4Zo41lhz2xVf2/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExN3RjZnJoYXJjYnNqNjNrcjZtNjB0eTdyb2h1MWZ6MmczbXNoczhwayZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/10X22vOfd3A9aw/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZjFmcHk0eWpkYnZ2d3VzbjV4aGV6YXBwbmZoaXg5OTF0aTZzcDdtbyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Jalikml2Vob2E/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcGljdWdseHh6OTVtc25md2dqbHBqN3I2ZW14MmVyc2g0MnN4NWwwNiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/i20a8T3wXU6A0/giphy.gif',
        'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExaDZrc3A4aG1udGtqNWM1OHl6ZThucGZ2M3g2bjZtbjZkYXU1a3ZxbSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/YPz7bVEvK0uw8/giphy.gif'
    ];
    const ALL_EMOJIS = [
        '👍', '❤️', '😂', '😮', '😢', '🔥', '🎉', '🤔', '👋', '👏', '👀', '💯', '🙏', '🤯', '😎', '✅',
        '😀', '😁', '😅', '🤣', '😇', '😉', '😊', '😍', '🤩', '😘', '😗', '😚', '😋', '😛', '😜', '🤪',
        '🤨', '🧐', '🤓', '🥳', '🥴', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗', '🤭', '🤫', '🤥',
        '😶', '😐', '😑', '😬', '🙄', '😯', '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐',
        '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '😈', '👿', '👹', '👺', '🤡', '💩', '👻', '💀',
        '☠️', '👽', '👾', '🤖', '🎃', '😺', '😸', '😹', '😻', '😼', '😽', '🙀', '😿', '😾', '🤲', '👐',
        '🙌', '🙏', '🤝', '👍', '👎', '👊', '✊', '🤛', '🤜', '🤞', '✌️', '🤟', '🤘', '👌', '🤏', '👈',
        '👉', '👆', '👇', '☝️', '✋', '🤚', '🖐', '🖖', '👋', '🤙', '💪', '🦾', '🖕', '✍️', '🤳', '💅',
        '👂', '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀', '👁️', '👅', '👄', '👶', '🧒', '👦', '👧',
        '🧑', '👱', '👨', '🧔', '👩', '🧓', '👴', '👵', '🙍', '🙎', '🙅', '🙆', '💁', '🙋', '🧏', '🙇',
        '🤦', '🤷', '👮', '🕵️', '💂', '🥷', '👷', '🤴', '👸', '👳', '👲', '🧕', '🤵', '👰', '🤰', '🤱'
    ];


    // ======== DOM ELEMENT SELECTORS (CACHE) ========
    const $ = (selector) => document.querySelector(selector);
    const $$ = (selector) => document.querySelectorAll(selector);

    const elements = {
        // Auth
        authContainer: $('#auth-container'), loginView: $('#login-view'), registerView: $('#register-view'),
        loginForm: $('#login-form'), registerForm: $('#register-form'), showRegisterLink: $('#show-register'),
        showLoginLink: $('#show-login'), loginErrorEl: $('#login-error'), registerErrorEl: $('#register-error'),
        // Core App
        appContainer: $('#app-container'), mainContent: $('#main-content'), dmContent: $('#dm-content'),
        // Server View
        serverList: $('#servers'), serverNameEl: $('#server-name'), serverHeader: $('#server-header'),
        channelList: $('#channels'), channelNameEl: $('#channel-name'), channelTopicEl: $('#channel-topic'),
        chatMessages: $('#chat-messages'), messageInput: $('#message-input'),
        userList: $('#user-list-sidebar'), memberCount: $('#member-count'), memberListToggle: $('#member-list-toggle'),
        // DM / Friends View
        dmNavLinks: $('#dm-nav-links'), dmList: $('#dm-list'), friendsView: $('#friends-view'),
        addFriendView: $('#add-friend-view'), nitroView: $('#nitro-view'), dmChatView: $('#dm-chat-view'),
        wumpusPlaceholder: $('#wumpus-placeholder'), friendsTabs: $('#friends-tabs'), friendsListContainer: $('#friends-list-container'),
        addFriendButton: $('#add-friend-button'), addFriendInput: $('#add-friend-input'),
        sendFriendRequestBtn: $('#send-friend-request-btn'), addFriendStatusEl: $('#add-friend-status'),
        dmChatUsername: $('#dm-chat-username'), dmChatMessages: $('#dm-chat-messages'),
        dmMessageInput: $('#dm-message-input'), backToFriendsList: $('#back-to-friends-list'),
        findConvoBtn: $('#find-convo-btn'), createDmBtn: $('#create-dm-button'),
        // User Panels
        currentUserNameEl: $('#current-user-name'), currentUserAvatarEl: $('#current-user-avatar'), currentUserSubtextEl: $('#current-user-subtext'),
        currentUserNameDm: $('#current-user-name-dm'), currentUserAvatarDm: $('#current-user-avatar-dm'), currentUserSubtextDm: $('#current-user-subtext-dm'),
        userPanelAvatarWrapper: $('#user-panel-avatar-wrapper'), dmPanelAvatarWrapper: $('#dm-panel-avatar-wrapper'),
        // Modals & Dropdowns
        modalBackdrop: $('#modal-backdrop'), serverDropdown: $('#server-dropdown'), friendActionsDropdown: $('#friend-actions-dropdown'),
        messageActionsDropdown: $('#message-actions-dropdown'), profileActionsDropdown: $('#profile-actions-dropdown'),
        findConvoModal: $('#find-convo-modal'), createGroupDmModal: $('#create-group-dm-modal'),
        profileModalActions: $('#profile-modal-actions'),
        // Global Actions
        homeButton: $('#home-button'), addServerButton: $('#add-server-button'), exploreServersButton: $('#explore-servers-button'),
        logoutButton: $('#logout-button'),
        // Settings Elements
        settingsButton: $('#settings-button'), settingsButtonDm: $('#settings-button-dm'),
        userSettingsModal: $('#user-settings-modal'), serverSettingsModal: $('#server-settings-modal'),
        serverSettingsNav: $('#server-settings-nav'), serverSettingsBtn: $('#server-settings-btn'),
        editUsernameBtn: $('#edit-username-btn'),
        // Toggles & Switches
        muteToggle: $('#mute-toggle'), deafenToggle: $('#deafen-toggle'),
        muteToggleDm: $('#mute-toggle-dm'), deafenToggleDm: $('#deafen-toggle-dm'),
        // Chat Enhancements
        uploadButton: $('#upload-button'), imageUploadInput: $('#image-upload-input'),
        emojiButton: $('#emoji-button'), emojiPicker: $('#emoji-picker'), reactionPicker: $('#reaction-picker'),
        gifButton: $('#gif-button'), replyIndicator: $('#reply-indicator'), cancelReplyBtn: $('#cancel-reply-btn'),
        // DM Chat Enhancements
        dmUploadButton: $('#dm-upload-button'), dmImageUploadInput: $('#dm-image-upload-input'),
        dmEmojiButton: $('#dm-emoji-button'), dmEmojiPicker: $('#dm-emoji-picker'),
        dmGifButton: $('#dm-gif-button'), dmReplyIndicator: $('#dm-reply-indicator'), dmCancelReplyBtn: $('#dm-cancel-reply-btn'),
        // Search
        chatSearchInput: $('#chat-search-input'), findConvoInput: $('#find-convo-input'),
        // Pins
        pinToggleButton: $('#pin-toggle-button'), pinnedMessagesPane: $('#pinned-messages-pane'),
        pinnedMessagesList: $('#pinned-messages-list'), closePinsBtn: $('#close-pins-btn'),
    };

    // ======== PERSISTENCE & UTILITIES ========
    const saveData = () => localStorage.setItem('accordData', JSON.stringify(appData));
    const saveState = () => {
        const minimalState = {
            currentServer: state.currentServer, currentChannel: state.currentChannel,
            currentTheme: state.currentTheme, activeDmView: state.activeDmView,
            activeFriendsTab: state.activeFriendsTab, currentOpenDm: state.currentOpenDm,
        };
        localStorage.setItem('accordState', JSON.stringify(minimalState));
    };
    const loadState = () => Object.assign(state, JSON.parse(localStorage.getItem('accordState')) || {});
    const findUser = (userId) => appData.users[userId];
    const findChannelById = (id) => { for (const s of appData.servers) for (const c of s.channels) { const f = c.items.find(i => i.id === id); if (f) return f; } return null; };
    const findServerById = (id) => appData.servers.find(s => s.id === id);
    const findMessageById = (channelId, messageId) => {
        const isDM = channelId.startsWith('dm');
        if (isDM) {
            return appData.dms.find(d => d.id === channelId)?.messages?.find(m => m.id === messageId);
        }
        return appData.messages[channelId]?.find(m => m.id === messageId);
    }
    const findOrCreateDmWithUser = (friendId) => {
        let dm = appData.dms.find(d => d.participants.length === 2 && d.participants.includes(state.currentUser.id) && d.participants.includes(friendId));
        if (dm) return dm.id;
        const newDm = { id: `dm${Date.now()}`, participants: [state.currentUser.id, friendId], messages: [] };
        appData.dms.push(newDm);
        saveData();
        return newDm.id;
    };
    const showNotification = (message, type = 'info', duration = 3000) => {
        const container = $('#notification-container');
        if (!container) return;
        const toast = document.createElement('div');
        toast.className = `notification-toast ${type}`;
        const icon = document.createElement('i');
        const iconMap = { success: 'fa-solid fa-check-circle', error: 'fa-solid fa-times-circle', info: 'fa-solid fa-info-circle' };
        icon.className = iconMap[type];
        toast.appendChild(icon);
        toast.append(message);
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('fading-out');
            toast.addEventListener('animationend', () => toast.remove());
        }, duration - 400);
    };

    // ======== UI CONTROL & VIEW SWITCHING (MODAL REWORK) ========
    const openModal = (modalId) => {
        closeAllDropdowns();
        // If the backdrop is hidden, show it. It stays visible for stacked modals.
        if (elements.modalBackdrop.classList.contains('hidden')) {
            elements.modalBackdrop.classList.remove('hidden');
        }
        // Push the new modal to the stack and show it.
        state.activeModals.push(modalId);
        $(`#${modalId}`)?.classList.remove('hidden');
        // Special case for loading settings data when the modal opens
        if (modalId === 'user-settings-modal') loadUserSettings();
        if (modalId === 'server-settings-modal') {
             const server = findServerById(state.currentServer);
             if (!server) return closeModal();
             $('#settings-server-name-sidebar').textContent = `${server.name} Settings`;
             $('#server-settings-name-input').value = server.name;
             // Reset to the first tab
             $$('#server-settings-nav a').forEach(a => a.classList.remove('active'));
             $('#server-settings-nav a[data-tab="overview"]').classList.add('active');
             $$('#server-settings-modal .settings-pane').forEach(p => p.classList.add('hidden'));
             $('#server-overview-settings').classList.remove('hidden');
        }
    };

    const closeModal = () => {
        if (state.activeModals.length === 0) return;

        // Pop the topmost modal from the stack.
        const modalToCloseId = state.activeModals.pop();
        const modalEl = $(`#${modalToCloseId}`);

        if (modalEl) {
            // Run the modal-specific cleanup function if it exists.
            if (typeof modalEl._cleanup === 'function') {
                modalEl._cleanup();
                delete modalEl._cleanup; // Prevent memory leaks.
            }
            modalEl.classList.add('hidden');
        }

        // If the modal stack is now empty, hide the backdrop.
        if (state.activeModals.length === 0) {
            elements.modalBackdrop.classList.add('hidden');
        }
    };
    
    const toggleDropdown = (dropdownId, targetElement, context = null) => {
        if (state.activeDropdown.id === dropdownId && state.activeDropdown.context?.messageId === context?.messageId) {
            closeAllDropdowns();
            return;
        }
        closeAllDropdowns();
        state.activeDropdown = { id: dropdownId, target: targetElement, context };
        const dropdown = $(`#${dropdownId}`);
        if (dropdown && targetElement) {
            dropdown.style.visibility = 'hidden';
            dropdown.classList.remove('hidden');
    
            const rect = targetElement.getBoundingClientRect();
            const dropdownHeight = dropdown.offsetHeight;
            const dropdownWidth = dropdown.offsetWidth;
    
            let top = rect.bottom + 5;
            if (top + dropdownHeight > window.innerHeight && rect.top - dropdownHeight > 0) {
                top = rect.top - dropdownHeight - 5;
            }
    
            let left = rect.left;
            if (left + dropdownWidth > window.innerWidth) {
                left = rect.right - dropdownWidth;
            }
            if (left < 5) { left = 5; }
    
            dropdown.style.top = `${top}px`;
            dropdown.style.left = `${left}px`;
            dropdown.style.visibility = 'visible';
        }
    };
    const closeAllDropdowns = () => {
        if (state.activeDropdown.id) {
            const dropdown = $(`#${state.activeDropdown.id}`);
            if (dropdown) {
                dropdown.classList.add('hidden');
                dropdown.style.visibility = '';
            }
            state.activeDropdown = { id: null, target: null, context: null };
        }
        elements.reactionPicker.classList.add('hidden');
        elements.emojiPicker.classList.add('hidden');
        elements.dmEmojiPicker?.classList.add('hidden');
    };
    const showMainContent = () => { elements.dmContent.classList.add('hidden'); elements.mainContent.classList.remove('hidden'); elements.homeButton.classList.remove('active'); renderServers(); };
    const showDmContent = () => {
        state.currentServer = null; state.currentChannel = null;
        elements.mainContent.classList.add('hidden'); elements.dmContent.classList.remove('hidden');
        $$('.server-icon').forEach(el => el.classList.remove('active'));
        elements.homeButton.classList.add('active');
        $$('#dm-nav-links .channel').forEach(el => el.classList.remove('active'));
        const friendsLink = elements.dmNavLinks.querySelector('[data-view="friends"]');
        if (friendsLink) friendsLink.classList.add('active');
        switchDmView('friends');
        saveState();
    };
    const switchDmView = (viewName) => {
        state.activeDmView = viewName;
        [elements.friendsView, elements.addFriendView, elements.nitroView, elements.dmChatView].forEach(view => view.classList.add('hidden'));

        if (viewName === 'shop') {
            elements.friendsView.classList.remove('hidden');
            elements.friendsListContainer.innerHTML = '';
            elements.wumpusPlaceholder.classList.remove('hidden');
            elements.wumpusPlaceholder.innerHTML = `<i class="fa-solid fa-store wumpus-icon"></i><h2>The Shop is currently closed for stocking!</h2><p>Check back later for cool new profile decorations and more.</p>`;
            renderDmList();
            return;
        }

        const viewToShow = $(`#${viewName}-view`);
        if (viewToShow) {
            viewToShow.classList.remove('hidden');
            if (viewName === 'friends') renderFriendsList();
        }
        if (viewName !== 'dm-chat') state.currentOpenDm = null;
        renderDmList();
        saveState();
    };
    const updateUI = () => {
        if (!elements.mainContent.classList.contains('hidden')) {
            renderServers(); renderChannelsAndUsers(); renderCurrentChannel();
        }
        saveState();
    };

    // ======== AUTH LOGIC ========
    const showRegisterForm = () => { [elements.loginErrorEl, elements.registerErrorEl].forEach(el => el.textContent = ''); elements.loginView.classList.add('hidden'); elements.registerView.classList.remove('hidden'); };
    const showLoginForm = () => { [elements.loginErrorEl, elements.registerErrorEl].forEach(el => el.textContent = ''); elements.registerView.classList.add('hidden'); elements.loginView.classList.remove('hidden'); };
    const login = (user) => { state.isAuthenticated = true; state.currentUser = user; localStorage.setItem('isAuthenticated', 'true'); localStorage.setItem('currentUser', JSON.stringify(user)); loadState(); initApp(); elements.authContainer.classList.add('hidden'); elements.appContainer.classList.remove('hidden'); };
    const handleLogin = (e) => { e.preventDefault(); const email = $('#login-email').value, password = $('#login-password').value; const user = Object.values(appData.users).find(u => u.email === email && u.password === password); user ? login(user) : elements.loginErrorEl.textContent = 'Invalid email or password.'; };
    const handleRegister = (e) => {
        e.preventDefault();
        const email = $('#register-email').value, username = $('#register-username').value, password = $('#register-password').value;
        if (!email || !username || !password) { elements.registerErrorEl.textContent = 'All fields are required.'; return; }
        if (Object.values(appData.users).some(u => u.email === email)) { elements.registerErrorEl.textContent = 'An account with this email already exists.'; return; }
        if (Object.values(appData.users).some(u => u.name.toLowerCase() === username.toLowerCase())) { elements.registerErrorEl.textContent = 'Username is already taken.'; return; }
        const newUserId = `user${Date.now()}`;
        const newUser = { id: newUserId, name: username, email, password, avatar: `https://i.pravatar.cc/40?u=${newUserId}`, status: 'online', about: 'New to Accord!', bannerColor: '#7289da', friends: [], pendingRequests: [], sentRequests:[], blocked: [], notes: {}, memberSince: new Date().toISOString().split('T')[0], hasNitro: false, settings: { privacy: { friendRequest: 'everyone', allowDmsFromServers: true } }, voiceSettings: { inputDevice: 'Default', outputDevice: 'Default', inputVolume: 100, outputVolume: 100 } };
        appData.users[newUserId] = newUser;
        saveData();
        login(newUser);
    };
    const handleLogout = () => { ['isAuthenticated', 'currentUser', 'accordState'].forEach(k => localStorage.removeItem(k)); state = { ...state, isAuthenticated: false, currentUser: null, activeModals: [] }; window.location.reload(); };

    // ======== RENDER FUNCTIONS ========
    const renderServers = () => { elements.serverList.innerHTML = ''; appData.servers.forEach(server => { if (!server.users.includes(state.currentUser.id)) return; const serverIcon = document.createElement('div'); serverIcon.className = `server-icon ${server.id === state.currentServer && !elements.mainContent.classList.contains('hidden') ? 'active' : ''}`; serverIcon.dataset.serverId = server.id; serverIcon.dataset.tooltip = server.name; serverIcon.innerHTML = `<img src="${server.icon}" alt="${server.name}">`; elements.serverList.appendChild(serverIcon); }); };
    const renderChannelsAndUsers = () => {
        const server = findServerById(state.currentServer);
        if (!server) { showDmContent(); return; };
        elements.serverNameEl.textContent = server.name;
        elements.channelList.innerHTML = '';
        server.channels.forEach(category => {
            const catDiv = document.createElement('div'); catDiv.className = 'channel-category';
            catDiv.innerHTML = `<i class="fa-solid fa-chevron-down"></i> ${category.category}`;
            elements.channelList.appendChild(catDiv);
            category.items.forEach(channel => {
                const chnItem = document.createElement('li');
                chnItem.className = `channel ${channel.id === state.currentChannel ? 'active' : ''}`;
                chnItem.dataset.channelId = channel.id;
                chnItem.innerHTML = `<i class="fa-solid ${channel.type === 'text' ? 'fa-hashtag' : 'fa-volume-high'}"></i> <span>${channel.name}</span>`;
                elements.channelList.appendChild(chnItem);
            });
        });
        elements.userList.innerHTML = '';
        elements.memberCount.textContent = server.users.length;
        ['online', 'offline'].forEach(statusGroup => {
            const group = server.users.map(id => findUser(id)).filter(u => u && u.status.toLowerCase() !== 'offline' && u.status.toLowerCase() !== 'invisible');
            const offlineGroup = server.users.map(id => findUser(id)).filter(u => u && (u.status.toLowerCase() === 'offline' || u.status.toLowerCase() === 'invisible'));
            
            if (statusGroup === 'online' && group.length > 0) {
                 const header = document.createElement('h3'); header.textContent = `ONLINE — ${group.length}`;
                 elements.userList.appendChild(header);
                 group.forEach(user => {
                     if (!user) return;
                     const item = document.createElement('li');
                     item.className = 'user-list-item'; item.dataset.userId = user.id;
                     item.innerHTML = `<div class="avatar-wrapper"><img src="${user.avatar}" alt="${user.name}" class="avatar"><div class="status ${user.status}"></div></div><span class="username">${user.name}</span>`;
                     elements.userList.appendChild(item);
                 });
            }
            if (statusGroup === 'offline' && offlineGroup.length > 0) {
                const header = document.createElement('h3'); header.textContent = `OFFLINE — ${offlineGroup.length}`;
                elements.userList.appendChild(header);
                offlineGroup.forEach(user => {
                     if (!user) return;
                     const item = document.createElement('li');
                     item.className = 'user-list-item'; item.dataset.userId = user.id;
                     item.innerHTML = `<div class="avatar-wrapper"><img src="${user.avatar}" alt="${user.name}" class="avatar"><div class="status ${user.status}"></div></div><span class="username">${user.name}</span>`;
                     elements.userList.appendChild(item);
                });
            }
        });
    };
    const renderMessages = (messageContainer, messageList, channelId) => {
        if (!messageList) { messageContainer.innerHTML = ''; return; }
        messageContainer.innerHTML = '';
        messageList.forEach(msg => { messageContainer.appendChild(createMessageElement(msg, channelId)); });
        messageContainer.scrollTop = messageContainer.scrollHeight;
    };
    const createMessageElement = (msg, channelId) => {
        const user = findUser(msg.userId);
        if (!user) return document.createDocumentFragment();

        const group = document.createElement('div');
        group.className = 'message-group';
        group.dataset.messageId = msg.id;
        group.dataset.userId = msg.userId;

        let replyHTML = '';
        if (msg.replyingTo) {
            const originalMsg = findMessageById(channelId, msg.replyingTo);
            if (originalMsg) {
                const originalAuthor = findUser(originalMsg.userId);
                let originalContent = originalMsg.content || 'Image';
                if(originalContent.length > 50) originalContent = originalContent.substring(0, 50) + '...';
                replyHTML = `<div class="reply-line"></div><div class="reply-context"><img src="${originalAuthor.avatar}" class="reply-avatar"> <span class="reply-username">${originalAuthor.name}</span> <span class="reply-content">${originalContent}</span></div>`;
            }
        }

        const isEditing = msg.id === state.editingMessageId;
        let textContent;
        if (isEditing) {
            textContent = `<textarea class="edit-message-textarea" rows="3">${msg.content}</textarea><div class="edit-message-info">escape to <span class="cancel-edit">cancel</span> • enter to <span class="save-edit">save</span></div>`;
        } else {
            let contentHTML = msg.content.replace(/@(\w+)/g, '<span class="mention">@$1</span>');
            if (msg.imageUrl) contentHTML += `<br><img src="${msg.imageUrl}" alt="Uploaded content" class="uploaded-image">`;
            textContent = contentHTML;
        }

        const reactionsHTML = (msg.reactions || []).map(reaction => {
            if (reaction.users.length === 0) return '';
            const isActive = reaction.users.includes(state.currentUser.id);
            return `<button class="reaction-btn ${isActive ? 'active' : ''}" data-emoji="${reaction.emoji}"><span class="emoji">${reaction.emoji}</span><span class="count">${reaction.users.length}</span></button>`;
        }).join('');

        const messageActionsHTML = `<div class="message-actions"><i class="fa-solid fa-face-grin-beam" data-tooltip="Add Reaction" data-action="add_reaction"></i><i class="fa-solid fa-reply" data-tooltip="Reply" data-action="reply"></i><i class="fa-solid fa-ellipsis-h" data-tooltip="More" data-action="more"></i></div>`;

        const timestamp = `<span class="message-timestamp">${msg.timestamp}</span>`;
        group.innerHTML = `
            ${replyHTML}
            <div class="message-body" data-timestamp="${msg.timestamp}">
                <img src="${user.avatar}" alt="${user.name}" class="avatar" data-user-id="${user.id}">
                <div class="message-content">
                    <div class="message-header">
                        <span class="message-author" data-user-id="${user.id}">${user.name}</span>
                        ${timestamp}
                    </div>
                    <div class="message-text-wrapper">${textContent}</div>
                    <div class="message-reactions">${reactionsHTML}</div>
                </div>
                ${messageActionsHTML}
            </div>`;

        if (isEditing) {
            const textarea = group.querySelector('.edit-message-textarea');
            setTimeout(() => textarea.focus(), 0);
            textarea.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); saveMessageEdit(msg.id, textarea.value, channelId); } else if (e.key === 'Escape') { cancelMessageEdit(); } });
            group.querySelector('.cancel-edit').onclick = cancelMessageEdit;
            group.querySelector('.save-edit').onclick = () => saveMessageEdit(msg.id, textarea.value, channelId);
        }
        return group;
    };
    const renderDmList = () => {
        elements.dmList.innerHTML = '';
        const dmsToRender = appData.dms.filter(dm => dm.participants.includes(state.currentUser.id));
        
        dmsToRender.forEach(dm => {
            const isGroup = !!dm.name;
            const otherUsers = dm.participants.filter(p => p !== state.currentUser.id);
            const otherUser = isGroup ? null : findUser(otherUsers[0]);
            const displayName = isGroup ? dm.name : otherUser?.name;
            
            if (!displayName) return;

            const item = document.createElement('li');
            item.className = `channel ${state.currentOpenDm === dm.id ? 'active' : ''}`;
            item.dataset.dmId = dm.id;

            let avatarHTML = '';
            let subtext = '';

            if (isGroup) {
                avatarHTML = `<div class="avatar-wrapper"><div class="avatar group-avatar"><i class="fa-solid fa-users"></i></div></div>`;
                subtext = `${dm.participants.length} Members`;
            } else if (otherUser) {
                const statusClass = otherUser.status || 'offline';
                avatarHTML = `<div class="avatar-wrapper"><img src="${otherUser.avatar}" class="avatar"><div class="status ${statusClass}"></div></div>`;
                if (otherUser.activity) {
                    subtext = otherUser.activity;
                }
            }

            item.innerHTML = `
                ${avatarHTML}
                <div class="dm-info">
                    <span class="dm-username">${displayName}</span>
                    ${subtext ? `<span class="dm-subtext">${subtext}</span>` : ''}
                </div>
            `;
            elements.dmList.appendChild(item);
        });
    };
    const renderFriendsList = () => {
        const user = state.currentUser;
        let idsToRender = [];
        
        const placeholderContent = {
            online: { icon: 'fa-ghost', text: "No one's around to play with Wumpus." },
            all: { icon: 'fa-users-slash', text: 'Wumpus is waiting on friends. You don’t have to though!' },
            pending: { icon: 'fa-hourglass-half', text: 'There are no pending friend requests. Here\'s Wumpus for now.' },
            blocked: { icon: 'fa-ban', text: "You can't unblock the Wumpus." }
        };
        let statusText = '';
        
        switch (state.activeFriendsTab) {
            case 'online': idsToRender = user.friends.filter(id => findUser(id)?.status === 'online'); break;
            case 'all': idsToRender = user.friends; break;
            case 'pending': idsToRender = user.pendingRequests; statusText = 'Incoming Friend Request'; break;
            case 'blocked': idsToRender = user.blocked; statusText = 'Blocked'; break;
        }

        elements.friendsListContainer.innerHTML = `<h3>${state.activeFriendsTab.toUpperCase()} — ${idsToRender.length}</h3>`;
        
        elements.wumpusPlaceholder.classList.toggle('hidden', idsToRender.length > 0);
        if (idsToRender.length === 0) {
            const content = placeholderContent[state.activeFriendsTab];
            elements.wumpusPlaceholder.innerHTML = `<i class="fa-solid ${content.icon} wumpus-icon"></i><h2>${content.text}</h2>`;
        }

        idsToRender.forEach(id => {
            const friend = findUser(id);
            if (!friend) return;
            const currentStatusText = (state.activeFriendsTab === 'all') ? (friend.activity || friend.status.charAt(0).toUpperCase() + friend.status.slice(1)) : statusText;
            const item = document.createElement('div');
            item.className = 'friend-list-item'; item.dataset.friendId = id;
            let actionsHTML = '';
            if (state.activeFriendsTab === 'pending') {
                actionsHTML = `<button class="accept-btn" data-tooltip="Accept"><i class="fa-solid fa-check"></i></button><button class="danger-btn" data-tooltip="Ignore"><i class="fa-solid fa-times"></i></button>`;
            } else if (state.activeFriendsTab === 'blocked') {
                actionsHTML = `<button class="unblock-btn" data-tooltip="Unblock"><i class="fa-solid fa-ban"></i></button>`;
            } else {
                actionsHTML = `<i class="fa-solid fa-message" data-tooltip="Message"></i><i class="fa-solid fa-ellipsis-vertical" data-tooltip="More"></i>`;
            }
            item.innerHTML = `<div class="avatar-wrapper" data-user-id="${friend.id}"><img src="${friend.avatar}" alt="${friend.name}" class="avatar"><div class="status ${friend.status}"></div></div><div class="friend-info"><span class="username">${friend.name}</span><span class="status-text">${currentStatusText}</span></div><div class="friend-actions">${actionsHTML}</div>`;
            elements.friendsListContainer.appendChild(item);
        });
    };
    const renderCurrentChannel = () => { const channel = findChannelById(state.currentChannel); if (!channel) return; elements.channelNameEl.textContent = channel.name; elements.channelTopicEl.textContent = channel.topic || ''; elements.messageInput.placeholder = `Message #${channel.name}`; renderMessages(elements.chatMessages, appData.messages[state.currentChannel], state.currentChannel); };
    const renderDmChat = (dmId) => { 
        state.currentOpenDm = dmId; 
        const dm = appData.dms.find(d => d.id === dmId); 
        if (!dm) return; 
        const isGroup = !!dm.name;
        const displayName = isGroup ? dm.name : findUser(dm.participants.find(p => p !== state.currentUser.id))?.name;
        elements.dmChatUsername.textContent = displayName; 
        elements.dmMessageInput.placeholder = `Message @${displayName}`; 
        renderMessages(elements.dmChatMessages, dm.messages, dmId); 
        switchDmView('dm-chat'); 
        renderDmList(); 
    };

    // ======== MODAL IMPLEMENTATIONS ========
    const showConfirmationModal = ({ title, text, confirmText = 'Confirm', confirmClass = 'danger', onConfirm }) => {
        openModal('confirmation-modal');
        $('#confirmation-modal-title').textContent = title;
        $('#confirmation-modal-text').textContent = text;
        const confirmBtn = $('#confirmation-confirm-btn');
        confirmBtn.textContent = confirmText;
        confirmBtn.className = `modal-button small ${confirmClass}`;
        
        const modalEl = $('#confirmation-modal');
        const cancelBtn = $('#confirmation-cancel-btn');

        const confirmHandler = () => {
            if (onConfirm) onConfirm();
            closeModal();
        };

        const cancelHandler = () => {
            closeModal();
        }

        const cleanup = () => {
            confirmBtn.removeEventListener('click', confirmHandler);
            cancelBtn.removeEventListener('click', cancelHandler);
        };

        modalEl._cleanup = cleanup;
        confirmBtn.addEventListener('click', confirmHandler);
        cancelBtn.addEventListener('click', cancelHandler);
    };

    const showPromptModal = ({ title, text, label, initialValue = '', onConfirm }) => {
        openModal('prompt-modal');
        $('#prompt-modal-title').textContent = title;
        $('#prompt-modal-text').textContent = text;
        const inputEl = $('#prompt-modal-input');
        $('#prompt-modal-label').textContent = label;
        inputEl.value = initialValue;
        setTimeout(() => inputEl.focus(), 100);

        const modalEl = $('#prompt-modal');
        const form = $('#prompt-modal-form');
        const cancelBtn = $('#prompt-cancel-btn');
        const closeButton = modalEl.querySelector('.modal-close-button');

        const submitHandler = (e) => {
            e.preventDefault();
            const value = inputEl.value;
            if (onConfirm) onConfirm(value);
            closeModal();
        };
        
        const cancelHandler = () => {
             closeModal();
        }

        const cleanup = () => {
            form.removeEventListener('submit', submitHandler);
            cancelBtn.removeEventListener('click', cancelHandler);
            closeButton.removeEventListener('click', cancelHandler);
        };

        modalEl._cleanup = cleanup;
        form.addEventListener('submit', submitHandler);
        cancelBtn.addEventListener('click', cancelHandler);
        closeButton.addEventListener('click', cancelHandler);
    };


    // ======== FEATURE IMPLEMENTATIONS ========
    // --- Chat & Messages ---
    const addMessage = (content, imageUrl, channelId) => {
        if (!content && !imageUrl) return;
        const newMsg = { id: `m${Date.now()}`, userId: state.currentUser.id, content, imageUrl, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), reactions: [], replyingTo: state.replyingToMessageId };
        const isDM = channelId.startsWith('dm');
        if (isDM) {
            const dm = appData.dms.find(d => d.id === channelId);
            if(dm) { if(!dm.messages) dm.messages = []; dm.messages.push(newMsg); renderDmChat(channelId); }
        } else {
            if (!appData.messages[channelId]) appData.messages[channelId] = [];
            appData.messages[channelId].push(newMsg);
            renderCurrentChannel();
        }
        cancelReply();
        saveData();
    };
    const startEditingMessage = (messageId, channelId) => { state.editingMessageId = messageId; channelId.startsWith('dm') ? renderDmChat(channelId) : renderCurrentChannel(); };
    const cancelMessageEdit = () => { if(state.editingMessageId) { const channelId = state.currentOpenDm || state.currentChannel; state.editingMessageId = null; channelId.startsWith('dm') ? renderDmChat(channelId) : renderCurrentChannel(); } };
    const saveMessageEdit = (messageId, newContent, channelId) => { const message = findMessageById(channelId, messageId); if (message) message.content = newContent; state.editingMessageId = null; saveData(); channelId.startsWith('dm') ? renderDmChat(channelId) : renderCurrentChannel(); };
    const deleteMessage = (messageId, channelId) => { 
        showConfirmationModal({
            title: 'Delete Message',
            text: 'Are you sure you want to delete this message?',
            onConfirm: () => {
                const isDM = channelId.startsWith('dm'); 
                const msgList = isDM ? appData.dms.find(d => d.id === channelId)?.messages : appData.messages[channelId]; 
                if (!msgList) return; 
                const msgIndex = msgList.findIndex(m => m.id === messageId); 
                if (msgIndex > -1) { 
                    msgList.splice(msgIndex, 1); 
                    saveData(); 
                    isDM ? renderDmChat(channelId) : renderCurrentChannel(); 
                }
            }
        });
    };
    const showReactionPicker = (target, messageId, channelId) => { const picker = elements.reactionPicker; picker.innerHTML = ALL_EMOJIS.slice(0, 12).map(e => `<span>${e}</span>`).join(''); picker.dataset.messageId = messageId; picker.dataset.channelId = channelId; const rect = target.getBoundingClientRect(); picker.style.top = `${rect.top - picker.offsetHeight - 5}px`; picker.style.left = `${rect.left - (picker.offsetWidth / 2)}px`; picker.classList.remove('hidden'); };
    const toggleReaction = (messageId, emoji, channelId) => {
        const message = findMessageById(channelId, messageId);
        if (!message) return;
        if (!message.reactions) message.reactions = [];
        let reaction = message.reactions.find(r => r.emoji === emoji);
        if (reaction) {
            const userIndex = reaction.users.indexOf(state.currentUser.id);
            if (userIndex > -1) reaction.users.splice(userIndex, 1);
            else reaction.users.push(state.currentUser.id);
            if (reaction.users.length === 0) message.reactions = message.reactions.filter(r => r.emoji !== emoji);
        } else {
            message.reactions.push({ emoji: emoji, users: [state.currentUser.id] });
        }
        saveData();
        channelId.startsWith('dm') ? renderDmChat(channelId) : renderCurrentChannel();
    };
    const startReply = (messageId, channelId) => {
        const message = findMessageById(channelId, messageId);
        if (!message) return;
        state.replyingToMessageId = messageId;
        const author = findUser(message.userId);
        const isDM = channelId.startsWith('dm');
        const replyIndicator = isDM ? elements.dmReplyIndicator : elements.replyIndicator;
        const replyUserEl = isDM ? $('#dm-reply-indicator-username') : $('#reply-indicator-username');
        const inputEl = isDM ? elements.dmMessageInput : elements.messageInput;

        replyUserEl.textContent = author.name;
        replyIndicator.classList.remove('hidden');
        inputEl.focus();
    };
    const cancelReply = () => {
        state.replyingToMessageId = null;
        elements.replyIndicator.classList.add('hidden');
        elements.dmReplyIndicator?.classList.add('hidden');
    };

    // --- Pinned Messages ---
    const togglePinMessage = (messageId, channelId) => {
        const channel = findChannelById(channelId);
        if (!channel) return;
        if (!channel.pins) channel.pins = [];
        const pinIndex = channel.pins.indexOf(messageId);
        if (pinIndex > -1) {
            channel.pins.splice(pinIndex, 1); // Unpin
            showNotification('Message unpinned.', 'info');
        } else {
            if (channel.pins.length >= 50) {
                showNotification("This channel has reached the 50 pin limit.", "error");
                return;
            }
            channel.pins.push(messageId); // Pin
            showNotification('Message pinned.', 'success');
        }
        saveData();
        if (state.isPinsVisible) renderPinnedMessages(channelId);
    };
    const renderPinnedMessages = (channelId) => {
        const channel = findChannelById(channelId);
        elements.pinnedMessagesList.innerHTML = '';
        if (!channel || !channel.pins || channel.pins.length === 0) {
            elements.pinnedMessagesList.innerHTML = '<p class="no-pins">No pinned messages in this channel yet.</p>';
            return;
        }
        channel.pins.slice().reverse().forEach(msgId => {
            const msg = findMessageById(channelId, msgId);
            if (!msg) return;
            const user = findUser(msg.userId);
            const pinEl = document.createElement('div');
            pinEl.className = 'pinned-message-item';
            pinEl.innerHTML = `
                <img src="${user.avatar}" alt="${user.name}" class="avatar">
                <div class="pin-content">
                    <div class="message-header"><span class="message-author">${user.name}</span><span class="message-timestamp">${msg.timestamp}</span></div>
                    <div class="message-text-wrapper">${msg.content || '<em>Image</em>'}</div>
                </div>
                <button class="jump-button" data-message-id="${msgId}">Jump</button>`;
            elements.pinnedMessagesList.appendChild(pinEl);
        });
    };
    const togglePinsView = (forceState) => {
        const shouldBeVisible = forceState !== undefined ? forceState : !state.isPinsVisible;
        if (state.isPinsVisible === shouldBeVisible) return;

        state.isPinsVisible = shouldBeVisible;
        if (state.isPinsVisible && state.isMemberListVisible) {
            toggleMemberListView(false); // Hide member list if opening pins
        }
        elements.pinnedMessagesPane.classList.toggle('visible', state.isPinsVisible);
        elements.pinToggleButton.classList.toggle('active', state.isPinsVisible);
        if(state.isPinsVisible) renderPinnedMessages(state.currentChannel);
    };
    const toggleMemberListView = (forceState) => {
        const shouldBeVisible = forceState !== undefined ? forceState : !state.isMemberListVisible;
        if (state.isMemberListVisible === shouldBeVisible) return;

        state.isMemberListVisible = shouldBeVisible;
        if (state.isMemberListVisible && state.isPinsVisible) {
            togglePinsView(false); // Hide pins if opening member list
        }
        elements.mainContent.classList.toggle('member-list-hidden', !state.isMemberListVisible);
        elements.memberListToggle.classList.toggle('active', state.isMemberListVisible);
    }
    const jumpToMessage = (messageId) => {
        if(state.isPinsVisible) togglePinsView(false);
        const messageEl = $(`#chat-messages .message-group[data-message-id="${messageId}"]`);
        if (messageEl) {
            messageEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            messageEl.classList.add('highlight');
            setTimeout(() => messageEl.classList.remove('highlight'), 2000);
        } else {
            showNotification('Message not currently loaded. (This is a simplified simulation)', 'info');
        }
    };

    // --- Friend Management ---
    const sendFriendRequest = (username, fromProfile = false) => {
        const statusEl = elements.addFriendStatusEl;
        if (!fromProfile) statusEl.textContent = '';
        if (!username) { if (!fromProfile) { statusEl.textContent = 'Please enter a username.'; statusEl.className = 'add-friend-status error'; } return; }
        const targetUser = Object.values(appData.users).find(u => u.name.toLowerCase() === username.toLowerCase());
        if (!targetUser) { if (!fromProfile) { statusEl.textContent = 'Hmm, didn\'t work. Double check that the username is correct.'; statusEl.className = 'add-friend-status error'; } return; }
        if (targetUser.id === state.currentUser.id || state.currentUser.friends.includes(targetUser.id) || state.currentUser.sentRequests.includes(targetUser.id)) { if (!fromProfile) { statusEl.textContent = 'You are already friends or have a pending request with this user.'; statusEl.className = 'add-friend-status error'; } return; }

        const privacy = targetUser.settings?.privacy?.friendRequest || 'everyone';
        if (privacy !== 'everyone') {
            const mutualFriends = state.currentUser.friends.filter(fId => targetUser.friends.includes(fId));
            const mutualServers = appData.servers.filter(s => s.users.includes(state.currentUser.id) && s.users.includes(targetUser.id));
            if (privacy === 'friends_of_friends' && mutualFriends.length === 0) {
                 if (!fromProfile) { statusEl.textContent = 'This user only accepts friend requests from friends of friends.'; statusEl.className = 'add-friend-status error'; } return;
            }
            if (privacy === 'server_members' && mutualServers.length === 0) {
                if (!fromProfile) { statusEl.textContent = 'This user only accepts friend requests from people in the same server.'; statusEl.className = 'add-friend-status error'; } return;
            }
        }

        targetUser.pendingRequests.push(state.currentUser.id);
        state.currentUser.sentRequests.push(targetUser.id);
        saveData();
        const successMsg = `Success! Your friend request to ${targetUser.name} was sent.`;
        if (!fromProfile) { statusEl.textContent = successMsg; statusEl.className = 'add-friend-status success'; elements.addFriendInput.value = ''; }
        else { showNotification(successMsg, 'success'); if (state.activeModals.includes('user-profile-modal')) openUserProfile(targetUser.id); }
    };
    const removeFriend = (friendId) => { showConfirmationModal({ title: `Remove '${findUser(friendId).name}'`, text: 'Are you sure you want to remove this friend?', confirmText: 'Remove Friend', onConfirm: () => { state.currentUser.friends = state.currentUser.friends.filter(id => id !== friendId); const friend = findUser(friendId); if (friend) friend.friends = friend.friends.filter(id => id !== state.currentUser.id); saveData(); if (state.activeModals.includes('user-profile-modal')) closeModal(); renderFriendsList(); updateUI(); } }); };
    const blockUser = (friendId) => { showConfirmationModal({ title: `Block '${findUser(friendId).name}'`, text: 'Are you sure you want to block this user? You will not be able to send or receive messages.', confirmText: 'Block', onConfirm: () => { state.currentUser.friends = state.currentUser.friends.filter(id => id !== friendId); const friend = findUser(friendId); if (friend) friend.friends = friend.friends.filter(id => id !== state.currentUser.id); if (!state.currentUser.blocked.includes(friendId)) state.currentUser.blocked.push(friendId); saveData(); if (state.activeModals.includes('user-profile-modal')) closeModal(); renderFriendsList(); updateUI(); } }); };
    const unblockUser = (userId) => { state.currentUser.blocked = state.currentUser.blocked.filter(id => id !== userId); saveData(); if (state.activeModals.includes('user-profile-modal')) closeModal(); renderFriendsList(); updateUI(); };
    const acceptFriendRequest = (userId) => { state.currentUser.pendingRequests = state.currentUser.pendingRequests.filter(id => id !== userId); state.currentUser.friends.push(userId); const otherUser = findUser(userId); otherUser.sentRequests = otherUser.sentRequests.filter(id => id !== state.currentUser.id); otherUser.friends.push(state.currentUser.id); saveData(); renderFriendsList(); };
    const ignoreFriendRequest = (userId) => { state.currentUser.pendingRequests = state.currentUser.pendingRequests.filter(id => id !== userId); const otherUser = findUser(userId); otherUser.sentRequests = otherUser.sentRequests.filter(id => id !== state.currentUser.id); saveData(); renderFriendsList(); };
    const cancelFriendRequest = (userId) => {
        state.currentUser.sentRequests = state.currentUser.sentRequests.filter(id => id !== userId);
        const otherUser = findUser(userId);
        if (otherUser) {
            otherUser.pendingRequests = otherUser.pendingRequests.filter(id => id !== state.currentUser.id);
        }
        saveData();
        renderFriendsList();
        if (state.activeModals.includes('user-profile-modal')) {
            openUserProfile(userId);
        }
    };

    // --- Server & Channel Management ---
    const createServer = (name) => { const newServerId = `server${Date.now()}`, newChannelId = `c${Date.now()}`; const newServer = { id: newServerId, name, icon: `https://i.pravatar.cc/64?u=${newServerId}`, channels: [{ category: 'Text Channels', items: [{ id: newChannelId, name: 'general', type: 'text', topic: `Welcome to ${name}!`, pins: [] }] }], users: [state.currentUser.id], roles: [], userRoles: {} }; appData.servers.push(newServer); appData.messages[newChannelId] = [{ id: `m${Date.now()}`, userId: state.currentUser.id, content: `Welcome to #${name}!`, timestamp: 'Just now', reactions:[] }]; saveData(); state.currentServer = newServerId; state.currentChannel = newChannelId; showMainContent(); updateUI(); closeModal(); };
    const joinServer = (serverId) => {
        const server = findServerById(serverId);
        if (server && !server.users.includes(state.currentUser.id)) {
            server.users.push(state.currentUser.id);
            saveData();
            state.currentServer = serverId;
            state.currentChannel = server.channels[0].items[0].id;
            showMainContent();
            updateUI();
            return { success: true, message: `Successfully joined ${server.name}!` };
        } else if (server) {
            return { success: false, message: "You are already a member of this server." };
        } else {
            return { success: false, message: "The invite is invalid or has expired." };
        }
    };
    const createChannel = (name) => { const server = findServerById(state.currentServer); if (!server || !name) return; const newChannelId = `c${Date.now()}`; server.channels.find(c => c.category === 'Text Channels').items.push({ id: newChannelId, name, type: 'text', topic: '', pins: [] }); appData.messages[newChannelId] = []; saveData(); state.currentChannel = newChannelId; updateUI(); closeModal(); };
    const leaveServer = () => {
        const server = findServerById(state.currentServer);
        if (server && server.users.includes(state.currentUser.id)) {
            showConfirmationModal({
                title: `Leave '${server.name}'`,
                text: "Are you sure you want to leave this server? You won't be able to rejoin unless you are re-invited.",
                confirmText: "Leave Server",
                onConfirm: () => {
                    server.users = server.users.filter(uid => uid !== state.currentUser.id);
                    saveData();
                    const nextServer = appData.servers.find(s => s.users.includes(state.currentUser.id));
                    state.currentServer = nextServer?.id || null;
                    if (state.currentServer) {
                        state.currentChannel = nextServer.channels[0].items[0].id;
                        showMainContent();
                        updateUI();
                    } else {
                        showDmContent();
                    }
                }
            });
        }
    };

    // --- Profile & Settings ---
    const openUserProfile = (userId) => {
        const user = findUser(userId);
        if (!user) return;
        
        // If the profile for this user is already the top modal, do nothing.
        const currentTopModal = state.activeModals[state.activeModals.length - 1];
        if (currentTopModal === 'user-profile-modal' && $('#profile-note-input').dataset.userId === userId) {
            return;
        }

        $$('.profile-tabs .tab-button').forEach(btn => btn.classList.remove('active'));
        $('.profile-tabs .tab-button[data-tab="about"]').classList.add('active');
        $$('.profile-tab-content').forEach(pane => pane.classList.add('hidden'));
        $('#profile-tab-about').classList.remove('hidden');

        $('#profile-modal-banner').style.backgroundColor = user.bannerColor || '#7289da';
        $('#profile-modal-avatar').src = user.avatar.replace('40', '92');
        $('#profile-modal-username').textContent = user.name;
        $('#profile-modal-about').textContent = user.about || 'This user is mysterious...';
        $('#profile-modal-member-since').textContent = new Date(user.memberSince).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        $('#profile-modal-badges').innerHTML = user.hasNitro ? `<i class="fa-solid fa-gem nitro-badge" data-tooltip="Nitro Subscriber"></i>` : '';
        
        const note = state.currentUser.notes?.[userId] || '';
        $('#profile-note-input').value = note;
        $('#profile-note-input').dataset.userId = userId;

        const actionsContainer = elements.profileModalActions;
        actionsContainer.innerHTML = '';
        if (userId !== state.currentUser.id) {
            if (state.currentUser.friends.includes(userId)) {
                actionsContainer.innerHTML = `<button class="message-btn" data-user-id="${userId}">Message</button>`;
            } else if (state.currentUser.blocked.includes(userId)) {
            } else if (state.currentUser.sentRequests.includes(userId)) {
                 actionsContainer.innerHTML = `<button class="add-friend-btn" disabled>Friend Request Sent</button>`;
            } else if (state.currentUser.pendingRequests.includes(userId)) {
                 actionsContainer.innerHTML = `<button class="modal-button small" data-action="accept-request" data-user-id="${userId}">Accept Request</button>`;
            } else {
                actionsContainer.innerHTML = `<button class="add-friend-btn" data-user-id="${userId}">Add Friend</button>`;
            }
            actionsContainer.innerHTML += `<button class="more-btn" data-user-id="${userId}" data-action="profile-more"><i class="fa-solid fa-ellipsis-h"></i></button>`;
        }

        const mutualFriends = state.currentUser.friends.filter(fId => user.friends?.includes(fId) && findUser(fId));
        const mutualServers = appData.servers.filter(s => s.users.includes(state.currentUser.id) && s.users.includes(userId));

        $('#mutual-friends-count').textContent = mutualFriends.length;
        $('#mutual-servers-count').textContent = mutualServers.length;

        $('#profile-mutual-friends').innerHTML = mutualFriends.length > 0
            ? mutualFriends.map(id => `<div class="mutual-item"><img src="${findUser(id).avatar}" class="avatar"><span>${findUser(id).name}</span></div>`).join('')
            : '<p class="text-muted">No mutual friends.</p>';

        $('#profile-mutual-servers').innerHTML = mutualServers.length > 0
            ? mutualServers.map(s => `<div class="mutual-item"><img src="${s.icon}" class="server-icon"><span>${s.name}</span></div>`).join('')
            : '<p class="text-muted">No mutual servers.</p>';

        openModal('user-profile-modal');
    };
    const saveProfileSettings = () => { const user = state.currentUser; user.about = $('#profile-about-me-input').value; user.bannerColor = $('#profile-banner-color-input').value; saveData(); showNotification('Profile saved!', 'success'); closeModal(); };
    const saveServerSettings = () => { const server = findServerById(state.currentServer); if (!server) return; server.name = $('#server-settings-name-input').value; saveData(); showNotification('Server settings saved!', 'success'); closeModal(); updateUI(); };

    // --- Server Settings ---
    const renderServerRolesSettings = () => {
        const server = findServerById(state.currentServer);
        const rolesList = $('#server-roles-list'); rolesList.innerHTML = '';
        (server.roles || []).forEach(role => {
            const item = document.createElement('li'); item.className = 'settings-list-item';
            item.innerHTML = `<div class="role-swatch" style="background-color: ${role.color};"></div><span>${role.name}</span><div class="actions"><i class="fa-solid fa-pen" data-role-id="${role.id}" data-action="edit"></i><i class="fa-solid fa-trash" data-role-id="${role.id}" data-action="delete"></i></div>`;
            rolesList.appendChild(item);
        });
    };
    const renderServerChannelsSettings = () => {
        const server = findServerById(state.currentServer);
        const channelsList = $('#server-channels-list'); channelsList.innerHTML = '';
        server.channels.forEach(cat => cat.items.forEach(ch => {
            const item = document.createElement('li'); item.className = 'settings-list-item';
            item.innerHTML = `<i class="fa-solid ${ch.type === 'text' ? 'fa-hashtag' : 'fa-volume-high'} channel-icon"></i><input type="text" value="${ch.name}" readonly data-channel-id="${ch.id}"><div class="actions"><i class="fa-solid fa-pen" data-channel-id="${ch.id}"></i><i class="fa-solid fa-trash" data-channel-id="${ch.id}"></i></div>`;
            channelsList.appendChild(item);
        }));
    };
    const createServerRole = () => {
        showPromptModal({
            title: 'Create Role',
            text: 'Enter a name for your new role.',
            label: 'ROLE NAME',
            onConfirm: (name) => {
                if (!name) return;
                const server = findServerById(state.currentServer);
                if (server) {
                    if (!server.roles) server.roles = [];
                    server.roles.push({ id: `r${Date.now()}`, name, color: '#99aab5' });
                    saveData();
                    renderServerRolesSettings();
                }
            }
        });
    };
    const editServerRole = (roleId) => {
        const server = findServerById(state.currentServer);
        const role = server.roles.find(r => r.id === roleId);
        if (!role) return;

        showPromptModal({
            title: 'Edit Role Name',
            text: `Enter a new name for the role "${role.name}".`,
            label: 'ROLE NAME',
            initialValue: role.name,
            onConfirm: (newName) => {
                if (newName) role.name = newName;
                showPromptModal({
                    title: 'Edit Role Color',
                    text: 'Enter a new hex color code for the role.',
                    label: 'HEX COLOR (e.g., #ff4b50)',
                    initialValue: role.color,
                    onConfirm: (newColor) => {
                        if (newColor && /^#[0-9A-F]{6}$/i.test(newColor)) {
                            role.color = newColor;
                        } else if (newColor) {
                            showNotification('Invalid hex color format. Color was not updated.', 'error');
                        }
                        saveData();
                        renderServerRolesSettings();
                    }
                });
            }
        });
    };
    const deleteServerRole = (roleId) => { showConfirmationModal({ title: 'Delete Role', text: 'Are you sure you want to delete this role?', onConfirm: () => { const server = findServerById(state.currentServer); server.roles = server.roles.filter(r => r.id !== roleId); saveData(); renderServerRolesSettings(); } }); };
    const deleteServerChannel = (channelId) => { showConfirmationModal({ title: 'Delete Channel', text: 'Are you sure you want to delete this channel? This cannot be undone.', onConfirm: () => { const server = findServerById(state.currentServer); server.channels.forEach(c => c.items = c.items.filter(i => i.id !== channelId)); if (state.currentChannel === channelId) { const firstChannel = server.channels.find(c=>c.items.length > 0)?.items[0]; state.currentChannel = firstChannel?.id || null; } saveData(); updateUI(); renderServerChannelsSettings(); } }); };
    const editServerChannel = (inputEl, channelId) => { inputEl.readOnly = false; inputEl.focus(); const save = () => { inputEl.readOnly = true; const channel = findChannelById(channelId); if(channel) channel.name = inputEl.value; saveData(); updateUI(); renderServerChannelsSettings(); inputEl.removeEventListener('blur', save); inputEl.removeEventListener('keydown', onKey); }; const onKey = (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } }; inputEl.addEventListener('blur', save); inputEl.addEventListener('keydown', onKey);};

    // ======== EVENT HANDLERS ========
    const handleGlobalClick = (e) => {
        if (state.activeDropdown.id && !e.target.closest('.dropdown-menu') && !e.target.closest('[data-tooltip="More"]') && !e.target.closest('[data-action="profile-more"]') && !e.target.closest('.server-header')) closeAllDropdowns();
        if ((!elements.reactionPicker.classList.contains('hidden') && !e.target.closest('.reaction-picker') && !e.target.closest('[data-action="add_reaction"]')) || (!elements.emojiPicker.classList.contains('hidden') && !e.target.closest('#emoji-picker') && !e.target.closest('#emoji-button')) || (!elements.dmEmojiPicker?.classList.contains('hidden') && !e.target.closest('#dm-emoji-picker') && !e.target.closest('#dm-emoji-button'))) closeAllDropdowns();
        const userId = e.target.closest('[data-user-id]')?.dataset.userId;
        if (userId && !e.target.closest('#user-panel-avatar-wrapper, #dm-panel-avatar-wrapper, .message-actions, .message-reactions, .friend-actions, .mutual-item, #create-group-dm-friends-list, #profile-modal-actions')) { openUserProfile(userId); }
    };
    const handleFriendsListClick = (e) => {
        const friendItem = e.target.closest('.friend-list-item');
        if (!friendItem) return;
        const friendId = friendItem.dataset.friendId;
        
        if (e.target.closest('.fa-message')) { showDmContent(); renderDmChat(findOrCreateDmWithUser(friendId)); }
        else if (e.target.closest('.fa-ellipsis-vertical')) { toggleDropdown('friend-actions-dropdown', e.target, { friendId }); }
        else if (e.target.closest('.accept-btn')) { acceptFriendRequest(friendId); }
        else if (e.target.closest('.danger-btn')) { if (state.activeFriendsTab === 'pending') ignoreFriendRequest(friendId); }
        else if (e.target.closest('.unblock-btn')) { if (state.activeFriendsTab === 'blocked') unblockUser(friendId); }
    };
    const handleMessageContainerClick = (e, channelId) => {
        const messageGroup = e.target.closest('.message-group');
        if (!messageGroup) return;
        const messageId = messageGroup.dataset.messageId;
        const action = e.target.dataset.action || e.target.closest('[data-action]')?.dataset.action;

        if(action) e.stopPropagation();

        switch(action) {
            case 'add_reaction':
                showReactionPicker(e.target, messageId, channelId);
                break;
            case 'reply':
                startReply(messageId, channelId);
                break;
            case 'more':
                const isPinned = findChannelById(channelId)?.pins?.includes(messageId);
                const pinText = isPinned ? 'Unpin Message' : 'Pin Message';
                $('#message-actions-dropdown [data-action="pin"]').innerHTML = `<i class="fa-solid fa-thumbtack"></i> ${pinText}`;
                const isOwnMessage = messageGroup.dataset.userId === state.currentUser.id;
                $('#message-actions-dropdown [data-action="edit"]').style.display = isOwnMessage ? 'flex' : 'none';
                $('#message-actions-dropdown [data-action="delete"]').style.display = isOwnMessage ? 'flex' : 'none';
                toggleDropdown('message-actions-dropdown', e.target, { messageId, channelId });
                break;
        }

        if (e.target.closest('.reaction-btn')) toggleReaction(messageId, e.target.closest('.reaction-btn').dataset.emoji, channelId);
    };

    // ======== APP INITIALIZATION ========
    const initAuth = () => {
        elements.showLoginLink.addEventListener('click', (e) => { e.preventDefault(); showLoginForm(); });
        elements.showRegisterLink.addEventListener('click', (e) => { e.preventDefault(); showRegisterForm(); });
        elements.loginForm.addEventListener('submit', handleLogin);
        elements.registerForm.addEventListener('submit', handleRegister);
    };

    const initApp = () => {
        // Populate User Info & Initial State
        const ensureDataIntegrity = (user) => {
            if (!user.sentRequests) user.sentRequests = [];
            if (!user.settings) user.settings = { privacy: { friendRequest: 'everyone', allowDmsFromServers: true } };
            if (!user.voiceSettings) user.voiceSettings = { inputDevice: 'Default', outputDevice: 'Default', inputVolume: 100, outputVolume: 100 };
            if (!user.friends) user.friends = [];
            if (!user.pendingRequests) user.pendingRequests = [];
            if (!user.blocked) user.blocked = [];
            if (!user.notes) user.notes = {};
        };
        Object.values(appData.users).forEach(ensureDataIntegrity);
        updateCurrentUserUI();
        elements.memberListToggle.classList.add('active');

        // Event Listeners
        document.addEventListener('click', handleGlobalClick);
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeModal(); closeAllDropdowns(); cancelMessageEdit(); cancelReply(); }});
        elements.serverList.addEventListener('click', (e) => { const serverIcon = e.target.closest('.server-icon:not(.action-icon)'); if (serverIcon?.dataset.serverId) { state.currentServer = serverIcon.dataset.serverId; const server = findServerById(state.currentServer); state.currentChannel = server?.channels[0]?.items[0]?.id; togglePinsView(false); showMainContent(); updateUI(); } });
        elements.channelList.addEventListener('click', (e) => { const channelItem = e.target.closest('.channel'); if (channelItem?.dataset.channelId) { state.currentChannel = channelItem.dataset.channelId; togglePinsView(false); updateUI(); } });
        elements.messageInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addMessage(elements.messageInput.value, null, state.currentChannel); elements.messageInput.value = ''; } });
        elements.dmMessageInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addMessage(elements.dmMessageInput.value, null, state.currentOpenDm); elements.dmMessageInput.value = ''; } });
        elements.chatMessages.addEventListener('click', (e) => handleMessageContainerClick(e, state.currentChannel));
        elements.dmChatMessages.addEventListener('click', (e) => handleMessageContainerClick(e, state.currentOpenDm));
        elements.homeButton.addEventListener('click', showDmContent);
        elements.serverHeader.addEventListener('click', (e) => toggleDropdown('server-dropdown', e.currentTarget));
        elements.memberListToggle.addEventListener('click', () => toggleMemberListView());
        elements.dmNavLinks.addEventListener('click', (e) => { const target = e.target.closest('.channel'); if (target) { $$('#dm-nav-links .channel').forEach(el => el.classList.remove('active')); target.classList.add('active'); $$('#friends-tabs a').forEach(tab => tab.classList.remove('active')); if(target.dataset.view === 'friends') { $('#friends-tabs a[data-tab="online"]').classList.add('active'); } switchDmView(target.dataset.view); }});
        elements.friendsTabs.addEventListener('click', (e) => { e.preventDefault(); const target = e.target; if (target.tagName === 'A') { $$('#friends-tabs a').forEach(tab => tab.classList.remove('active')); target.classList.add('active'); state.activeFriendsTab = target.dataset.tab; renderFriendsList(); }});
        elements.addFriendButton.addEventListener('click', () => switchDmView('add-friend'));
        elements.sendFriendRequestBtn.addEventListener('click', () => sendFriendRequest(elements.addFriendInput.value));
        elements.dmList.addEventListener('click', (e) => { const target = e.target.closest('.channel'); if (target?.dataset.dmId) renderDmChat(target.dataset.dmId); });
        elements.friendsListContainer.addEventListener('click', handleFriendsListClick);
        elements.backToFriendsList.addEventListener('click', (e) => { e.preventDefault(); switchDmView('friends'); });
        
        // Server Chat Input Actions
        elements.uploadButton.addEventListener('click', () => elements.imageUploadInput.click());
        elements.imageUploadInput.addEventListener('change', (e) => { const file = e.target.files[0]; if (file?.type.startsWith('image/')) { const reader = new FileReader(); reader.onload = (event) => addMessage('', event.target.result, state.currentOpenDm || state.currentChannel); reader.readAsDataURL(file); } e.target.value = ''; });
        elements.emojiButton.addEventListener('click', (e) => { e.stopPropagation(); elements.emojiPicker.classList.toggle('hidden'); });
        elements.gifButton.addEventListener('click', () => { $('#gif-picker-grid').innerHTML = GIF_URLS.map(url => `<img src="${url}" alt="gif">`).join(''); openModal('gif-picker-modal'); });

        // DM Chat Input Actions
        elements.dmUploadButton.addEventListener('click', () => elements.dmImageUploadInput.click());
        elements.dmImageUploadInput.addEventListener('change', (e) => { const file = e.target.files[0]; if (file?.type.startsWith('image/')) { const reader = new FileReader(); reader.onload = (event) => addMessage('', event.target.result, state.currentOpenDm); reader.readAsDataURL(file); } e.target.value = ''; });
        elements.dmEmojiButton.addEventListener('click', (e) => { e.stopPropagation(); elements.dmEmojiPicker.classList.toggle('hidden'); });
        elements.dmGifButton.addEventListener('click', () => { $('#gif-picker-grid').innerHTML = GIF_URLS.map(url => `<img src="${url}" alt="gif">`).join(''); openModal('gif-picker-modal'); });
        
        elements.reactionPicker.addEventListener('click', (e) => { if (e.target.tagName !== 'SPAN') return; const picker = e.currentTarget; toggleReaction(picker.dataset.messageId, e.target.textContent, picker.dataset.channelId); closeAllDropdowns(); });
        elements.chatSearchInput.addEventListener('keyup', (e) => { const q = e.target.value.toLowerCase(); $$('#chat-messages .message-group').forEach(m => { const txt = m.textContent.toLowerCase(); m.classList.toggle('dimmed', q && !txt.includes(q)); }); });
        elements.cancelReplyBtn.addEventListener('click', cancelReply);
        elements.dmCancelReplyBtn?.addEventListener('click', cancelReply);
        
        // Modals & Dropdowns
        // FIX: The generic close button handler now correctly closes the top-most modal.
        $$('.modal-close-button, #modal-backdrop').forEach(btn => btn.addEventListener('click', closeModal));
        elements.addServerButton.addEventListener('click', () => openModal('add-server-modal'));
        $('#create-server-option').addEventListener('click', () => { closeModal(); openModal('create-server-form-modal'); });
        $('#create-server-form').addEventListener('submit', (e) => { e.preventDefault(); createServer($('#server-name-input').value); });
        $('#join-server-button').addEventListener('click', () => { closeModal(); openModal('join-server-modal'); });
        $('#join-server-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const inputEl = $('#join-server-input');
            const errorEl = $('#join-server-error');
            const inviteCode = inputEl.value.trim();
            
            errorEl.textContent = '';
            if (!inviteCode) { errorEl.textContent = 'Please enter an invite.'; return; }
            
            const serverId = inviteCode.split('/').pop();
            const result = joinServer(serverId);
            
            if (result.success) {
                showNotification(result.message, 'success');
                closeModal();
                inputEl.value = '';
            } else {
                errorEl.textContent = result.message;
            }
        });
        $('#join-server-cancel-btn').addEventListener('click', closeModal);
        $('#invite-people-btn').addEventListener('click', () => { openModal('invite-people-modal'); closeAllDropdowns(); });
        $('#copy-invite-link-btn').addEventListener('click', (e) => { navigator.clipboard.writeText($('#invite-link-input').value); e.target.textContent = 'Copied!'; setTimeout(() => e.target.textContent = 'Copy', 2000); });
        $('#create-channel-btn').addEventListener('click', () => { openModal('create-channel-modal'); closeAllDropdowns(); });
        $('#create-channel-form').addEventListener('submit', (e) => { e.preventDefault(); createChannel($('#channel-name-input').value); });
        $('#leave-server-btn').addEventListener('click', () => { leaveServer(); closeAllDropdowns(); });
        
        elements.friendActionsDropdown.addEventListener('click', e => {
            if (!state.activeDropdown.context) return;
            const { friendId } = state.activeDropdown.context;
            const actionNode = e.target.closest('li');
            if (!actionNode) return;

            switch(actionNode.id) {
                case 'start-dm-btn': showDmContent(); renderDmChat(findOrCreateDmWithUser(friendId)); break;
                case 'remove-friend-btn': removeFriend(friendId); break;
                case 'block-user-btn': blockUser(friendId); break;
            }
            closeAllDropdowns();
        });

        elements.messageActionsDropdown.addEventListener('click', e => {
            if(!state.activeDropdown.context) return;
            const { messageId, channelId } = state.activeDropdown.context;
            const action = e.target.closest('li')?.dataset.action;
            const message = findMessageById(channelId, messageId);
            if (!message) return;

            switch(action) {
                case 'reply': startReply(messageId, channelId); break;
                case 'edit': startEditingMessage(messageId, channelId); break;
                case 'pin': togglePinMessage(messageId, channelId); break;
                case 'mention': const user = findUser(message.userId); if(user) (state.currentOpenDm ? elements.dmMessageInput : elements.messageInput).value += `@${user.name} `; break;
                case 'delete': deleteMessage(messageId, channelId); break;
            }
            closeAllDropdowns();
        });
        elements.exploreServersButton.addEventListener('click', () => { $('#explore-server-list').innerHTML = appData.servers.filter(s => !s.users.includes(state.currentUser.id)).map(s => `<div class="modal-option" data-server-id="${s.id}"><div><img src="${s.icon}"> <div class="server-info"><h3>${s.name}</h3> <p>${s.users.length} Members</p></div></div><button class="add-friend-btn">Join</button></div>`).join('') || '<p>No other servers to join.</p>'; openModal('explore-servers-modal'); });
        $('#explore-server-list').addEventListener('click', (e) => { 
            if (e.target.tagName === 'BUTTON') {
                const result = joinServer(e.target.closest('.modal-option').dataset.serverId);
                showNotification(result.message, result.success ? 'success' : 'error');
                if (result.success) closeModal();
            }
        });

        // Pins View
        elements.pinToggleButton.addEventListener('click', () => togglePinsView());
        elements.closePinsBtn.addEventListener('click', () => togglePinsView(false));
        elements.pinnedMessagesList.addEventListener('click', (e) => { const jumpBtn = e.target.closest('.jump-button'); if(jumpBtn) jumpToMessage(jumpBtn.dataset.messageId); });

        // Settings, Toggles, and other features
        [elements.userPanelAvatarWrapper, elements.dmPanelAvatarWrapper].forEach(btn => btn.addEventListener('click', () => openUserProfile(state.currentUser.id)));
        [elements.settingsButton, elements.settingsButtonDm].forEach(btn => btn.addEventListener('click', () => openModal('user-settings-modal')));
        $('#logout-button').addEventListener('click', handleLogout);
        [elements.muteToggle, elements.muteToggleDm].forEach(btn => btn.addEventListener('click', () => { state.isMuted = !state.isMuted; $$('#mute-toggle, #mute-toggle-dm').forEach(el => { el.classList.toggle('active', state.isMuted); el.querySelector('i').className = `fa-solid ${state.isMuted ? 'fa-microphone-slash' : 'fa-microphone'}`; }); }));
        [elements.deafenToggle, elements.deafenToggleDm].forEach(btn => btn.addEventListener('click', () => { state.isDeafened = !state.isDeafened; $$('#deafen-toggle, #deafen-toggle-dm').forEach(el => el.classList.toggle('active', state.isDeafened)); }));
        $('#user-settings-nav').addEventListener('click', e => { e.preventDefault(); const target = e.target.closest('a'); if(target) { $$('#user-settings-nav a').forEach(a => a.classList.remove('active')); target.classList.add('active'); $$('#user-settings-modal .settings-pane').forEach(p => p.classList.add('hidden')); $(`#${target.dataset.tab}-settings`).classList.remove('hidden'); } });
        $('#save-profile-settings-btn').addEventListener('click', saveProfileSettings);
        elements.serverSettingsBtn.addEventListener('click', () => { openModal('server-settings-modal'); closeAllDropdowns(); });
        $('#save-server-settings-btn').addEventListener('click', saveServerSettings);
        
        $('#gif-picker-modal').addEventListener('click', (e) => {
            if (e.target.tagName === 'IMG') {
                e.stopPropagation();
                addMessage('', e.target.src, state.currentOpenDm || state.currentChannel);
                closeModal();
            }
        });
        $$('.nitro-subscribe-btn').forEach(btn => btn.addEventListener('click', () => { showConfirmationModal({ title: 'Subscribe to Nitro?', text: 'This is a simulation. Subscribing will grant you a cosmetic Nitro badge for $9.99/month.', confirmText: 'Subscribe', confirmClass: 'boost', onConfirm: () => { state.currentUser.hasNitro = true; saveData(); showNotification("Thanks for subscribing to Nitro!", 'success'); closeModal(); switchDmView('friends'); } })}));
        $$('#gift-button, #dm-gift-button').forEach(btn => btn.addEventListener('click', () => showNotification("Gifting is not available in this simulation.", 'info')));
        $$('#dm-call-btn, #dm-video-btn').forEach(btn => btn.addEventListener('click', (e) => showNotification(`Starting simulated call with ${elements.dmChatUsername.textContent}...`, 'info')));
        
        elements.emojiPicker.innerHTML = ALL_EMOJIS.map(e => `<span>${e}</span>`).join('');
        elements.emojiPicker.addEventListener('click', e => { if (e.target.tagName === 'SPAN') { elements.messageInput.value += e.target.textContent; elements.emojiPicker.classList.add('hidden'); elements.messageInput.focus(); } });
        elements.dmEmojiPicker.innerHTML = ALL_EMOJIS.map(e => `<span>${e}</span>`).join('');
        elements.dmEmojiPicker.addEventListener('click', e => { if (e.target.tagName === 'SPAN') { elements.dmMessageInput.value += e.target.textContent; elements.dmEmojiPicker.classList.add('hidden'); elements.dmMessageInput.focus(); } });

        // User Settings Actions
        $('.theme-options').addEventListener('click', e => { const themeOption = e.target.closest('.theme-option'); if(themeOption) { state.currentTheme = themeOption.dataset.theme; document.documentElement.setAttribute('data-theme', state.currentTheme); localStorage.setItem('theme', state.currentTheme); updateThemeSettingsUI(); }});
        $('#message-display-setting').addEventListener('change', e => { document.body.dataset.messageDisplay = e.target.value; const channelId = state.currentOpenDm || state.currentChannel; channelId?.startsWith('dm') ? renderDmChat(channelId) : renderCurrentChannel(); });
        $('#friend-request-setting').addEventListener('change', e => { state.currentUser.settings.privacy.friendRequest = e.target.value; saveData(); });
        $('#dm-privacy-toggle').addEventListener('change', e => { state.currentUser.settings.privacy.allowDmsFromServers = e.target.checked; saveData(); });
        elements.editUsernameBtn.addEventListener('click', () => {
            showPromptModal({
                title: 'Change your username',
                text: 'Enter a new username. Note that this is a simulation and might not check for duplicates like the real thing!',
                label: 'USERNAME',
                initialValue: state.currentUser.name,
                onConfirm: (newName) => {
                    if (newName && newName.length > 2) {
                        state.currentUser.name = newName;
                        saveData();
                        updateCurrentUserUI();
                        loadUserSettings();
                        showNotification("Username updated!", "success");
                    } else if (newName) {
                        showNotification("Username must be longer than 2 characters.", "error");
                    }
                }
            });
        });
        $('#change-avatar-btn').addEventListener('click', () => { const newAvatar = `https://i.pravatar.cc/40?u=${Date.now()}`; state.currentUser.avatar = newAvatar; saveData(); updateCurrentUserUI(); showNotification('Avatar updated!', 'success'); });
        $('#change-password-btn').addEventListener('click', () => { showPromptModal({ title: "Change Password", text: "Enter a new password. For security, you should use a password manager!", label: "NEW PASSWORD", onConfirm: (newPass) => { if(newPass) {state.currentUser.password = newPass; saveData(); showNotification('Password changed!', 'success');} }})});
        $('#voice-settings').addEventListener('change', e => {
            const el = e.target;
            const settingKeyMap = { 'voice-input-device': 'inputDevice', 'voice-output-device': 'outputDevice', 'voice-input-volume': 'inputVolume', 'voice-output-volume': 'outputVolume' };
            const key = settingKeyMap[el.id];
            if (key) { state.currentUser.voiceSettings[key] = el.value; saveData(); }
        });
        
        elements.profileModalActions.addEventListener('click', e => {
            const button = e.target.closest('button');
            if (!button) return;

            const userId = button.dataset.userId;
            const user = findUser(userId);

            if (button.classList.contains('message-btn')) {
                closeModal();
                showDmContent();
                renderDmChat(findOrCreateDmWithUser(userId));
            } else if (button.classList.contains('add-friend-btn')) {
                sendFriendRequest(user.name, true);
            } else if (button.classList.contains('more-btn')) {
                const dropdownUl = $('#profile-actions-dropdown ul');
                let dropdownHtml = '';
                if (state.currentUser.friends.includes(userId)) {
                    dropdownHtml += `<li data-action="remove-friend" data-user-id="${userId}" class="danger"><i class="fa-solid fa-user-minus"></i> Remove Friend</li>`;
                } else if (state.currentUser.sentRequests.includes(userId)) {
                     dropdownHtml += `<li data-action="cancel-request" data-user-id="${userId}" class="danger"><i class="fa-solid fa-times-circle"></i> Cancel Request</li>`;
                } else if(state.currentUser.pendingRequests.includes(userId)) {
                    dropdownHtml += `<li data-action="accept-request" data-user-id="${userId}" class="success"><i class="fa-solid fa-user-plus"></i> Accept Request</li>`;
                    dropdownHtml += `<li data-action="ignore-request" data-user-id="${userId}" class="danger"><i class="fa-solid fa-user-times"></i> Ignore Request</li>`;
                }
                
                if (state.currentUser.blocked.includes(userId)) {
                    if (dropdownHtml) dropdownHtml += `<hr>`;
                    dropdownHtml += `<li data-action="unblock-user" data-user-id="${userId}"><i class="fa-solid fa-check-circle"></i> Unblock</li>`;
                } else {
                    if (dropdownHtml) dropdownHtml += `<hr>`;
                    dropdownHtml += `<li data-action="block-user" data-user-id="${userId}" class="danger"><i class="fa-solid fa-ban"></i> Block User</li>`;
                }
                dropdownUl.innerHTML = dropdownHtml;
                toggleDropdown('profile-actions-dropdown', button, { userId });
            }
        });

        elements.profileActionsDropdown.addEventListener('click', e => {
            const actionItem = e.target.closest('li[data-action]');
            if (!actionItem) return;

            const action = actionItem.dataset.action;
            const userId = actionItem.dataset.userId;
            closeAllDropdowns();

            switch(action) {
                case 'remove-friend': removeFriend(userId); break;
                case 'block-user': blockUser(userId); break;
                case 'unblock-user': unblockUser(userId); break;
                case 'cancel-request': cancelFriendRequest(userId); break;
                case 'accept-request': acceptFriendRequest(userId); break;
                case 'ignore-request': ignoreFriendRequest(userId); break;
            }
            
            if (state.activeModals.includes('user-profile-modal')) {
                openUserProfile(userId);
            }
        });


        $('#profile-note-input').addEventListener('blur', e => {
            const userId = e.target.dataset.userId;
            const noteText = e.target.value;
            if (!state.currentUser.notes) state.currentUser.notes = {};
            state.currentUser.notes[userId] = noteText;
            saveData();
        });

        // Server Settings Navigation & Actions
        elements.serverSettingsNav.addEventListener('click', e => { e.preventDefault(); const target = e.target.closest('a'); if (target) { $$('#server-settings-nav a').forEach(a => a.classList.remove('active')); target.classList.add('active'); $$('#server-settings-modal .settings-pane').forEach(p => p.classList.add('hidden')); $(`#server-${target.dataset.tab}-settings`).classList.remove('hidden'); if(target.dataset.tab === 'roles') renderServerRolesSettings(); if(target.dataset.tab === 'channels') renderServerChannelsSettings(); } });
        $('#create-role-btn').addEventListener('click', createServerRole);
        $('#server-roles-list').addEventListener('click', e => { const target = e.target.closest('i[data-role-id]'); if(!target) return; const roleId = target.dataset.roleId; const action = target.dataset.action; if (action === 'delete') deleteServerRole(roleId); if(action === 'edit') editServerRole(roleId); });
        $('#server-channels-list').addEventListener('click', e => { const target = e.target; const channelId = target.dataset.channelId; if (!channelId) return; if (target.classList.contains('fa-trash')) deleteServerChannel(channelId); if (target.classList.contains('fa-pen')) editServerChannel(target.closest('.settings-list-item').querySelector('input'), channelId); });

        // DM Creation Modals
        elements.findConvoBtn.addEventListener('click', () => {
             const friendsListEl = $('#create-dm-friends-list');
             friendsListEl.innerHTML = '';
             state.currentUser.friends.forEach(friendId => {
                 const user = findUser(friendId);
                 if (!user) return;
                 const item = document.createElement('div');
                 item.className = 'dm-friend-item';
                 item.dataset.userId = user.id;
                 item.innerHTML = `<img src="${user.avatar}" alt="${user.name}" class="avatar"><span>${user.name}</span>`;
                 item.onclick = () => { closeModal(); renderDmChat(findOrCreateDmWithUser(user.id)); };
                 friendsListEl.appendChild(item);
             });
             openModal('find-convo-modal');
        });
        elements.findConvoInput.addEventListener('keyup', e => {
            const query = e.target.value.toLowerCase();
            $$('#create-dm-friends-list .dm-friend-item').forEach(item => {
                const username = item.querySelector('span').textContent.toLowerCase();
                item.style.display = username.includes(query) ? 'flex' : 'none';
            });
        });
        elements.createDmBtn.addEventListener('click', () => {
            const friendsListEl = $('#create-group-dm-friends-list');
            friendsListEl.innerHTML = '';
            state.currentUser.friends.forEach(friendId => {
                 const user = findUser(friendId);
                 if (!user) return;
                 const item = document.createElement('label');
                 item.className = 'dm-friend-item';
                 item.innerHTML = `<img src="${user.avatar}" alt="${user.name}" class="avatar"><span>${user.name}</span><input type="checkbox" data-user-id="${user.id}">`;
                 friendsListEl.appendChild(item);
            });
            openModal('create-group-dm-modal');
        });
        $('#create-group-dm-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const selectedUsers = [state.currentUser.id, ...Array.from($$('#create-group-dm-friends-list input:checked')).map(cb => cb.dataset.userId)];
            if(selectedUsers.length < 2) { showNotification("Please select at least one friend.", "error"); return; }
            const groupName = $('#group-dm-name-input').value.trim() || selectedUsers.slice(1).map(id => findUser(id).name).join(', ').substring(0, 50);
            const newDm = { id: `dm${Date.now()}`, name: groupName, participants: selectedUsers, messages: [] };
            appData.dms.push(newDm);
            saveData();
            closeModal();
            renderDmChat(newDm.id);
        });

        // Final UI setup
        const firstValidServer = appData.servers.find(s => s.users.includes(state.currentUser.id));
        if (state.currentServer && findServerById(state.currentServer)?.users.includes(state.currentUser.id)) { showMainContent(); }
        else if (firstValidServer) { state.currentServer = firstValidServer.id; state.currentChannel = firstValidServer.channels[0].items[0].id; showMainContent(); }
        else { showDmContent(); }
        updateUI();
    };

    // ======== APPLICATION START ========
    const updateThemeSettingsUI = () => {
        $$('.theme-option').forEach(el => el.classList.remove('active'));
        $(`.theme-option[data-theme="${state.currentTheme}"]`)?.classList.add('active');
    };
    const updateCurrentUserUI = () => {
        const user = state.currentUser;
        if (!user) return;
        [elements.currentUserNameEl, elements.currentUserNameDm].forEach(el => el.textContent = user.name);
        [elements.currentUserAvatarEl, elements.currentUserAvatarDm].forEach(el => el.src = user.avatar);
        
        const subtext = user.activity || (user.status.charAt(0).toUpperCase() + user.status.slice(1));
        [elements.currentUserSubtextEl, elements.currentUserSubtextDm].forEach(el => {
            if (el) el.textContent = subtext;
        });
        
        $$('#user-panel-avatar-wrapper .status-indicator, #dm-panel-avatar-wrapper .status-indicator').forEach(el => {
            el.className = `status-indicator ${user.status}`;
        });
    };
    const loadUserSettings = () => {
        const user = state.currentUser;
        $('#account-username-display').textContent = user.name;
        $('#account-email-display').textContent = user.email;
        $('#profile-about-me-input').value = user.about;
        $('#profile-banner-color-input').value = user.bannerColor;
        $(`input[name="fr-privacy"][value="${user.settings.privacy.friendRequest}"]`).checked = true;
        $('#dm-privacy-toggle').checked = user.settings.privacy.allowDmsFromServers;
        $('#message-display-setting').value = document.body.dataset.messageDisplay || 'cozy';
        if (user.voiceSettings) {
            $('#voice-input-device').value = user.voiceSettings.inputDevice;
            $('#voice-output-device').value = user.voiceSettings.outputDevice;
            $('#voice-input-volume').value = user.voiceSettings.inputVolume;
            $('#voice-output-volume').value = user.voiceSettings.outputVolume;
        }
    };
    const savedTheme = localStorage.getItem('theme') || 'dark';
    state.currentTheme = savedTheme;
    document.documentElement.setAttribute('data-theme', state.currentTheme);

    const savedAuth = localStorage.getItem('isAuthenticated');
    const savedUser = JSON.parse(localStorage.getItem('currentUser'));
    if (savedAuth === 'true' && savedUser && findUser(savedUser.id)) {
        state.isAuthenticated = true;
        state.currentUser = findUser(savedUser.id); // Load fresh data
        loadState();
        initApp();
        updateThemeSettingsUI();
        elements.authContainer.classList.add('hidden');
        elements.appContainer.classList.remove('hidden');
    } else {
        initAuth();
        elements.authContainer.classList.remove('hidden');
        elements.appContainer.classList.add('hidden');
    }
});