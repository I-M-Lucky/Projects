import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QToolBar, QAction, QSizePolicy, QSpacerItem, QWidget, QStackedWidget, QListWidget, QMenu, QToolButton, QLabel, QCompleter
from PyQt5.QtCore import QUrl, Qt, QSize, QTimer, QStringListModel
from PyQt5.QtGui import QIcon, QPixmap, QPalette, QBrush, QFont, QPainter, QPainterPath, QColor
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
from PyQt5.QtWidgets import QFrame, QScrollArea, QGridLayout, QDialog, QDialogButtonBox, QMessageBox, QGraphicsBlurEffect
from PyQt5.QtWidgets import QMenu, QAction
import requests  # Import the requests library

class Browser(QWidget):
    def __init__(self):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        super().__init__()
        self.setWindowTitle("Glassmorphic Browser")

        # Data Storage
        self.history = []
        self.bookmarks = []

        # ---- UI elements ----
        # Address Bar
        self.address_bar = QLineEdit()
        self.address_bar.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                padding: 5px;
                border-radius: 15px;
                font-size: 14px;
                color: white;
            }
            QLineEdit:focus {
                border: 1px solid rgba(255, 255, 255, 0.5);
            }
        """)
        self.address_bar.setPlaceholderText("Enter URL or Search")
        self.address_bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.address_bar.setMinimumWidth(500)
        self.address_bar.setMaximumWidth(800)

        # URL/Search Suggestions
        self.completer_model = QStringListModel()
        self.completer = QCompleter(self.completer_model, self)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.address_bar.setCompleter(self.completer)
        self.address_bar.textChanged.connect(self.update_completer)

        # Go Button
        self.go_button = QPushButton("Go")
        self.go_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.2);
                color: white;
                border: none;
                padding: 5px 15px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 14px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 15px;
                border: 1px solid rgba(255, 255, 255, 0.3);
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.3);
            }
            QPushButton:pressed {
                background-color: rgba(255, 255, 255, 0.4);
            }
        """)
        self.go_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.go_button.setMinimumHeight(33)
        self.go_button.setMaximumHeight(33)

        # Go Button Container (QFrame)
        self.gobutton_container = QFrame()
        self.gobutton_container.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.gobutton_container.setStyleSheet("""
            QFrame {
                border-radius: 15px;
                height: 33px;
            }
        """)

        gobutton_layout = QVBoxLayout()
        gobutton_layout.setContentsMargins(0, 0, 0, 0)
        gobutton_layout.addWidget(self.go_button)
        self.gobutton_container.setLayout(gobutton_layout)

        # Web View
        self.web_view = QWebEngineView()
        self.web_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.web_view.urlChanged.connect(self.update_title)
        self.web_view.setStyleSheet("border-radius: 20px;")

        # Web View Container (QFrame)
        self.webview_container = QFrame()
        self.webview_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.webview_container.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 20px;
                margin: 15px;
            }
        """)
        #blur_effect = QGraphicsBlurEffect()
        #blur_effect.setBlurRadius(10)
        #self.webview_container.setGraphicsEffect(blur_effect)  # Remove blur here

        webview_layout = QVBoxLayout()
        webview_layout.setContentsMargins(0, 0, 0, 0)
        webview_layout.addWidget(self.web_view)
        self.webview_container.setLayout(webview_layout)

        # Initial Widget (Before Search)
        self.initial_widget = QScrollArea()
        self.initial_widget.setWidgetResizable(True)
        self.initial_widget.setStyleSheet("background-color: transparent; border: none; border-radius: 20px;") #add border radius
        self.initial_widget.setContentsMargins(10,10,10,10)

        initial_content = QWidget()
        initial_layout = QVBoxLayout(initial_content)
        initial_layout.setAlignment(Qt.AlignTop)

        # Featured Content Section
        self.featured_label = QLabel("Featured")
        self.featured_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        initial_layout.addWidget(self.featured_label)

        self.featured_grid = QGridLayout()  # Use a grid layout
        initial_layout.addLayout(self.featured_grid)

        self.add_featured_website("Google", "https://www.google.com", ":/icons/google.png")  # Replace with actual icons later
        self.add_featured_website("YouTube", "https://www.youtube.com", ":/icons/youtube.png")
        self.add_featured_website("Wikipedia", "https://www.wikipedia.org", ":/icons/wikipedia.png")
        self.add_featured_website("DuckDuckGo", "https://duckduckgo.com", ":/icons/duckduckgo.png")
        self.featured_grid.setHorizontalSpacing(10)
        # Recently Viewed Section
        self.recently_viewed_label = QLabel("Recently Viewed")
        self.recently_viewed_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        initial_layout.addWidget(self.recently_viewed_label)

        self.recently_viewed_list = QListWidget()
        self.recently_viewed_list.setStyleSheet("color: white; background-color: rgba(255, 255, 255, 0.1); border: none;")
        self.recently_viewed_list.itemDoubleClicked.connect(self.load_recently_viewed_url)
        initial_layout.addWidget(self.recently_viewed_list)
        self.update_recently_viewed()

        # Bookmarks Section
        self.bookmarks_label = QLabel("Bookmarks")
        self.bookmarks_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        initial_layout.addWidget(self.bookmarks_label)

        self.bookmarks_list = QListWidget()
        self.bookmarks_list.setStyleSheet("color: white; background-color: rgba(255, 255, 255, 0.1); border: none;")
        self.bookmarks_list.itemDoubleClicked.connect(self.load_bookmark_url)
        self.bookmarks_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.bookmarks_list.customContextMenuRequested.connect(self.open_bookmark_menu)
        initial_layout.addWidget(self.bookmarks_list)
        self.update_bookmarks()

        initial_layout.addSpacerItem(QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Expanding))

        self.initial_widget.setWidget(initial_content)

        # Custom title bar
        title_bar = QWidget()
        title_bar_layout = QHBoxLayout()
        title_bar_layout.setContentsMargins(5, 0, 5, 0)

        # Add Title
        self.title_label = QLabel("ONE")
        self.title_label.setStyleSheet("color:white; font-size:12px;")
        title_bar_layout.addWidget(self.title_label)

        title_bar_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))

        # Close Button
        close_btn = QPushButton("X")
        close_btn.setFont(QFont("Arial", 12, QFont.Bold))
        close_btn.setStyleSheet("""
            QPushButton {
                border: none;
                background-color: rgba(255, 0, 0, 0.5);
                border-radius: 12px;
                color: white;
            }
            QPushButton:hover {
                background-color: rgba(255, 0, 0, 0.7);
            }
        """)
        close_btn.clicked.connect(self.close)
        close_btn.setFixedSize(QSize(24, 24))
        title_bar_layout.addWidget(close_btn)

        title_bar.setLayout(title_bar_layout)

        # Toolbar
        toolbar = QWidget()
        toolbar_layout = QHBoxLayout()
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        toolbar.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.favicon_label = QLabel()  # Label for the favicon
        self.favicon_label.setFixedSize(16, 16)  # Set a fixed size
        toolbar_layout.addWidget(self.favicon_label)

        # Home Button
        self.home_btn = QPushButton("🏠")
        self.home_btn.setFont(QFont("Arial", 12))
        self.home_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.home_btn.clicked.connect(self.go_home)
        self.home_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.home_btn)
        self.home_btn.setEnabled(False)

        # Back Button
        self.back_btn = QPushButton("←")
        self.back_btn.setFont(QFont("Arial", 12))
        self.back_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.back_btn.clicked.connect(self.web_view.back)
        self.back_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.back_btn)
        self.back_btn.setEnabled(False)

        # Forward Button
        self.forward_btn = QPushButton("→")
        self.forward_btn.setFont(QFont("Arial", 12))
        self.forward_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.forward_btn.clicked.connect(self.web_view.forward)
        self.forward_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.forward_btn)
        self.forward_btn.setEnabled(False)

        # Reload Button
        self.reload_btn = QPushButton("⟳")
        self.reload_btn.setFont(QFont("Arial", 12))
        self.reload_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.reload_btn.clicked.connect(self.reload_tab)
        self.reload_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.reload_btn)

        # Bookmark Button
        self.bookmark_button = QPushButton("☆")
        self.bookmark_button.setFont(QFont("Arial", 12))
        self.bookmark_button.setStyleSheet("QPushButton { border: none; color: white; }")
        self.bookmark_button.clicked.connect(self.toggle_bookmark)
        self.bookmark_button.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.bookmark_button)
        self.bookmark_button.setEnabled(False)

        # Zoom Controls
        self.zoom_in_btn = QPushButton("+")
        self.zoom_in_btn.setFont(QFont("Arial", 12))
        self.zoom_in_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.zoom_in_btn.clicked.connect(self.zoom_in)
        self.zoom_in_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.zoom_in_btn)
        self.zoom_in_btn.setEnabled(False)

        self.zoom_out_btn = QPushButton("-")
        self.zoom_out_btn.setFont(QFont("Arial", 12))
        self.zoom_out_btn.setStyleSheet("QPushButton { border: none; color: white; }")
        self.zoom_out_btn.clicked.connect(self.zoom_out)
        self.zoom_out_btn.setFixedSize(QSize(28, 28))
        toolbar_layout.addWidget(self.zoom_out_btn)
        self.zoom_out_btn.setEnabled(False)

        toolbar_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        toolbar.setLayout(toolbar_layout)
        toolbar.setStyleSheet("QWidget { background-color: rgba(255, 255, 255, 0.1); border-radius: 10px; }")
        toolbar.adjustSize()

        # ---- Layout ----
        hbox = QHBoxLayout()
        hbox.addStretch()
        hbox.addWidget(self.address_bar)
        hbox.addWidget(self.gobutton_container)
        hbox.addStretch()
        hbox.setContentsMargins(10, 5, 10, 0)

        vbox = QVBoxLayout()
        vbox.addWidget(title_bar)
        vbox.addWidget(toolbar)
        vbox.addLayout(hbox)  # **This line was missing!**

        # Stacked Widget
        self.stacked_widget = QStackedWidget()
        self.stacked_widget.addWidget(self.initial_widget)
        self.stacked_widget.addWidget(self.webview_container)
        self.stacked_widget.setCurrentWidget(self.initial_widget)

        vbox.addWidget(self.stacked_widget)
        vbox.setContentsMargins(0, 0, 0, 0)
        self.setLayout(vbox)
        self.setWindowFlags(Qt.FramelessWindowHint)

        # ---- Background Image ----
        self.background_image = QPixmap()
        try:
            image_data = requests.get("https://wallpapercave.com/wp/wp14471192.jpg").content
            if not self.background_image.loadFromData(image_data):
                print("Failed to load background image.")
            else:
                self.scaled_background = self.background_image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation) #Scale image

                palette = self.palette()
                palette.setBrush(QPalette.Window, QBrush(self.scaled_background)) #Scale image
                self.setPalette(palette)

            self.setAutoFillBackground(True)
        except requests.exceptions.RequestException as e:
            print(f"Error fetching background image: {e}")

        # ---- Signals and Slots ----
        self.go_button.clicked.connect(self.load_url)
        self.address_bar.returnPressed.connect(self.load_url)
        self.web_view.urlChanged.connect(self.update_address_bar)
        self.web_view.loadFinished.connect(self.on_load_finished)

        # Mouse Press Event for moving the window
        self.title_bar = title_bar
        self.title_bar.mousePressEvent = self.mousePressEvent
        self.title_bar.mouseMoveEvent = self.mouseMoveEvent
        self.offset = None

        self.loading_timer = QTimer(self)
        self.loading_timer.timeout.connect(self.check_loading_finished)
        self.loading_timer.setInterval(100) #Check every 100ms

    def load_url(self):
        try:
            url = self.address_bar.text()
            if not url.startswith("http://") and not url.startswith("https://"):
                if " " in url:  #Detect if is search query
                    url = "https://www.google.com/search?q=" + url.replace(" ", "+")
                else:
                    url = "http://" + url  #Prepend http if missing.
            self.address_bar.setText(url)
            url = QUrl(url)
            if not url.isValid():
                print(f"Invalid URL: {url}")
                return

            self.web_view.load(url)
            self.stacked_widget.setCurrentWidget(self.webview_container)
            self.add_history_item(url.toString())
            self.update_toolbar_buttons()
            self.bookmark_button.setEnabled(True)
            self.zoom_in_btn.setEnabled(True)
            self.zoom_out_btn.setEnabled(True)

            self.loading_timer.start()
        except Exception as e:
            print(f"Error in load_url: {e}")

    def check_loading_finished(self):
        try:
            if self.web_view.page().isLoading():
                return
            else:
                self.loading_timer.stop()
                self.update_title(self.web_view.url())
        except Exception as e:
            print(f"Error in check_loading_finished: {e}")

    def update_address_bar(self, q):
        self.address_bar.setText(q.toString())
        self.update_bookmark_button()
        self.update_favicon(q)

    def resizeEvent(self, event):
        # Resize the background image when the window is resized
        if not self.background_image.isNull():
            self.scaled_background = self.background_image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation) #Scale image

            palette = self.palette()
            palette.setBrush(QPalette.Window, QBrush(self.scaled_background)) #Scale image
            self.setPalette(palette)
        super().resizeEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.offset = event.pos()

    def mouseMoveEvent(self, event):
        if self.offset is not None:
            x = event.globalX()
            y = event.globalY()
            self.move(x - self.offset.x(), y - self.offset.y())

    def go_home(self):
        self.stacked_widget.setCurrentWidget(self.initial_widget)
        self.update_toolbar_buttons()
        self.bookmark_button.setEnabled(False)
        self.zoom_in_btn.setEnabled(False)
        self.zoom_out_btn.setEnabled(False)

    def reload_tab(self):
        if self.stacked_widget.currentWidget() == self.webview_container:
            self.web_view.reload()
        else:
            self.update_recently_viewed()

    def load_recently_viewed_url(self, item):
        url = item.text()
        self.address_bar.setText(url)
        self.load_url()

    def load_bookmark_url(self, item):
        url = item.text()
        self.address_bar.setText(url)
        self.load_url()

    def add_history_item(self, url):
        if url not in self.history:
            self.history.insert(0, url)
            if len(self.history) > 10:
                self.history.pop()
            self.update_recently_viewed()

    def update_title(self, url):
        title = self.web_view.title()
        if title:
            self.title_label.setText(title)
            self.setWindowTitle(title)
        else:
            self.title_label.setText("Glassmorphic Browser")
            self.setWindowTitle("Glassmorphic Browser")

    def toggle_bookmark(self):
        url = self.address_bar.text()
        if url:
            if url in self.bookmarks:
                self.bookmarks.remove(url)
                self.bookmark_button.setText("☆")
            else:
                self.bookmarks.append(url)
                self.bookmark_button.setText("★")
            self.update_bookmarks()

    def update_bookmark_button(self):
        url = self.address_bar.text()
        if url in self.bookmarks:
            self.bookmark_button.setText("★")
        else:
            self.bookmark_button.setText("☆")

    def update_recently_viewed(self):
        self.recently_viewed_list.clear()
        self.recently_viewed_list.addItems(self.history[:5])

    def update_bookmarks(self):
        self.bookmarks_list.clear()
        self.bookmarks_list.addItems(self.bookmarks)

    def update_toolbar_buttons(self):
        in_initial_state = self.stacked_widget.currentWidget() == self.initial_widget

        try:
            history = self.web_view.history()
            self.back_btn.setEnabled(not in_initial_state and history.canGoBack())
            self.forward_btn.setEnabled(not in_initial_state and history.canGoForward())
        except Exception as e:
            print(f"Error getting history or enabling buttons: {e}")
            self.back_btn.setEnabled(False)
            self.forward_btn.setEnabled(False)

        self.home_btn.setEnabled(not in_initial_state)
        self.zoom_in_btn.setEnabled(not in_initial_state)
        self.zoom_out_btn.setEnabled(not in_initial_state)

        if in_initial_state:
            self.title_label.setText("Glassmorphic Browser")
            self.setWindowTitle("Glassmorphic Browser")
        else:
            self.update_bookmark_button()

    def on_load_finished(self, ok):
        self.update_toolbar_buttons()

    def update_completer(self, text):
        suggestions = list(set(self.history + self.bookmarks))
        matches = [s for s in suggestions if text.lower() in s.lower()]
        self.completer_model.setStringList(matches)

    def add_featured_website(self, name, url, icon_path):
        button = QPushButton(name)
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: rgba(255, 255, 255, 0.1);
                color: white;
                border: none;
                padding: 5px 15px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 14px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 15px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                width: 48%;  /* Let it take up almost half the container */
                max-width: 48%; /*Let it have max-width of the container*/
                min-width: 100px; /*Ensure to be no lower then 100px*/
            }}
            QPushButton:hover {{
                background-color: rgba(255, 255, 255, 0.3);
            }}
        """)
        button.clicked.connect(lambda: self.load_featured_url(url))

        # Find the next available row and column. Ensures all buttons are aligned.
        row = self.featured_grid.count() // 2 if self.featured_grid.columnCount() > 0 else 0
        col = self.featured_grid.count() % 2 if self.featured_grid.columnCount() > 0 else 0

        self.featured_grid.addWidget(button, row, col, alignment=Qt.AlignmentFlag.AlignLeft)

        self.featured_grid.setColumnStretch(0, 1)  # Distribute space evenly
        self.featured_grid.setColumnStretch(1, 1)

        self.featured_grid.setSpacing(10) # Set space between item

    def load_featured_url(self, url):
        try:
            self.address_bar.setText(url)
            self.load_url()
        except Exception as e:
            print(f"Error in load_featured_url: {e}")

    def update_favicon(self, q):
        if q.isValid():
            try:
                favicon_url = self.web_view.page().iconUrl()
                if favicon_url.isValid():
                    import requests
                    image_data = requests.get(favicon_url.toString()).content
                    pixmap = QPixmap()
                    if pixmap.loadFromData(image_data):
                        scaled_pixmap = pixmap.scaled(16, 16, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                        self.favicon_label.setPixmap(scaled_pixmap)
                        self.favicon_label.show()
                    else:
                        self.favicon_label.clear()
                else:
                    self.favicon_label.clear()
            except Exception as e:
                print(f"Error loading favicon: {e}")
                self.favicon_label.clear()

        else:
            self.favicon_label.clear()

    def open_bookmark_menu(self, position):
        index = self.bookmarks_list.indexAt(position)
        if index.isValid():
            item = self.bookmarks_list.item(index.row())
            bookmark_url = item.text()

            menu = QMenu(self)
            edit_action = QAction("Edit Bookmark", self)
            delete_action = QAction("Delete Bookmark", self)
            menu.addAction(edit_action)
            menu.addAction(delete_action)

            edit_action.triggered.connect(lambda: self.edit_bookmark(bookmark_url))
            delete_action.triggered.connect(lambda: self.delete_bookmark(bookmark_url))

            menu.exec_(self.bookmarks_list.mapToGlobal(position))

    def edit_bookmark(self, url):
        dialog = EditBookmarkDialog(url, self)
        result = dialog.exec_()

        if result == QDialog.Accepted:
            new_url = dialog.url_edit.text()
            new_name = dialog.name_edit.text()

            if url in self.bookmarks:
                self.bookmarks.remove(url)
                self.bookmarks.append(new_url)  # Use new URL as the identifier

                index = self.bookmarks_list.findItems(url, Qt.MatchExactly)[0]
                index.setText(new_name)  # Update ListWidget with the new name (can store new URL in data field)

            self.update_bookmarks()

    def delete_bookmark(self, url):
         reply = QMessageBox.question(self, 'Delete Bookmark',
            f"Delete {url} from bookmarks?", QMessageBox.Yes |
            QMessageBox.No, QMessageBox.No)

         if reply == QMessageBox.Yes:
            if url in self.bookmarks:
                self.bookmarks.remove(url)
                self.update_bookmarks()

    def zoom_in(self):
        self.web_view.setZoomFactor(self.web_view.zoomFactor() + 0.25)

    def zoom_out(self):
        self.web_view.setZoomFactor(self.web_view.zoomFactor() - 0.25)


class EditBookmarkDialog(QDialog):
    def __init__(self, url, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Bookmark")

        self.url = url

        self.name_label = QLabel("Name:")
        self.name_edit = QLineEdit()
        self.name_edit.setText(url)  # Initial name (you can fetch/store names separately later)

        self.url_label = QLabel("URL:")
        self.url_edit = QLineEdit()
        self.url_edit.setText(url)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addWidget(self.name_label)
        layout.addWidget(self.name_edit)
        layout.addWidget(self.url_label)
        layout.addWidget(self.url_edit)
        layout.addWidget(button_box)

        self.setLayout(layout)


if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app.setStyle("Fusion")
    app.setAttribute(Qt.AA_DontCreateNativeWidgetSiblings, True)

    # Register custom resource path (replace with your actual path)
    QApplication.addLibraryPath("./resources")  #Example path where you might store resource files.

    browser = Browser()
    browser.showFullScreen()
    sys.exit(app.exec_())